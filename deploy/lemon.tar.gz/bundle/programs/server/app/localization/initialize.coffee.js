(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
i18n.languages = [
  {
    key: 'vi',
    display: 'T.Việt'
  }, {
    key: 'en',
    display: 'English'
  }
];

i18n.setDefaultLanguage('vi');

i18n.setLanguage('vi');

})();

//# sourceMappingURL=initialize.coffee.js.map

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.buildRoutes(Router);

})();

//# sourceMappingURL=router.coffee.js.map

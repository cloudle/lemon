(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
process.env.MONGO_URL = 'mongodb://localhost:27017/lemon';

process.env.MAIL_URL = 'smtp://lehaoson@gmail.com:Ultimate7@smtp.gmail.com:465/';

})();

//# sourceMappingURL=startup.coffee.js.map

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.publish('myProfile', function() {
  return Schema.userProfiles.find({
    user: this.userId
  });
});

Meteor.publishComposite('myMerchantProfiles', function() {
  var self;
  self = this;
  return {
    find: function() {
      var currentProfile;
      currentProfile = Schema.userProfiles.findOne({
        user: self.userId
      });
      if (!currentProfile) {
        return EmptyQueryResult;
      }
      return Schema.userProfiles.find({
        currentMerchant: currentProfile.currentMerchant
      });
    },
    children: [
      {
        find: function(profile) {
          return Meteor.users.find({
            _id: profile.user
          });
        }
      }, {
        find: function(profile) {
          return AvatarImages.find({
            _id: profile.avatar
          });
        }
      }
    ]
  };
});

Meteor.publish('myOption', function() {
  return Schema.userOptions.find({
    user: this.userId
  });
});

Meteor.publish('mySession', function() {
  return Schema.userSessions.find({
    user: this.userId
  });
});

Meteor.users.allow({
  insert: function(userId, user) {
    return true;
  },
  update: function(userId, user) {
    return true;
  },
  remove: function(userId, user) {
    if (Schema.orders.findOne({
      creator: user._id
    })) {
      return false;
    }
    if (Schema.sales.findOne({
      creator: user._id
    })) {
      return false;
    }
    if (Schema.imports.findOne({
      creator: user._id
    })) {
      return false;
    }
    if (Schema.customers.findOne({
      creator: user._id
    })) {
      return false;
    }
    MetroSummary.updateMetroSummaryByStaffDestroy(userId);
    return true;
  }
});

Schema.userProfiles.allow({
  insert: function(userId, userProfile) {
    return true;
  },
  update: function(userId, userProfile) {
    return true;
  },
  remove: function(userId, userProfile) {
    return true;
  }
});

Schema.userOptions.allow({
  insert: function(userId, userOption) {
    return true;
  },
  update: function(userId, userOption) {
    return true;
  },
  remove: function(userId, userOption) {
    return true;
  }
});

Schema.userSessions.allow({
  insert: function(userId, userSession) {
    return userSession.user === userId && Schema.userSessions.findOne({
      user: userId
    }) === void 0;
  },
  update: function(userId, userSession) {
    return userSession.user === userId;
  },
  remove: function(userId, userSession) {
    return true;
  }
});

})();

//# sourceMappingURL=user.coffee.js.map

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.publish('currentInventory', function(warehouseId) {
  var detail, inventory, mySession, warehouse;
  mySession = Schema.userSessions.findOne({
    user: this.userId
  });
  if (!mySession) {
    return [];
  }
  warehouse = Schema.warehouse.findOne({
    _id: warehouseId
  });
  if (warehouse.checkingInventory === false) {
    return [];
  }
  inventory = Schema.inventories.find({
    _id: warehouse.inventory
  });
  detail = Schema.inventoryDetails.find({
    inventory: warehouse.inventory
  });
  return [inventory, detail];
});

Meteor.publish('allInventoryAndDetail', function() {
  var inventory, inventoryDetail, myProfile;
  myProfile = Schema.userProfiles.findOne({
    user: this.userId
  });
  if (!myProfile) {
    return [];
  }
  inventory = Schema.inventories.find({});
  inventoryDetail = Schema.inventoryDetails.find({});
  return [inventory, inventoryDetail];
});

Meteor.publish('allInventory', function() {
  var myProfile;
  myProfile = Schema.userProfiles.findOne({
    user: this.userId
  });
  if (!myProfile) {
    return [];
  }
  return Schema.inventories.find({
    warehouse: myProfile.currentWarehouse
  });
});

Meteor.publishComposite('inventoryReviewInWarehouse', function() {
  var self;
  self = this;
  return {
    find: function() {
      var myProfile;
      myProfile = Schema.userProfiles.findOne({
        user: self.userId
      });
      if (!myProfile) {
        return EmptyQueryResult;
      }
      return Schema.inventories.find({
        submitted: true,
        warehouse: myProfile.currentWarehouse
      });
    },
    children: [
      {
        find: function(inventory) {
          return Schema.userProfiles.find({
            user: inventory.creator
          });
        }
      }
    ]
  };
});

Meteor.publishComposite('inventoryDetailInWarehouse', function(inventoryId) {
  var self;
  self = this;
  return {
    find: function() {
      var inventory;
      inventory = Schema.inventories.findOne({
        _id: inventoryId,
        creator: self.userId
      });
      if (!inventory) {
        return EmptyQueryResult;
      }
      return Schema.inventoryDetails.find({
        inventory: inventory._id
      });
    },
    children: [
      {
        find: function(inventoryDetail) {
          return Schema.productDetails.find({
            _id: inventoryDetail.productDetail
          });
        },
        children: [
          {
            find: function(productDetail) {
              return Schema.products.find({
                _id: productDetail.product
              });
            }
          }
        ]
      }
    ]
  };
});

Meteor.publishComposite('productLostInInventory', function(inventoryId) {
  var self;
  self = this;
  return {
    find: function() {
      var inventory;
      inventory = Schema.inventories.findOne({
        _id: inventoryId,
        creator: self.userId
      });
      if (!inventory) {
        return EmptyQueryResult;
      }
      return Schema.productLosts.find({
        inventory: inventory._id
      });
    },
    children: [
      {
        find: function(productLost) {
          return Schema.productDetails.find({
            _id: productLost.productDetail
          });
        },
        children: [
          {
            find: function(productDetail) {
              return Schema.products.find({
                _id: productDetail.product
              });
            }
          }
        ]
      }
    ]
  };
});

Schema.inventories.allow({
  insert: function() {
    return true;
  },
  update: function() {
    return true;
  },
  remove: function() {
    return true;
  }
});

Schema.inventoryDetails.allow({
  insert: function() {
    return true;
  },
  update: function() {
    return true;
  },
  remove: function() {
    return true;
  }
});

})();

//# sourceMappingURL=inventory.coffee.js.map

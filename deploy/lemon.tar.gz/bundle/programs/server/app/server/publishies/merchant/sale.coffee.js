(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.publish('mySaleAndDetail', function() {
  var myProfile, mySaleDetails, mySales;
  myProfile = Schema.userProfiles.findOne({
    user: this.userId
  });
  if (!myProfile) {
    return [];
  }
  mySales = Schema.sales.find({
    $and: [
      {
        merchant: myProfile.currentMerchant,
        warehouse: myProfile.currentWarehouse
      }, {
        $or: [
          {
            creator: myProfile.user
          }, {
            seller: myProfile.user
          }
        ]
      }
    ]
  });
  mySaleDetails = Schema.saleDetails.find({
    sale: {
      $in: _.pluck(mySales.fetch(), '_id')
    }
  });
  return [mySales, mySaleDetails];
});

Meteor.publish('saleBillAccounting', function() {
  var myProfile;
  myProfile = Schema.userProfiles.findOne({
    user: this.userId
  });
  if (!myProfile) {
    return [];
  }
  return Schema.sales.find({});
});

Meteor.publishComposite('billManagerSales', function() {
  var self;
  self = this;
  return {
    find: function() {
      var myProfile;
      myProfile = Schema.userProfiles.findOne({
        user: self.userId
      });
      if (!myProfile) {
        return EmptyQueryResult;
      }
      return Schema.sales.find({
        merchant: myProfile.currentMerchant
      });
    },
    children: [
      {
        find: function(sale) {
          return Schema.customers.find({
            _id: sale.buyer
          });
        },
        children: [
          {
            find: function(customer, sale) {
              return AvatarImages.find({
                _id: customer.avatar
              });
            }
          }
        ]
      }
    ]
  };
});

Meteor.publish('saleBills', function() {
  return Schema.sales.find({});
});

Meteor.publish('availableSales', function() {
  var myProfile;
  myProfile = Schema.userProfiles.findOne({
    user: this.userId
  });
  if (!myProfile) {
    return [];
  }
  return Schema.sales.find({
    merchant: myProfile.currentMerchant,
    warehouse: myProfile.currentWarehouse,
    submitted: true,
    returnLock: false
  });
});

Meteor.publishComposite('saleDetails', function(saleId) {
  var self;
  self = this;
  return {
    find: function() {
      if (!self.userId) {
        return EmptyQueryResult;
      }
      return Schema.saleDetails.find({
        sale: saleId
      });
    },
    children: [
      {
        find: function(saleDetail) {
          return Schema.products.find({
            _id: saleDetail.product
          });
        }
      }
    ]
  };
});

Meteor.publish('saleDetailAndProductAndReturn', function(saleId) {
  var myProfile, returnProducts, returns, saleDetail;
  myProfile = Schema.userProfiles.findOne({
    user: this.userId
  });
  if (!myProfile) {
    return [];
  }
  if (Schema.sales.findOne({
    _id: saleId,
    merchant: myProfile.currentMerchant,
    warehouse: myProfile.currentWarehouse
  })) {
    saleDetail = Schema.saleDetails.find({
      sale: saleId
    });
    returnProducts = Schema.products.find({
      _id: {
        $in: _.pluck(saleDetail.fetch(), 'product')
      }
    });
    returns = Schema.returns.find({
      sale: saleId,
      status: {
        $ne: 2
      }
    });
    return [saleDetail, returnProducts, returns];
  }
});

Schema.sales.allow({
  insert: function() {
    return true;
  },
  update: function() {
    return true;
  },
  remove: function() {
    return true;
  }
});

Schema.saleDetails.allow({
  insert: function() {
    return true;
  },
  update: function() {
    return true;
  },
  remove: function() {
    return true;
  }
});

})();

//# sourceMappingURL=sale.coffee.js.map

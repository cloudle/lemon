(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.publish('fake', function() {
  var self;
  self = this;
  return setTimeout(function() {
    return self.ready();
  }, 20000);
});

Meteor.publish('system', function() {
  return Schema.systems.find({});
});

Schema.systems.allow({
  insert: function() {
    return true;
  },
  update: function() {
    return true;
  },
  remove: function() {
    return true;
  }
});

AvatarImages.allow({
  insert: function() {
    return true;
  },
  update: function() {
    return true;
  },
  remove: function() {
    return true;
  },
  download: function() {
    return true;
  }
});

})();

//# sourceMappingURL=system.coffee.js.map

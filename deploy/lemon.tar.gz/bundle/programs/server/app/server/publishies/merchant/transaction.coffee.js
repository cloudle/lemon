(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.publish('availableReceivable', function() {
  var myProfile;
  myProfile = Schema.userProfiles.findOne({
    user: this.userId
  });
  if (!myProfile) {
    return [];
  }
  return Schema.transactions.find({
    merchant: myProfile.currentMerchant,
    warehouse: myProfile.currentWarehouse
  });
});

Meteor.publishComposite('receivableAndRelates', function() {
  var self;
  self = this;
  return {
    find: function() {
      var myProfile;
      myProfile = Schema.userProfiles.findOne({
        user: self.userId
      });
      if (!myProfile) {
        return EmptyQueryResult;
      }
      return Schema.transactions.find({
        merchant: myProfile.currentMerchant,
        warehouse: myProfile.currentWarehouse
      });
    },
    children: [
      {
        find: function(transaction) {
          return Schema.customers.find({
            _id: transaction.owner
          });
        },
        children: [
          {
            find: function(customer, transaction) {
              return AvatarImages.find({
                _id: customer.avatar
              });
            }
          }
        ]
      }
    ]
  };
});

Meteor.publishComposite('transactionDetails', function(transactionId) {
  var self;
  self = this;
  return {
    find: function() {
      var myProfile;
      myProfile = Schema.userProfiles.findOne({
        user: self.userId
      });
      if (!myProfile) {
        return EmptyQueryResult;
      }
      return Schema.transactionDetails.find({
        transaction: transactionId,
        merchant: myProfile.currentMerchant
      });
    },
    children: [
      {
        find: function(transactionDetail) {
          return Schema.userProfiles.find({
            user: transactionDetail.creator
          });
        }
      }
    ]
  };
});

Schema.transactions.allow({
  insert: function() {
    return true;
  },
  update: function() {
    return true;
  },
  remove: function() {
    return true;
  }
});

Schema.transactionDetails.allow({
  insert: function() {
    return true;
  },
  update: function() {
    return true;
  },
  remove: function() {
    return true;
  }
});

})();

//# sourceMappingURL=transaction.coffee.js.map

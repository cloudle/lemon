(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.publish('myPurchase', function() {
  var profile;
  if (!this.userId) {
    return [];
  }
  profile = Schema.userProfiles.findOne({
    user: this.userId
  });
  if (!profile) {
    return [];
  }
  return Schema.merchantPurchases.find({
    merchant: profile.currentMerchant
  });
});

Schema.merchantPurchases.allow({
  insert: function() {
    return true;
  },
  update: function() {
    return true;
  },
  remove: function() {
    return true;
  }
});

})();

//# sourceMappingURL=purchase.coffee.js.map

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.publishComposite('availableDeliveries', function() {
  var self;
  self = this;
  return {
    find: function() {
      var myProfile;
      myProfile = Schema.userProfiles.findOne({
        user: self.userId
      });
      if (!myProfile) {
        return EmptyQueryResult;
      }
      return Schema.deliveries.find({
        merchant: myProfile.currentMerchant
      });
    },
    children: [
      {
        find: function(delivery) {
          return Schema.customers.find({
            _id: delivery.buyer
          });
        },
        children: [
          {
            find: function(customer, delivery) {
              return AvatarImages.find({
                _id: customer.avatar
              });
            }
          }
        ]
      }
    ]
  };
});

Schema.deliveries.allow({
  insert: function() {
    return true;
  },
  update: function() {
    return true;
  },
  remove: function() {
    return true;
  }
});

})();

//# sourceMappingURL=delivery.coffee.js.map

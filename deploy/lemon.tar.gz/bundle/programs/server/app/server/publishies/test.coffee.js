(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.publishComposite('merchantTestDep', {
  find: function() {
    var currentProfile;
    currentProfile = Schema.userProfiles.findOne({
      user: "xdsada"
    });
    if (!currentProfile) {
      return EmptyQueryResult;
    }
    return Schema.userProfiles.find({
      currentMerchant: currentProfile.currentMerchant
    });
  },
  children: [
    {
      find: function(customer) {
        return AvatarImages.find({
          _id: customer.avatar
        });
      }
    }
  ]
});

})();

//# sourceMappingURL=test.coffee.js.map

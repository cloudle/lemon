(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.publishComposite('availableCustomers', function() {
  var self;
  self = this;
  return {
    find: function() {
      var myProfile;
      myProfile = Schema.userProfiles.findOne({
        user: self.userId
      });
      if (!myProfile) {
        return EmptyQueryResult;
      }
      return Schema.customers.find({
        parentMerchant: myProfile.parentMerchant
      });
    },
    children: [
      {
        find: function(customer) {
          return AvatarImages.find({
            _id: customer.avatar
          });
        }
      }
    ]
  };
});

Schema.customers.allow({
  insert: function(userId, customer) {
    var customerFound;
    customerFound = Schema.customers.findOne({
      currentMerchant: customer.parentMerchant,
      name: customer.name,
      phone: customer.phone
    });
    return customerFound === void 0;
  },
  update: function() {
    return true;
  },
  remove: function(userId, customer) {
    var anySaleFound;
    anySaleFound = Schema.sales.findOne({
      buyer: customer._id
    });
    return anySaleFound === void 0;
  }
});

})();

//# sourceMappingURL=customer.coffee.js.map

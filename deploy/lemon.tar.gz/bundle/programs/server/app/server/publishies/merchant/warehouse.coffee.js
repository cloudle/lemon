(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.publish('availableWarehouse', function() {
  var myProfile;
  myProfile = Schema.userProfiles.findOne({
    user: this.userId
  });
  if (!myProfile) {
    return [];
  }
  return Schema.warehouses.find({
    merchant: myProfile.currentMerchant
  });
});

Meteor.publish('allWarehouse', function() {
  var myProfile;
  myProfile = Schema.userProfiles.findOne({
    user: this.userId
  });
  if (!myProfile) {
    return [];
  }
  return Schema.warehouses.find({
    parentMerchant: myProfile.parentMerchant
  });
});

Schema.warehouses.allow({
  insert: function() {
    return true;
  },
  update: function() {
    return true;
  },
  remove: function() {
    return true;
  }
});

})();

//# sourceMappingURL=warehouse.coffee.js.map

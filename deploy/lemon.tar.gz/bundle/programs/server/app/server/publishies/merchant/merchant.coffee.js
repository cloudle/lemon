(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.publish('availableBranch', function() {
  var myProfile;
  myProfile = Schema.userProfiles.findOne({
    user: this.userId
  });
  if (!myProfile) {
    return [];
  }
  return Schema.merchants.find({
    $or: [
      {
        _id: myProfile.parentMerchant
      }, {
        parent: myProfile.parentMerchant
      }
    ]
  });
});

Meteor.publish('myMerchantAndWarehouse', function() {
  var myMerchant, myProfile, myWarehouse;
  myProfile = Schema.userProfiles.findOne({
    user: this.userId
  });
  if (!myProfile) {
    return [];
  }
  myMerchant = Schema.merchants.find({
    _id: myProfile.currentMerchant
  });
  myWarehouse = Schema.warehouses.find({
    _id: myProfile.currentWarehouse
  });
  return [myMerchant, myWarehouse];
});

Schema.merchants.allow({
  insert: function() {
    return true;
  },
  update: function() {
    return true;
  },
  remove: function() {
    return true;
  }
});

})();

//# sourceMappingURL=merchant.coffee.js.map

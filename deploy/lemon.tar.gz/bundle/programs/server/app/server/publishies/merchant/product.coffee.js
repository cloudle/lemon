(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.publish('products', function() {
  var myProfile;
  myProfile = Schema.userProfiles.findOne({
    user: this.userId
  });
  if (!myProfile) {
    return [];
  }
  return Schema.products.find({
    warehouse: myProfile.currentWarehouse,
    availableQuality: {
      $gt: 0
    }
  });
});

Meteor.publish('allProducts', function() {
  var myProfile;
  myProfile = Schema.userProfiles.findOne({
    user: this.userId
  });
  if (!myProfile) {
    return [];
  }
  return Schema.products.find({
    warehouse: myProfile.currentWarehouse
  });
});

Meteor.publish('allProductDetails', function() {
  var myProfile;
  myProfile = Schema.userProfiles.findOne({
    user: this.userId
  });
  if (!myProfile) {
    return [];
  }
  return Schema.productDetails.find({
    warehouse: myProfile.currentWarehouse
  });
});

Schema.products.allow({
  insert: function(userId, product) {
    if (Schema.products.findOne({
      merchant: product.merchant,
      warehouse: product.warehouse,
      productCode: product.productCode,
      skulls: product.skulls
    })) {
      return false;
    } else {
      return true;
    }
  },
  update: function(userId, product) {
    return true;
  },
  remove: function(userId, product) {
    var productInUse;
    productInUse = Schema.importDetails.findOne({
      product: product._id
    });
    return product.totalQuality === 0 && !productInUse;
  }
});

Schema.productDetails.allow({
  insert: function() {
    return true;
  },
  update: function() {
    return true;
  },
  remove: function() {
    return true;
  }
});

Schema.productLosts.allow({
  insert: function() {
    return true;
  },
  update: function() {
    return true;
  },
  remove: function() {
    return true;
  }
});

Schema.productGroups.allow({
  insert: function() {
    return true;
  },
  update: function() {
    return true;
  },
  remove: function() {
    return true;
  }
});

})();

//# sourceMappingURL=product.coffee.js.map

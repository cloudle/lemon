(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.publish('currentMerchantRoles', function() {
  var currentProfile;
  currentProfile = Schema.userProfiles.findOne({
    user: this.userId
  });
  if (!currentProfile) {
    return [];
  }
  return Schema.roles.find({
    $or: [
      {
        group: 'merchant'
      }, {
        currentMerchant: currentProfile.currentMerchant
      }
    ]
  });
});

Schema.roles.allow({
  insert: function() {
    return true;
  },
  update: function() {
    return true;
  },
  remove: function() {
    return true;
  }
});

})();

//# sourceMappingURL=role.coffee.js.map

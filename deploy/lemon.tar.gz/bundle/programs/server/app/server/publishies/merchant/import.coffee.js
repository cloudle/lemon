(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.publish('myImportHistory', function() {
  var myImports, myProfile;
  myProfile = Schema.userProfiles.findOne({
    user: this.userId
  });
  if (!myProfile) {
    return [];
  }
  return myImports = Schema.imports.find({
    creator: myProfile.user,
    merchant: myProfile.currentMerchant,
    warehouse: myProfile.currentWarehouse
  });
});

Meteor.publish('importDetails', function(importId) {
  var currentOrder;
  currentOrder = Schema.imports.findOne(importId);
  if (!this.userId || (currentOrder != null ? currentOrder.creator : void 0) !== this.userId) {
    return [];
  }
  return Schema.importDetails.find({
    "import": importId
  });
});

Meteor.publishComposite('importHistoryInWarehouse', function() {
  var self;
  self = this;
  return {
    find: function() {
      var myProfile;
      myProfile = Schema.userProfiles.findOne({
        user: self.userId
      });
      if (!myProfile) {
        return EmptyQueryResult;
      }
      return Schema.imports.find({
        submitted: true,
        warehouse: myProfile.currentWarehouse
      });
    },
    children: [
      {
        find: function(imports) {
          return Schema.userProfiles.find({
            user: imports.creator
          });
        }
      }
    ]
  };
});

Meteor.publishComposite('importDetailInWarehouse', function(importId) {
  var self;
  self = this;
  return {
    find: function() {
      var myProfile;
      myProfile = Schema.userProfiles.findOne({
        user: self.userId
      });
      if (!myProfile) {
        return EmptyQueryResult;
      }
      return Schema.importDetails.find({
        "import": importId,
        warehouse: myProfile.currentWarehouse
      });
    },
    children: [
      {
        find: function(importDetail) {
          return Schema.products.find({
            _id: importDetail.product
          });
        }
      }
    ]
  };
});

Schema.imports.allow({
  insert: function(userId, imports) {
    return true;
  },
  update: function(userId, imports) {
    return true;
  },
  remove: function(userId, imports) {
    return true;
  }
});

Schema.importDetails.allow({
  insert: function(userId, importDetail) {
    return true;
  },
  update: function(userId, importDetail) {
    return true;
  },
  remove: function(userId, importDetail) {
    return true;
  }
});

})();

//# sourceMappingURL=import.coffee.js.map

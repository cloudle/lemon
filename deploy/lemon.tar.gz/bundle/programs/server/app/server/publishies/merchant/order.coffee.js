(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.publish('myOrderHistory', function() {
  var historyOrders, myProfile, mySession, orderId;
  myProfile = Schema.userProfiles.findOne({
    user: this.userId
  });
  if (!myProfile) {
    return [];
  }
  historyOrders = Schema.orders.find({
    creator: myProfile.user,
    merchant: myProfile.currentMerchant,
    warehouse: myProfile.currentWarehouse
  });
  if (historyOrders.count() === 0) {
    orderId = Order.createdNewBy(null, myProfile);
    mySession = Schema.userSessions.findOne({
      user: this.userId
    });
    Schema.userSessions.update(mySession._id, {
      $set: {
        currentOrder: orderId
      }
    });
    historyOrders = Schema.orders.find({
      creator: myProfile.user,
      merchant: myProfile.currentMerchant,
      warehouse: myProfile.currentWarehouse
    });
  }
  return historyOrders;
});

Meteor.publish('orderDetails', function(orderId) {
  var currentOrder;
  currentOrder = Schema.orders.findOne(orderId);
  if (!this.userId || (currentOrder != null ? currentOrder.creator : void 0) !== this.userId) {
    return [];
  }
  return Schema.orderDetails.find({
    order: orderId
  });
});

Schema.orders.allow({
  insert: function() {
    return true;
  },
  update: function() {
    return true;
  },
  remove: function() {
    return true;
  }
});

Schema.orderDetails.allow({
  insert: function() {
    return true;
  },
  update: function() {
    return true;
  },
  remove: function() {
    return true;
  }
});

})();

//# sourceMappingURL=order.coffee.js.map

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.publish('distributors', function() {
  var myProfile;
  myProfile = Schema.userProfiles.findOne({
    user: this.userId
  });
  if (!myProfile) {
    return [];
  }
  return Schema.distributors.find({
    merchant: myProfile.currentMerchant
  });
});

Schema.distributors.allow({
  insert: function() {
    return true;
  },
  update: function() {
    return true;
  },
  remove: function() {
    return true;
  }
});

})();

//# sourceMappingURL=distributor.coffee.js.map

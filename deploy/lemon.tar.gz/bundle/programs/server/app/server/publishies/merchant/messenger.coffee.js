(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.publish('unreadMessages', function() {
  if (!this.userId) {
    return [];
  }
  return Schema.messages.find({
    receiver: this.userId,
    reads: {
      $ne: this.userId
    }
  });
});

})();

//# sourceMappingURL=messenger.coffee.js.map

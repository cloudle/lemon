(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.publish('returnDetails', function(returnId) {
  var myProfile, returns;
  myProfile = Schema.userProfiles.findOne({
    user: this.userId
  });
  if (!myProfile) {
    return [];
  }
  returns = Schema.returns.findOne({
    _id: returnId,
    status: {
      $ne: 2
    }
  });
  return Schema.returnDetails.find({
    "return": returns._id
  });
});

Schema.returns.allow({
  insert: function() {
    return true;
  },
  update: function() {
    return true;
  },
  remove: function() {
    return true;
  }
});

Schema.returnDetails.allow({
  insert: function() {
    return true;
  },
  update: function() {
    return true;
  },
  remove: function() {
    return true;
  }
});

})();

//# sourceMappingURL=return.coffee.js.map

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.publish('unreadNotifications', function() {
  if (!this.userId) {
    return [];
  }
  return Schema.notifications.find({
    receiver: this.userId,
    seen: false
  });
});

})();

//# sourceMappingURL=notification.coffee.js.map

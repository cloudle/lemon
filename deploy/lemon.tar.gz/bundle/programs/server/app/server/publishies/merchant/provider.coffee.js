(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.publish('providers', function() {
  var myProfile;
  myProfile = Schema.userProfiles.findOne({
    user: this.userId
  });
  if (!myProfile) {
    return [];
  }
  return Schema.providers.find({
    parentMerchant: myProfile.parentMerchant
  });
});

Schema.providers.allow({
  insert: function(userId, provider) {
    if (Schema.providers.findOne({
      parentMerchant: provider.parentMerchant,
      name: provider.name
    })) {
      return false;
    } else {
      return true;
    }
  },
  update: function(userId, provider) {
    return true;
  },
  remove: function(userId, provider) {
    return true;
  }
});

})();

//# sourceMappingURL=provider.coffee.js.map

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var checkProductInStockQuality, createSaleAndSaleOrder, removeOrderAndOrderDetail, subtractQualityOnSales;

checkProductInStockQuality = function(orderDetails, products) {
  var currentDetail, currentProduct, e, _i, _len;
  orderDetails = _.chain(orderDetails).groupBy("product").map(function(group, key) {
    return {
      product: key,
      quality: _.reduce(group, (function(res, current) {
        return res + current.quality;
      }), 0)
    };
  }).value();
  try {
    for (_i = 0, _len = orderDetails.length; _i < _len; _i++) {
      currentDetail = orderDetails[_i];
      currentProduct = _.findWhere(products, {
        _id: currentDetail.product
      });
      if (currentProduct.availableQuality < currentDetail.quality) {
        throw {
          message: "lỗi",
          item: currentDetail
        };
      }
    }
    return {};
  } catch (_error) {
    e = _error;
    return {
      error: e
    };
  }
};

subtractQualityOnSales = function(stockingItems, sellingItem, currentSale) {
  var productDetail, requiredQuality, takenQuality, transactionQuality, _i, _len;
  transactionQuality = 0;
  for (_i = 0, _len = stockingItems.length; _i < _len; _i++) {
    productDetail = stockingItems[_i];
    requiredQuality = sellingItem.quality - transactionQuality;
    if (productDetail.availableQuality > requiredQuality) {
      takenQuality = requiredQuality;
    } else {
      takenQuality = productDetail.availableQuality;
    }
    SaleDetail.createSaleDetailByOrder(currentSale, sellingItem, productDetail, takenQuality);
    Schema.productDetails.update(productDetail._id, {
      $inc: {
        availableQuality: -takenQuality
      }
    });
    Schema.products.update(productDetail.product, {
      $inc: {
        availableQuality: -takenQuality
      }
    });
    transactionQuality += takenQuality;
    if (transactionQuality === sellingItem.quality) {
      break;
    }
  }
  return transactionQuality === sellingItem.quality;
};

createSaleAndSaleOrder = function(order, orderDetails) {
  var currentOrderDetail, currentSale, option, productDetails, _i, _len;
  currentSale = Sale.findOne(Sale.insertByOrder(order));
  if (!currentSale) {
    throw new Meteor.Error("Create sale fail.");
  }
  for (_i = 0, _len = orderDetails.length; _i < _len; _i++) {
    currentOrderDetail = orderDetails[_i];
    productDetails = Schema.productDetails.find({
      product: currentOrderDetail.product,
      availableQuality: {
        $gt: 0
      }
    }).fetch();
    subtractQualityOnSales(productDetails, currentOrderDetail, currentSale.data);
  }
  option = {
    status: true
  };
  if (currentSale.data.paymentsDelivery === 1) {
    option.delivery = Delivery.insertBySale(order, currentSale.data);
  }
  Sale.update(currentSale.id, {
    $set: option
  }, function(error, result) {
    if (error) {
      return console.log(error);
    }
  });
  return currentSale;
};

removeOrderAndOrderDetail = function(order, userProfile) {
  var allTabs, buyer, currentIndex, currentLength, currentSource, nextIndex;
  allTabs = Order.myHistory(userProfile.user, userProfile.currentWarehouse, userProfile.currentMerchant).fetch();
  currentSource = _.findWhere(allTabs, {
    _id: userProfile.currentOrder
  });
  currentIndex = allTabs.indexOf(currentSource);
  currentLength = allTabs.length;
  if (currentLength > 1) {
    nextIndex = currentIndex === currentLength - 1 ? currentIndex - 1 : currentIndex + 1;
    UserSession.set('currentOrder', allTabs[nextIndex]._id);
  } else {
    buyer = Customer.findOne(order.buyer).data;
    UserSession.set('currentOrder', Order.createdNewBy(buyer, userProfile));
  }
  Order.remove(order._id);
  return OrderDetail.remove({
    order: order._id
  });
};

Meteor.methods({
  finishOrder: function(orderId) {
    var currentOrder, orderDetails, product_ids, products, result, sale, userProfile;
    userProfile = Schema.userProfiles.findOne({
      user: this.userId
    });
    if (!userProfile) {
      throw new Meteor.Error("User chưa đăng nhập.");
      return;
    }
    currentOrder = Schema.orders.findOne({
      _id: orderId,
      creator: userProfile.user,
      merchant: userProfile.currentMerchant,
      warehouse: userProfile.currentWarehouse
    });
    if (!currentOrder) {
      throw new Meteor.Error("Order không tồn tại.");
      return;
    }
    orderDetails = Schema.orderDetails.find({
      order: currentOrder._id
    }).fetch();
    if (orderDetails.length < 1) {
      throw new Meteor.Error("Order rỗng.");
      return;
    }
    product_ids = _.union(_.pluck(orderDetails, 'product'));
    products = Schema.products.find({
      _id: {
        $in: product_ids
      }
    }).fetch();
    result = checkProductInStockQuality(orderDetails, products);
    if (result.error) {
      throw new Meteor.Error(result.error);
    }
    sale = createSaleAndSaleOrder(currentOrder, orderDetails);
    if (sale) {
      return removeOrderAndOrderDetail(currentOrder, userProfile);
    }
  }
});

})();

//# sourceMappingURL=order.coffee.js.map

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var navigateNewTab;

navigateNewTab = function(currentImportId, profile) {
  var allTabs, currentIndex, currentLength, currentSource, importId, nextIndex;
  allTabs = Import.myHistory(profile.user, profile.currentWarehouse, profile.currentMerchant).fetch();
  currentSource = _.findWhere(allTabs, {
    _id: currentImportId
  });
  currentIndex = allTabs.indexOf(currentSource);
  currentLength = allTabs.length;
  if (currentLength > 1) {
    nextIndex = currentIndex === currentLength - 1 ? currentIndex - 1 : currentIndex + 1;
    return UserSession.set('currentImport', allTabs[nextIndex]._id);
  } else {
    importId = Import.createdNewBy('01-05-2015', profile);
    UserSession.set('currentImport', importId);
    return Schema.imports.findOne(importId);
  }
};

Meteor.methods({
  importEnabledEdit: function(importId) {
    var currentImport, importDetail, importDetails, _i, _len;
    currentImport = Schema.imports.findOne({
      _id: importId,
      finish: false,
      submitted: true
    });
    if (currentImport) {
      importDetails = Schema.importDetails.find({
        "import": importId
      }).fetch();
      if (importDetails.length > 0) {
        for (_i = 0, _len = importDetails.length; _i < _len; _i++) {
          importDetail = importDetails[_i];
          Schema.importDetails.update(importDetail._id, {
            $set: {
              submitted: false
            }
          });
        }
        Schema.imports.update(importId, {
          $set: {
            submitted: false
          }
        });
        return 'Phieu Co The Duoc Chinh Sua';
      }
    }
  },
  importSubmit: function(importId) {
    var currentImport, importDetail, importDetails, _i, _len;
    currentImport = Schema.imports.findOne({
      _id: importId,
      finish: false,
      submitted: false
    });
    if (currentImport) {
      importDetails = Schema.importDetails.find({
        "import": importId
      }).fetch();
      if (importDetails.length > 0) {
        for (_i = 0, _len = importDetails.length; _i < _len; _i++) {
          importDetail = importDetails[_i];
          Schema.importDetails.update(importDetail._id, {
            $set: {
              submitted: true
            }
          });
        }
        Schema.imports.update(importId, {
          $set: {
            submitted: true
          }
        });
        return 'Duoc Xac Nhan, Cho Duyet Cua Quan Ly';
      }
    }
  },
  importFinish: function(importId) {
    var currentImport, importDetail, importDetails, option1, option2, product, productDetail, profile, transaction, transactionDetail, warehouseImport, _i, _j, _len, _len1;
    if (profile = Schema.userProfiles.findOne({
      user: Meteor.userId()
    })) {
      currentImport = Schema.imports.findOne({
        _id: importId,
        submitted: true,
        finish: false,
        merchant: profile.currentMerchant
      });
      if (currentImport) {
        importDetails = Schema.importDetails.find({
          "import": importId
        }).fetch();
        for (_i = 0, _len = importDetails.length; _i < _len; _i++) {
          importDetail = importDetails[_i];
          if (!Schema.products.findOne(importDetail.product)) {
            throw new Meteor.Error('importError', 'Không tìm thấy sản phẩm id:' + importDetail.product);
            return;
          }
        }
        for (_j = 0, _len1 = importDetails.length; _j < _len1; _j++) {
          importDetail = importDetails[_j];
          productDetail = ProductDetail.newProductDetail(currentImport, importDetail);
          Schema.productDetails.insert(productDetail, function(error, result) {
            if (error) {
              throw new Meteor.Error('importError', 'Sai thông tin sản phẩm nhập kho');
            }
          });
          product = Schema.products.findOne(importDetail.product);
          option1 = {
            totalQuality: importDetail.importQuality,
            availableQuality: importDetail.importQuality,
            inStockQuality: importDetail.importQuality
          };
          option2 = {
            provider: importDetail.provider,
            importPrice: importDetail.importPrice,
            allowDelete: false
          };
          if (importDetail.salePrice) {
            option2.price = importDetail.salePrice;
          }
          Schema.products.update(product._id, {
            $inc: option1,
            $set: option2
          }, function(error, result) {
            if (error) {
              throw new Meteor.Error('importError', 'Sai thông tin sản phẩm nhập kho');
            }
          });
        }
        navigateNewTab(currentImport._id, profile);
        Schema.imports.update(currentImport._id, {
          $set: {
            finish: true,
            submitted: true
          }
        });
        warehouseImport = Schema.imports.findOne(importId);
        transaction = Transaction.newByImport(warehouseImport);
        transactionDetail = TransactionDetail.newByTransaction(transaction);
        MetroSummary.updateMetroSummaryByImport(importId);
      }
      return 'Phiếu nhập kho đã được duyệt';
    } else {
      throw new Meteor.Error('importError', 'Đã có lỗi trong quá trình xác nhận');
    }
  }
});

})();

//# sourceMappingURL=import.coffee.js.map

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var createInventory;

createInventory = function(warehouse, userProfile, description, productDetails) {
  var inventoryId, productDetail, _i, _len, _ref;
  if (inventoryId = Schema.inventories.insert({
    merchant: warehouse.merchant,
    warehouse: warehouse._id,
    creator: userProfile.user,
    description: description
  })) {
    _ref = productDetails.fetch();
    for (_i = 0, _len = _ref.length; _i < _len; _i++) {
      productDetail = _ref[_i];
      Schema.inventoryDetails.insert({
        merchant: warehouse.merchant,
        warehouse: warehouse._id,
        creator: userProfile.user,
        inventory: inventoryId,
        product: productDetail.product,
        productDetail: productDetail._id,
        lockOriginalQuality: productDetail.inStockQuality
      });
    }
    Schema.inventories.update(inventoryId, {
      $set: {
        detail: true
      }
    });
    return Schema.warehouses.update(warehouse._id, {
      $set: {
        checkingInventory: true,
        inventory: inventoryId
      }
    });
  }
};

Meteor.methods({
  createNewInventory: function(warehouseId, description) {
    var productDetails, userProfile, warehouse;
    userProfile = Schema.userProfiles.findOne({
      user: Meteor.userId()
    });
    if (!userProfile) {
      throw new Meteor.Error("Chưa đăng nhập.");
      return;
    }
    warehouse = Schema.warehouses.findOne({
      _id: warehouseId,
      merchant: userProfile.currentMerchant
    });
    if (!warehouse) {
      throw new Meteor.Error("Warehouse không chính xác");
      return;
    }
    if (warehouse.checkingInventory === true) {
      throw new Meteor.Error("Warehouse đang kiểm kho.");
      return;
    }
    productDetails = Schema.productDetails.find({
      warehouse: warehouseId,
      inStockQuality: {
        $gt: 0
      }
    });
    if (productDetails.count() < 1) {
      throw new Meteor.Error("Warehouse đang trống.");
      return;
    }
    createInventory(warehouse, userProfile, description, productDetails);
    return 'Tao thanh cong';
  }
});

})();

//# sourceMappingURL=inventory.coffee.js.map

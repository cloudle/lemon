(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({
  mailTo: function(to, from, subject, text) {
    this.unblock();
    return Email.send({
      to: to,
      from: from,
      subject: subject,
      text: text
    });
  }
});

})();

//# sourceMappingURL=email.coffee.js.map

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({
  updateDelivery: function(deliveryId, status) {
    var currentDelivery, sale, setOptionDelivery, setOptionSale, transaction, unsetOptionDelivery, unsetOptionSale, userProfile, _ref;
    if (!(userProfile = Schema.userProfiles.findOne({
      user: Meteor.userId()
    }))) {
      throw new Meteor.Error('deliveryError', Apps.Merchant.DeliveryError.userNotFound.reason);
      return;
    }
    if (!(currentDelivery = Schema.deliveries.findOne({
      _id: deliveryId,
      merchant: userProfile.currentMerchant,
      warehouse: userProfile.currentWarehouse
    }))) {
      throw new Meteor.Error('deliveryError', Apps.Merchant.DeliveryError.userNotFound.reason);
      return;
    }
    if (!(sale = Schema.sales.findOne(currentDelivery.sale))) {
      throw new Meteor.Error('deliveryError', Apps.Merchant.DeliveryError.saleNotDelivery.reason);
      return;
    }
    if ((sale.status === (_ref = sale.submitted) && _ref === true)) {
      throw new Meteor.Error('deliveryError', Apps.Merchant.DeliveryError.deliveryIsFinish.reason);
      return;
    }
    transaction = Schema.transactions.findOne({
      parent: sale._id
    });
    setOptionDelivery = {
      $set: {}
    };
    setOptionSale = {
      $set: {}
    };
    unsetOptionSale = {
      $unset: {}
    };
    unsetOptionDelivery = {
      $unset: {}
    };
    switch (status) {
      case 'cancel':
        if (currentDelivery.shipper === userProfile.user) {
          if (currentDelivery.status === 2) {
            setOptionDelivery = {
              $set: {
                status: 1
              }
            };
            unsetOptionDelivery = {
              shipper: true
            };
            setOptionSale = {
              $set: {
                status: false
              }
            };
          }
          if (currentDelivery.status === 4) {
            setOptionDelivery = {
              $set: {
                status: 3
              }
            };
          }
          if (currentDelivery.status === 8) {
            setOptionDelivery = {
              $set: {
                status: 4
              }
            };
            setOptionSale = {
              $set: {
                status: false
              }
            };
          }
        }
        break;
      case 'select':
        if (currentDelivery.status === 1) {
          setOptionDelivery = {
            $set: {
              status: 2,
              shipper: userProfile.user
            }
          };
          setOptionSale = {
            $set: {
              status: true
            }
          };
        }
        break;
      case 'start':
        if (currentDelivery.status === 3) {
          setOptionDelivery = {
            $set: {
              status: 4,
              shipper: userProfile.user
            }
          };
        }
        break;
      case 'success':
        if (currentDelivery.status === 4) {
          if (transaction.debitCash > 0) {
            setOptionDelivery = {
              $set: {
                status: 5,
                shipper: userProfile.user
              }
            };
            setOptionSale = {
              $set: {
                status: true,
                success: true
              }
            };
          } else {
            setOptionDelivery = {
              $set: {
                status: 7,
                shipper: userProfile.user
              }
            };
            setOptionSale = {
              $set: {
                status: false,
                success: true,
                submitted: true
              }
            };
          }
        }
        break;
      case 'fail':
        if (currentDelivery.status === 4) {
          if (transaction.debitCash > 0) {
            setOptionDelivery = {
              $set: {
                status: 8,
                shipper: userProfile.user
              }
            };
            setOptionSale = {
              $set: {
                status: true,
                success: false
              }
            };
          } else {
            setOptionDelivery = {
              $set: {
                status: 8,
                shipper: userProfile.user
              }
            };
            setOptionSale = {
              $set: {
                status: true,
                success: false
              }
            };
          }
        }
        break;
      case 'finish':
        if (currentDelivery.status === 6) {
          setOptionDelivery = {
            $set: {
              status: 7,
              shipper: userProfile.user
            }
          };
          setOptionSale = {
            $set: {
              status: true,
              submitted: true
            }
          };
        }
        if (currentDelivery.status === 9) {
          setOptionDelivery = {
            $set: {
              status: 10,
              shipper: userProfile.user
            }
          };
          setOptionSale = {
            $set: {
              status: true,
              submitted: true
            }
          };
        }
    }
    Schema.deliveries.update(currentDelivery._id, setOptionDelivery, unsetOptionDelivery);
    return Schema.sales.update(currentDelivery.sale, setOptionSale, unsetOptionSale);
  }
});

})();

//# sourceMappingURL=delivery.coffee.js.map

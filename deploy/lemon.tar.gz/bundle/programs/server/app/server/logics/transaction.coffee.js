(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({
  deleteTransaction: function(id) {
    var error, permission, profile, transaction, transactionDetails;
    try {
      profile = Schema.userProfiles.findOne({
        user: Meteor.userId()
      });
      if (!profile) {
        throw 'Không tìm thấy profile';
      }
      permission = Role.hasPermission(profile._id, Apps.Merchant.Permissions.transactionManagement.key);
      if (permission === false) {
        throw 'Bạn không có quyền thực hiên.';
      }
      transaction = Schema.transactions.findOne({
        _id: id,
        merchant: profile.currentMerchant
      });
      if (!transaction) {
        throw 'Không tìm thấy transaction';
      }
      transactionDetails = Schema.transactionDetails.find({
        transaction: transaction._id
      });
      if (transactionDetails.count() > 0) {
        throw 'Không thể xóa transaction khi có transactionDetails';
      }
      if ((Schema.transactions.remove(transaction._id)) === 1) {
        return true;
      } else {
        throw 'Xóa transaction không thành công';
      }
    } catch (_error) {
      error = _error;
      throw new Meteor.Error('deleteTransaction', error);
    }
  },
  addTransactionDetail: function(transactionId, depositCash, paymentDate) {
    var error, permission, profile, transaction;
    try {
      profile = Schema.userProfiles.findOne({
        user: Meteor.userId()
      });
      if (!profile) {
        throw 'Không tìm thấy profile';
      }
      permission = Role.hasPermission(profile._id, Apps.Merchant.Permissions.transactionManagement.key);
      if (permission === false) {
        throw 'Bạn không có quyền thực hiên.';
      }
      transaction = Schema.transactions.findOne({
        _id: transactionId,
        merchant: profile.currentMerchant
      });
      if (!transaction) {
        throw 'Không tìm thấy transaction';
      }
      if (transaction.debitCash < depositCash) {
        throw 'Tiền trả lớn hơn tiền thiếu.';
      }
      if (depositCash <= 0) {
        throw 'Tiền trả lớn hơn 0.';
      }
      console.log('ok');
      if (Schema.transactionDetails.insert(TransactionDetail["new"](profile.user, transaction, depositCash, paymentDate))) {
        console.log('ok 1');
        return Schema.transactions.update(transaction._id, {
          $inc: {
            depositCash: depositCash,
            debitCash: -depositCash
          }
        });
      } else {
        throw 'Thêm trả nợ không thành công';
      }
    } catch (_error) {
      error = _error;
      throw new Meteor.Error('addTransactionDetail', error);
    }
  }
});

})();

//# sourceMappingURL=transaction.coffee.js.map

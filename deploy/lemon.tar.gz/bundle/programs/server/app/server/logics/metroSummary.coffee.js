(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({
  reCalculateMetroSummary: function(id) {
    var metro;
    metro = MetroSummary.findOne(id);
    return metro.updateMetroSummary();
  }
});

})();

//# sourceMappingURL=metroSummary.coffee.js.map

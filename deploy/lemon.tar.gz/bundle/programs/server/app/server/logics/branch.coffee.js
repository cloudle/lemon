(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({
  createNewBranch: function(name, address) {
    var merchantId, myProfile;
    myProfile = Schema.userProfiles.findOne({
      user: Meteor.userId()
    });
    if (myProfile && name) {
      merchantId = Schema.merchants.insert({
        parent: myProfile.parentMerchant,
        creator: myProfile.user,
        name: name,
        address: address ? address : void 0
      });
      Schema.warehouses.insert(Warehouse.newDefault({
        merchantId: merchantId
      }));
      Schema.metroSummaries.insert(MetroSummary.newByMerchant(merchantId));
      return MetroSummary.updateMetroSummaryBy(['branch']);
    }
  },
  destroyBranch: function(branchId) {
    var branch, myProfile;
    myProfile = Schema.userProfiles.findOne({
      user: Meteor.userId()
    });
    if (myProfile && (branch = Schema.merchants.findOne({
      _id: branchId,
      parent: myProfile.parentMerchant
    }))) {
      if (!Schema.products.findOne({
        merchant: branchId,
        totalQuality: {
          $gt: 0
        }
      })) {
        Schema.warehouses.remove({
          merchant: branchId
        });
        Schema.metroSummaries.remove({
          merchant: branchId
        });
        Schema.merchants.remove({
          _id: branchId
        });
        MetroSummary.updateMetroSummaryBy(['branch']);
        return 'Xóa thành công chi nhánh.';
      }
    }
  }
});

})();

//# sourceMappingURL=branch.coffee.js.map

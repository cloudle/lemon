(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({
  createSaleExport: function(saleId) {
    var currentSale, productOption, saleDetail, userProfile, _i, _len, _ref;
    if (userProfile = Schema.userProfiles.findOne({
      user: Meteor.userId()
    })) {
      if (currentSale = Schema.sales.findOne({
        _id: saleId,
        merchant: userProfile.currentMerchant,
        status: true,
        received: true,
        exported: false,
        imported: false,
        submitted: false,
        paymentsDelivery: {
          $in: [0, 1]
        }
      })) {
        _ref = Schema.saleDetails.find({
          sale: currentSale._id
        }).fetch();
        for (_i = 0, _len = _ref.length; _i < _len; _i++) {
          saleDetail = _ref[_i];
          productOption = {
            $inc: {
              inStockQuality: -saleDetail.quality
            }
          };
          Schema.products.update(saleDetail.product, productOption);
          Schema.productDetails.update(saleDetail.productDetail, productOption);
          Schema.saleDetails.update(saleDetail._id, {
            $set: {
              exported: true,
              exportDate: new Date,
              status: true
            }
          });
          Schema.saleExports.insert(SaleExport["new"](currentSale, saleDetail), function(error, result) {
            if (error) {
              return console.log(error);
            }
          });
        }
        MetroSummary.updateMetroSummaryBySaleExport(currentSale._id);
        switch (currentSale.paymentsDelivery) {
          case 0:
            Schema.sales.update(currentSale._id, {
              $set: {
                submitted: true,
                exported: true
              }
            });
            break;
          case 1:
            Schema.sales.update(currentSale._id, {
              $set: {
                exported: true,
                status: false
              }
            });
            Schema.deliveries.update(currentSale.delivery, {
              $set: {
                status: 3,
                exporter: Meteor.userId()
              }
            });
        }
        return 'create ExportSale';
      } else {
        throw new Meteor.Error('saleExportError', 'Phiếu bán hàng không tồn tại');
      }
    }
  },
  createSaleImport: function(saleId) {
    var currentSale, option, saleDetail, userProfile, _i, _len, _ref;
    if (userProfile = Schema.userProfiles.findOne({
      user: Meteor.userId()
    })) {
      if (currentSale = Schema.sales.findOne({
        _id: saleId,
        merchant: userProfile.currentMerchant,
        status: true,
        received: true,
        exported: true,
        imported: false,
        submitted: false,
        paymentsDelivery: 1
      })) {
        _ref = Schema.saleDetails.find({
          sale: currentSale._id
        }).fetch();
        for (_i = 0, _len = _ref.length; _i < _len; _i++) {
          saleDetail = _ref[_i];
          option = {
            availableQuality: saleDetail.quality,
            inStockQuality: saleDetail.quality
          };
          Schema.productDetails.update(saleDetail.productDetail, {
            $inc: option
          });
          Schema.products.update(saleDetail.product, {
            $inc: option
          });
        }
        MetroSummary.updateMetroSummaryBySaleImport(currentSale._id);
        Schema.sales.update(currentSale._id, {
          $set: {
            imported: true,
            status: false
          }
        });
        Schema.deliveries.update(currentSale.delivery, {
          $set: {
            status: 9,
            importer: Meteor.userId()
          }
        });
        return console.log('create ImportSale');
      } else {
        throw new Meteor.Error('saleImportError', 'Phiếu bán hàng không tồn tại');
      }
    }
  }
});

})();

//# sourceMappingURL=submitExportAndImportOfSale.coffee.js.map

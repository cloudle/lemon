(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({
  registerMerchant: function(email, password, companyName, contactPhone) {
    var merchantId, user, userId, warehouseId;
    userId = Accounts.createUser({
      email: email,
      password: password
    });
    user = Meteor.users.findOne(userId);
    if (!user) {
      throw new Meteor.Error("loi tao tai khoan", "khong the tao tai khoan");
      return;
    }
    merchantId = Schema.merchants.insert({
      owner: userId,
      creator: userId,
      name: companyName
    });
    Schema.merchantPurchases.insert({
      merchant: merchantId,
      merchantRegistered: false,
      user: userId,
      companyName: companyName,
      contactPhone: contactPhone,
      merchantName: 'Trụ Sở',
      warehouseName: 'Kho Trụ Sở'
    });
    warehouseId = Schema.warehouses.insert(Warehouse.newDefault({
      merchantId: merchantId,
      parentMerchantId: merchantId,
      creator: userId,
      name: 'Kho Trụ Sở'
    }));
    Schema.userProfiles.insert({
      user: userId,
      parentMerchant: merchantId,
      currentMerchant: merchantId,
      currentWarehouse: warehouseId,
      isRoot: true,
      systemVersion: Schema.systems.findOne().version
    });
    Schema.metroSummaries.insert(MetroSummary.newByMerchant(merchantId));
    Schema.userSessions.insert({
      user: userId
    });
    return user;
  },
  createMerchantStaff: function(email, password, profile) {
    var user, userId;
    userId = Accounts.createUser({
      email: email,
      password: password
    });
    user = Meteor.users.findOne(userId);
    if (!user) {
      throw new Meteor.Error("loi tao tai khoan", "khong the tao tai khoan");
      return;
    }
    profile.user = userId;
    Schema.userProfiles.insert(profile);
    MetroSummary.updateMetroSummaryByStaff(userId);
    return user;
  }
});

})();

//# sourceMappingURL=merchant.coffee.js.map

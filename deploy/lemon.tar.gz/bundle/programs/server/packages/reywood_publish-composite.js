(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var _ = Package.underscore._;

(function () {

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/reywood:publish-composite/publish_composite.js                                                          //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
Meteor.publishComposite = function(name, options) {                                                                 // 1
    return Meteor.publish(name, function() {                                                                        // 2
        var subscription = new Subscription(this),                                                                  // 3
            instanceOptions = options,                                                                              // 4
            args = Array.prototype.slice.apply(arguments);                                                          // 5
                                                                                                                    // 6
        if (typeof instanceOptions === "function") {                                                                // 7
            instanceOptions = instanceOptions.apply(this, args);                                                    // 8
        }                                                                                                           // 9
                                                                                                                    // 10
        var pub = new Publication(subscription, instanceOptions);                                                   // 11
        pub.publish();                                                                                              // 12
                                                                                                                    // 13
        this.onStop(function() {                                                                                    // 14
            pub.unpublish();                                                                                        // 15
        });                                                                                                         // 16
                                                                                                                    // 17
        this.ready();                                                                                               // 18
    });                                                                                                             // 19
};                                                                                                                  // 20
                                                                                                                    // 21
                                                                                                                    // 22
var Subscription = function(meteorSub) {                                                                            // 23
    var self = this;                                                                                                // 24
    this.meteorSub = meteorSub;                                                                                     // 25
    this.docHash = {};                                                                                              // 26
    this.refCounter = new DocumentRefCounter({                                                                      // 27
        onChange: function(collectionName, docId, refCount) {                                                       // 28
            debugLog("Subscription.refCounter.onChange", collectionName + ":" + docId.valueOf() + " " + refCount);  // 29
            if (refCount <= 0) {                                                                                    // 30
                meteorSub.removed(collectionName, docId);                                                           // 31
                self._removeDocHash(docId);                                                                         // 32
            }                                                                                                       // 33
        }                                                                                                           // 34
    });                                                                                                             // 35
};                                                                                                                  // 36
                                                                                                                    // 37
Subscription.prototype.added = function(collectionName, doc) {                                                      // 38
    this.refCounter.increment(collectionName, doc._id);                                                             // 39
                                                                                                                    // 40
    if (this._hasDocChanged(doc._id, doc)) {                                                                        // 41
        debugLog("Subscription.added", collectionName + ":" + doc._id);                                             // 42
        this.meteorSub.added(collectionName, doc._id, doc);                                                         // 43
        this._addDocHash(doc);                                                                                      // 44
    }                                                                                                               // 45
};                                                                                                                  // 46
                                                                                                                    // 47
Subscription.prototype.changed = function(collectionName, id, changes) {                                            // 48
    if (this._hasDocChanged(id, changes)) {                                                                         // 49
        debugLog("Subscription.changed", collectionName + ":" + id);                                                // 50
        this.meteorSub.changed(collectionName, id, changes);                                                        // 51
        this._updateDocHash(id, changes);                                                                           // 52
    }                                                                                                               // 53
};                                                                                                                  // 54
                                                                                                                    // 55
Subscription.prototype.removed = function(collectionName, docId) {                                                  // 56
    debugLog("Subscription.removed", collectionName + ":" + docId.valueOf());                                       // 57
    this.refCounter.decrement(collectionName, docId);                                                               // 58
};                                                                                                                  // 59
                                                                                                                    // 60
Subscription.prototype._addDocHash = function(doc) {                                                                // 61
    this.docHash[doc._id.valueOf()] = doc;                                                                          // 62
};                                                                                                                  // 63
                                                                                                                    // 64
Subscription.prototype._updateDocHash = function(id, changes) {                                                     // 65
    var key = id.valueOf();                                                                                         // 66
    var existingDoc = this.docHash[key] || {};                                                                      // 67
    this.docHash[key] = _.extend(existingDoc, changes);                                                             // 68
};                                                                                                                  // 69
                                                                                                                    // 70
Subscription.prototype._hasDocChanged = function(id, doc) {                                                         // 71
    var existingDoc = this.docHash[id.valueOf()];                                                                   // 72
                                                                                                                    // 73
    if (!existingDoc) { return true; }                                                                              // 74
                                                                                                                    // 75
    for (var i in doc) {                                                                                            // 76
        if (doc.hasOwnProperty(i) && !_.isEqual(doc[i], existingDoc[i])) {                                          // 77
            return true;                                                                                            // 78
        }                                                                                                           // 79
    }                                                                                                               // 80
                                                                                                                    // 81
    return false;                                                                                                   // 82
};                                                                                                                  // 83
                                                                                                                    // 84
Subscription.prototype._removeDocHash = function(docId) {                                                           // 85
    delete this.docHash[docId.valueOf()];                                                                           // 86
};                                                                                                                  // 87
                                                                                                                    // 88
                                                                                                                    // 89
                                                                                                                    // 90
var Publication = function(subscription, options, args) {                                                           // 91
    this.subscription = subscription;                                                                               // 92
    this.options = options;                                                                                         // 93
    this.args = args || [];                                                                                         // 94
    this.children = options.children || [];                                                                         // 95
    this.childPublications = [];                                                                                    // 96
    this.collectionName = options.collectionName;                                                                   // 97
};                                                                                                                  // 98
                                                                                                                    // 99
Publication.prototype.publish = function() {                                                                        // 100
    this.cursor = this._getCursor();                                                                                // 101
                                                                                                                    // 102
    if (!this.cursor) { return; }                                                                                   // 103
                                                                                                                    // 104
    var collectionName = this._getCollectionName();                                                                 // 105
    var self = this;                                                                                                // 106
                                                                                                                    // 107
    this.observeHandle = this.cursor.observe({                                                                      // 108
        added: function(doc) {                                                                                      // 109
            var alreadyPublished = !!self.childPublications[doc._id];                                               // 110
                                                                                                                    // 111
            if (alreadyPublished) {                                                                                 // 112
                debugLog("Publication.observeHandle.added", collectionName + ":" + doc._id + " already published"); // 113
                self.subscription.changed(collectionName, doc._id, doc);                                            // 114
                self._republishChildrenOf(doc);                                                                     // 115
            } else {                                                                                                // 116
                self.subscription.added(collectionName, doc);                                                       // 117
                self._publishChildrenOf(doc);                                                                       // 118
            }                                                                                                       // 119
        },                                                                                                          // 120
        changed: function(newDoc) {                                                                                 // 121
            debugLog("Publication.observeHandle.changed", collectionName + ":" + newDoc._id);                       // 122
            self._republishChildrenOf(newDoc);                                                                      // 123
        },                                                                                                          // 124
        removed: function(doc) {                                                                                    // 125
            debugLog("Publication.observeHandle.removed", collectionName + ":" + doc._id);                          // 126
            self._unpublishChildrenOf(doc._id);                                                                     // 127
            self.subscription.removed(collectionName, doc._id);                                                     // 128
        }                                                                                                           // 129
    });                                                                                                             // 130
                                                                                                                    // 131
    this.observeChangesHandle = this.cursor.observeChanges({                                                        // 132
        changed: function(id, fields) {                                                                             // 133
            debugLog("Publication.observeChangesHandle.changed", collectionName + ":" + id);                        // 134
            self.subscription.changed(collectionName, id, fields);                                                  // 135
        }                                                                                                           // 136
    });                                                                                                             // 137
};                                                                                                                  // 138
                                                                                                                    // 139
Publication.prototype.unpublish = function() {                                                                      // 140
    this._stopObservingCursor();                                                                                    // 141
    this._removeAllCursorDocuments();                                                                               // 142
    this._unpublishChildPublications();                                                                             // 143
};                                                                                                                  // 144
                                                                                                                    // 145
Publication.prototype._republish = function() {                                                                     // 146
    var collectionName = this._getCollectionName();                                                                 // 147
    var oldPublishedIds = this._getPublishedIds();                                                                  // 148
                                                                                                                    // 149
    debugLog("Publication._republish", "stop observing old cursor");                                                // 150
    this._stopObservingCursor();                                                                                    // 151
                                                                                                                    // 152
    debugLog("Publication._republish", "run .publish again");                                                       // 153
    this.publish();                                                                                                 // 154
                                                                                                                    // 155
    var newPublishedIds = this._getPublishedIds();                                                                  // 156
    var docsToRemove = _.difference(oldPublishedIds, newPublishedIds);                                              // 157
                                                                                                                    // 158
    debugLog("Publication._republish", "unpublish docs from old cursor, " + JSON.stringify(docsToRemove));          // 159
    _.each(docsToRemove, function(docId) {                                                                          // 160
        this._unpublishChildrenOf(docId);                                                                           // 161
        this.subscription.removed(collectionName, docId);                                                           // 162
    }, this);                                                                                                       // 163
};                                                                                                                  // 164
                                                                                                                    // 165
Publication.prototype._getCursor = function() {                                                                     // 166
    return this.options.find.apply(this.subscription.meteorSub, this.args);                                         // 167
};                                                                                                                  // 168
                                                                                                                    // 169
Publication.prototype._getCollectionName = function() {                                                             // 170
    return this.collectionName || (this.cursor && this.cursor._getCollectionName());                                // 171
};                                                                                                                  // 172
                                                                                                                    // 173
Publication.prototype._publishChildrenOf = function(doc) {                                                          // 174
    this.childPublications[doc._id] = [];                                                                           // 175
                                                                                                                    // 176
    _.each(this.children, function(options) {                                                                       // 177
        var pub = new Publication(this.subscription, options, [ doc ].concat(this.args));                           // 178
        this.childPublications[doc._id].push(pub);                                                                  // 179
        pub.publish();                                                                                              // 180
    }, this);                                                                                                       // 181
};                                                                                                                  // 182
                                                                                                                    // 183
Publication.prototype._republishChildrenOf = function(doc) {                                                        // 184
    if (this.childPublications[doc._id]) {                                                                          // 185
        _.each(this.childPublications[doc._id], function(pub) {                                                     // 186
            pub.args[0] = doc;                                                                                      // 187
            pub._republish();                                                                                       // 188
        });                                                                                                         // 189
    }                                                                                                               // 190
};                                                                                                                  // 191
                                                                                                                    // 192
Publication.prototype._unpublishChildrenOf = function(docId) {                                                      // 193
    docId = docId.valueOf();                                                                                        // 194
                                                                                                                    // 195
    debugLog("Publication._unpublishChildrenOf", "unpublishing children of " + this._getCollectionName() + ":" + docId);
    if (this.childPublications[docId]) {                                                                            // 197
        _.each(this.childPublications[docId], function(pub) {                                                       // 198
            pub.unpublish();                                                                                        // 199
        });                                                                                                         // 200
    }                                                                                                               // 201
    delete this.childPublications[docId];                                                                           // 202
};                                                                                                                  // 203
                                                                                                                    // 204
Publication.prototype._removeAllCursorDocuments = function() {                                                      // 205
    if (!this.cursor) { return; }                                                                                   // 206
                                                                                                                    // 207
    var collectionName = this._getCollectionName();                                                                 // 208
                                                                                                                    // 209
    this.cursor.rewind();                                                                                           // 210
    this.cursor.forEach(function(doc) {                                                                             // 211
        this.subscription.removed(collectionName, doc._id);                                                         // 212
    }, this);                                                                                                       // 213
};                                                                                                                  // 214
                                                                                                                    // 215
Publication.prototype._unpublishChildPublications = function() {                                                    // 216
    for (var docId in this.childPublications) {                                                                     // 217
        this._unpublishChildrenOf(docId);                                                                           // 218
        delete this.childPublications[docId];                                                                       // 219
    }                                                                                                               // 220
};                                                                                                                  // 221
                                                                                                                    // 222
Publication.prototype._getPublishedIds = function() {                                                               // 223
    if (this.cursor) {                                                                                              // 224
        this.cursor.rewind();                                                                                       // 225
        return this.cursor.map(function(doc) { return doc._id; });                                                  // 226
    } else {                                                                                                        // 227
        return [];                                                                                                  // 228
    }                                                                                                               // 229
};                                                                                                                  // 230
                                                                                                                    // 231
Publication.prototype._stopObservingCursor = function() {                                                           // 232
    if (this.observeHandle) {                                                                                       // 233
        this.observeHandle.stop();                                                                                  // 234
        delete this.observeHandle;                                                                                  // 235
    }                                                                                                               // 236
                                                                                                                    // 237
    if (this.observeChangesHandle) {                                                                                // 238
        this.observeChangesHandle.stop();                                                                           // 239
        delete this.observeChangesHandle;                                                                           // 240
    }                                                                                                               // 241
};                                                                                                                  // 242
                                                                                                                    // 243
                                                                                                                    // 244
var DocumentRefCounter = function(observer) {                                                                       // 245
    this.heap = {};                                                                                                 // 246
    this.observer = observer;                                                                                       // 247
};                                                                                                                  // 248
                                                                                                                    // 249
DocumentRefCounter.prototype.increment = function(collectionName, docId) {                                          // 250
    var key = collectionName + ":" + docId.valueOf();                                                               // 251
    if (!this.heap[key]) {                                                                                          // 252
        this.heap[key] = 0;                                                                                         // 253
    }                                                                                                               // 254
    this.heap[key]++;                                                                                               // 255
};                                                                                                                  // 256
                                                                                                                    // 257
DocumentRefCounter.prototype.decrement = function(collectionName, docId) {                                          // 258
    var key = collectionName + ":" + docId.valueOf();                                                               // 259
    if (this.heap[key]) {                                                                                           // 260
        this.heap[key]--;                                                                                           // 261
                                                                                                                    // 262
        this.observer.onChange(collectionName, docId, this.heap[key]);                                              // 263
    }                                                                                                               // 264
};                                                                                                                  // 265
                                                                                                                    // 266
                                                                                                                    // 267
var enableDebugLogging = false;                                                                                     // 268
var debugLog = enableDebugLogging ? function(source, message) {                                                     // 269
    while (source.length < 35) { source += " "; }                                                                   // 270
    console.log("[" + source + "] " + message);                                                                     // 271
} : function() { };                                                                                                 // 272
                                                                                                                    // 273
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['reywood:publish-composite'] = {};

})();

//# sourceMappingURL=reywood_publish-composite.js.map

(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var RoutePolicy = Package.routepolicy.RoutePolicy;
var EJSON = Package.ejson.EJSON;
var _ = Package.underscore._;

/* Package-scope variables */
var Inject, id;

(function () {

///////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                           //
// packages/meteorhacks:inject-initial/lib/inject-server.js                                  //
//                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////
                                                                                             //
Inject = {                                                                                   // 1
  // stores in a script type=application/ejson tag, accessed with Injected.obj('id')         // 2
  obj: function(id, data, res) {                                                             // 3
    this._checkForObjOrFunction(data,                                                        // 4
      'Inject.obj(id, data [,res]) expects `data` to be an Object or Function');             // 5
                                                                                             // 6
    if (res) {                                                                               // 7
      this._resAssign(res, 'objList', id, data);                                             // 8
    } else {                                                                                 // 9
      this.objList[id] = data;                                                               // 10
    }                                                                                        // 11
  },                                                                                         // 12
  objList: {},                                                                               // 13
                                                                                             // 14
  // Inserts a META called `id`, whose `content` can be accessed with Injected.meta()        // 15
  meta: function(id, data, res) {                                                            // 16
    this._checkForTextOrFunction(data,                                                       // 17
      'Inject.meta(id, data [,res]) expects `data` to be an String or Function');            // 18
                                                                                             // 19
    if (res) {                                                                               // 20
      this._resAssign(res, 'metaList', id, data);                                            // 21
    } else {                                                                                 // 22
      this.metaList[id] = data;                                                              // 23
    }                                                                                        // 24
  },                                                                                         // 25
  metaList: {},                                                                              // 26
                                                                                             // 27
  rawHead: function(id, textOrFunc, res) {                                                   // 28
    this._checkForTextOrFunction(textOrFunc,                                                 // 29
      'Inject.rawHead(id, content [,res]) expects `content` to be an String or Function');   // 30
                                                                                             // 31
    if (res) {                                                                               // 32
      this._resAssign(res, 'rawHeads', id, textOrFunc);                                      // 33
    } else {                                                                                 // 34
      this.rawHeads[id] = textOrFunc;                                                        // 35
    }                                                                                        // 36
  },                                                                                         // 37
  rawHeads: {},                                                                              // 38
                                                                                             // 39
  rawBody: function(id, textOrFunc, res) {                                                   // 40
    this._checkForTextOrFunction(textOrFunc,                                                 // 41
      'Inject.rawBody(id, content [,res]) expects `content` to be an String or Function');   // 42
                                                                                             // 43
    if (res) {                                                                               // 44
      this._resAssign(res, 'rawBodies', id, textOrFunc);                                     // 45
    } else {                                                                                 // 46
      this.rawBodies[id] = textOrFunc;                                                       // 47
    }                                                                                        // 48
  },                                                                                         // 49
  rawBodies: {},                                                                             // 50
                                                                                             // 51
  // The callback receives the entire HTML page and must return a modified version           // 52
  rawModHtml: function(id, func) {                                                           // 53
    if (!_.isFunction(func)) {                                                               // 54
      var message = 'Inject func id "' + id + '" should be a function, not ' + typeof(func); // 55
      throw new Error(message);                                                              // 56
    }                                                                                        // 57
                                                                                             // 58
    this.rawModHtmlFuncs[id] = func;                                                         // 59
  },                                                                                         // 60
  rawModHtmlFuncs: {},                                                                       // 61
                                                                                             // 62
  _injectObjects: function(html, res) {                                                      // 63
    var objs = _.extend({}, Inject.objList, res.Inject && res.Inject.objList);               // 64
    if (_.isEmpty(objs)) {                                                                   // 65
      return html;                                                                           // 66
    }                                                                                        // 67
                                                                                             // 68
    var obj, injectHtml = '';                                                                // 69
    for (id in objs) {                                                                       // 70
      obj = _.isFunction(objs[id]) ? objs[id](res) : objs[id];                               // 71
      injectHtml += "  <script id='" + id.replace("'", '&apos;')                             // 72
        + "' type='application/ejson'>" + EJSON.stringify(obj)                               // 73
        + "</script>\n";                                                                     // 74
    }                                                                                        // 75
                                                                                             // 76
    return html.replace('<head>', '<head>\n' + injectHtml);                                  // 77
  },                                                                                         // 78
                                                                                             // 79
  _injectMeta: function(html, res) {                                                         // 80
    var metas = _.extend({}, Inject.metaList, res.Inject && res.Inject.metaList);            // 81
    if (_.isEmpty(metas))                                                                    // 82
      return html;                                                                           // 83
                                                                                             // 84
    var injectHtml = '';                                                                     // 85
    for (id in metas) {                                                                      // 86
      var meta = this._evalToText(metas[id], res, html);                                     // 87
      injectHtml += "  <meta id='" + id.replace("'", '&apos;')                               // 88
        + "' content='" + meta.replace("'", '&apos;') + "'>\n", res;                         // 89
    }                                                                                        // 90
                                                                                             // 91
    return html.replace('<head>', '<head>\n' + injectHtml);                                  // 92
  },                                                                                         // 93
                                                                                             // 94
  _injectHeads: function(html, res) {                                                        // 95
    var heads = _.extend({}, Inject.rawHeads, res.Inject && res.Inject.rawHeads);            // 96
    if (_.isEmpty(heads))                                                                    // 97
      return html;                                                                           // 98
                                                                                             // 99
    var injectHtml = '';                                                                     // 100
    for (id in heads) {                                                                      // 101
      var head = this._evalToText(heads[id], res, html);                                     // 102
      injectHtml += head + '\n';                                                             // 103
    }                                                                                        // 104
                                                                                             // 105
    return html.replace('<head>', '<head>\n' + injectHtml);                                  // 106
  },                                                                                         // 107
                                                                                             // 108
  _injectBodies: function(html, res) {                                                       // 109
    var bodies = _.extend({}, Inject.rawBodies, res.Inject && res.Inject.rawBodies);         // 110
    if (_.isEmpty(bodies))                                                                   // 111
      return html;                                                                           // 112
                                                                                             // 113
    var injectHtml = '';                                                                     // 114
    for (id in bodies) {                                                                     // 115
      var body = this._evalToText(bodies[id], res, html);                                    // 116
      injectHtml += body + '\n';                                                             // 117
    }                                                                                        // 118
                                                                                             // 119
    return html.replace('<body>', '<body>\n' + injectHtml);                                  // 120
  },                                                                                         // 121
                                                                                             // 122
  // ensure object exists and store there                                                    // 123
  _resAssign: function(res, key, id, value) {                                                // 124
    if (!res.Inject)                                                                         // 125
      res.Inject = {};                                                                       // 126
    if (!res.Inject[key])                                                                    // 127
      res.Inject[key] = {};                                                                  // 128
    res.Inject[key][id] = value;                                                             // 129
  },                                                                                         // 130
                                                                                             // 131
  _checkForTextOrFunction: function (arg, message) {                                         // 132
    if(!(_.isString(arg) || _.isFunction(arg))) {                                            // 133
      throw new Error(message);                                                              // 134
    }                                                                                        // 135
  },                                                                                         // 136
                                                                                             // 137
  _checkForObjOrFunction: function (arg, message) {                                          // 138
    if(!(_.isObject(arg) || _.isFunction(arg))) {                                            // 139
      throw new Error(message);                                                              // 140
    }                                                                                        // 141
  },                                                                                         // 142
                                                                                             // 143
  // we don't handle errors here. Let them to handle in a higher level                       // 144
  _evalToText: function(textOrFunc, res, html) {                                             // 145
    if(_.isFunction(textOrFunc)) {                                                           // 146
      return textOrFunc(res, html);                                                          // 147
    } else {                                                                                 // 148
      return textOrFunc;                                                                     // 149
    }                                                                                        // 150
  }                                                                                          // 151
};                                                                                           // 152
                                                                                             // 153
Inject.rawModHtml('injectHeads', Inject._injectHeads.bind(Inject));                          // 154
Inject.rawModHtml('injectMeta', Inject._injectMeta.bind(Inject));                            // 155
Inject.rawModHtml('injectBodies', Inject._injectBodies.bind(Inject));                        // 156
Inject.rawModHtml('injectObjects', Inject._injectObjects.bind(Inject));                      // 157
                                                                                             // 158
///////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                           //
// packages/meteorhacks:inject-initial/lib/inject-core.js                                    //
//                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////
                                                                                             //
// Hijack core node API and attach data to the response dynamically                          // 1
// We are simply using this hack because, there is no way to alter                           // 2
// Meteor's html content on the server side                                                  // 3
                                                                                             // 4
var http = Npm.require('http');                                                              // 5
                                                                                             // 6
var originalWrite = http.OutgoingMessage.prototype.write;                                    // 7
http.OutgoingMessage.prototype.write = function(chunk, encoding) {                           // 8
  //prevent hijacking other http requests                                                    // 9
  if(!this.iInjected &&                                                                      // 10
    encoding === undefined && /^<!DOCTYPE html>/.test(chunk)) {                              // 11
    chunk = chunk.toString();                                                                // 12
                                                                                             // 13
    for (id in Inject.rawModHtmlFuncs) {                                                     // 14
      chunk = Inject.rawModHtmlFuncs[id](chunk, this);                                       // 15
      if (!_.isString(chunk)) {                                                              // 16
        throw new Error('Inject func id "' + id + '" must return HTML, not '                 // 17
          + typeof(chunk) + '\n' + JSON.stringify(chunk, null, 2));                          // 18
      }                                                                                      // 19
    }                                                                                        // 20
                                                                                             // 21
                                                                                             // 22
    this.iInjected = true;                                                                   // 23
  }                                                                                          // 24
                                                                                             // 25
  originalWrite.call(this, chunk, encoding);                                                 // 26
};                                                                                           // 27
                                                                                             // 28
//meteor algorithm to check if this is a meteor serving http request or not                  // 29
Inject.appUrl = function(url) {                                                              // 30
  if (url === '/favicon.ico' || url === '/robots.txt')                                       // 31
    return false;                                                                            // 32
                                                                                             // 33
  // NOTE: app.manifest is not a web standard like favicon.ico and                           // 34
  // robots.txt. It is a file id we have chosen to use for HTML5                             // 35
  // appcache URLs. It is included here to prevent using an appcache                         // 36
  // then removing it from poisoning an app permanently. Eventually,                         // 37
  // once we have server side routing, this won't be needed as                               // 38
  // unknown URLs with return a 404 automatically.                                           // 39
  if (url === '/app.manifest')                                                               // 40
    return false;                                                                            // 41
                                                                                             // 42
  // Avoid serving app HTML for declared routes such as /sockjs/.                            // 43
  if (typeof(RoutePolicy) != 'undefined' && RoutePolicy.classify(url))                       // 44
    return false;                                                                            // 45
                                                                                             // 46
  // we currently return app HTML on all URLs by default                                     // 47
  return true;                                                                               // 48
};                                                                                           // 49
                                                                                             // 50
///////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['meteorhacks:inject-initial'] = {
  Inject: Inject
};

})();

//# sourceMappingURL=meteorhacks_inject-initial.js.map

(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['jnoble:multi-styl'] = {};

})();

//# sourceMappingURL=jnoble_multi-styl.js.map

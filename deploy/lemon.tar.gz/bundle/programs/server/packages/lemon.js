(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var _ = Package.underscore._;
var SubsManager = Package['meteorhacks:subs-manager'].SubsManager;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;

/* Package-scope variables */
var __coffeescriptShare;

(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/lemon/namespace.coffee.js                                                                              //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
this.lemon = {};

this.Apps = {};

this.simpleSchema = {};

this.Schema = {};

this.db = {};

this.logics = {};

this.modulus = {};

modulus.seedScripts = [];

modulus.routes = [];

this.Apps = {};

Apps.Merchant = {};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/lemon/core/core.coffee.js                                                                              //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var goldenRatio,
  __slice = [].slice;

lemon.log = function() {
  var now, params;
  params = 1 <= arguments.length ? __slice.call(arguments, 0) : [];
  now = new Date();
  params.unshift("" + (now.getMinutes()) + ":" + (now.getSeconds()));
  return console.log.apply(console, params);
};

lemon.ExcuteLogics = function() {
  return UserSession.set("ExcuteLogics", Meteor.uuid());
};

lemon.sleep = function(milliseconds) {
  var i, start, _i, _results;
  start = new Date().getTime();
  _results = [];
  for (i = _i = 0; _i <= 10000000; i = ++_i) {
    if ((new Date().getTime() - start) > milliseconds) {
      break;
    } else {
      _results.push(void 0);
    }
  }
  return _results;
};

goldenRatio = 1.618;

lemon.designRatio = {};

lemon.designRatio.baseSize = function(fullSize) {
  return fullSize / goldenRatio;
};

lemon.designRatio.addOnSize = function(baseSize) {
  return baseSize / goldenRatio;
};

lemon.designRatio.fullSize = function(baseSize) {
  return baseSize * goldenRatio;
};

lemon.designRatio.split = function(fullSize) {
  var addOnSize, baseSize;
  baseSize = lemon.designRatio.baseSize(fullSize);
  addOnSize = lemon.designRatio.addOnSize(baseSize);
  return {
    base: baseSize,
    addOn: addOnSize
  };
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/lemon/core/router.coffee.js                                                                            //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
this.lemon.addRoute = function(routes, baseRoute) {
  var route, _i, _len;
  if (baseRoute == null) {
    baseRoute = {};
  }
  if (!Array.isArray(routes)) {
    routes = [routes];
  }
  for (_i = 0, _len = routes.length; _i < _len; _i++) {
    route = routes[_i];
    _.extend(route, baseRoute);
    if (route.waitOnDependency) {
      route.waitOn = function() {
        var item, results, _j, _len1;
        results = lemon.dependencies.resolve(route.waitOnDependency);
        for (_j = 0, _len1 = results.length; _j < _len1; _j++) {
          item = results[_j];
          item.ready();
        }
        return results;
      };
    }
    modulus.routes.push(route);
  }
};

this.lemon.buildRoutes = function(router) {
  var route, template, _i, _len, _ref, _results;
  _ref = modulus.routes;
  _results = [];
  for (_i = 0, _len = _ref.length; _i < _len; _i++) {
    route = _ref[_i];
    template = void 0;
    if (route.template && route.path) {
      template = route.template;
      delete route.template;
    } else if (route.template) {
      template = route.template;
      delete route.template;
      route.path = "/" + template;
    } else if (route.path) {
      template = route.path.substring(1);
    }
    if (template) {
      _results.push(router.route(template, route));
    } else {
      _results.push(void 0);
    }
  }
  return _results;
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/lemon/core/apps.coffee.js                                                                              //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Apps.setupHistories = [];

Apps.setup = function(scope, initializers, appName) {
  var init, _i, _len;
  if (!initializers || !Array.isArray(initializers) || _.contains(Apps.setupHistories, appName)) {
    return;
  }
  for (_i = 0, _len = initializers.length; _i < _len; _i++) {
    init = initializers[_i];
    if (typeof init === 'function') {
      init(scope);
    }
  }
  if (appName) {
    return Apps.setupHistories.push(appName);
  }
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/lemon/core/dependency.coffee.js                                                                        //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var recursiveResolve;

lemon.dependencies = {};

lemon.dependencies.add = function(name, deps) {
  return lemon.dependencies[name] = deps;
};

lemon.dependencies.list = function(dep) {
  var name, value, _ref;
  if (dep == null) {
    dep = void 0;
  }
  if (dep && lemon.dependencies[dep]) {
    console.log(recursiveResolve(lemon.dependencies[dep]));
  } else {
    _ref = lemon.dependencies;
    for (name in _ref) {
      value = _ref[name];
      if (Array.isArray(value)) {
        console.log(name, value);
      }
    }
  }
};

lemon.dependencies.resolve = function(name) {
  var dep, dependencies, subscriptions, _i, _len;
  if (!lemon.dependencies[name]) {
    return;
  }
  dependencies = recursiveResolve(lemon.dependencies[name]);
  subscriptions = [];
  for (_i = 0, _len = dependencies.length; _i < _len; _i++) {
    dep = dependencies[_i];
    if (typeof dep === 'string') {
      subscriptions.push(Meteor.subscribe.call(Meteor, dep));
    } else if (Array.isArray(dep)) {
      subscriptions.push(Meteor.subscribe.apply(Meteor, dep));
    }
  }
  return subscriptions;
};

recursiveResolve = function(nextDep, currentDeps) {
  var dep, _i, _len;
  if (currentDeps == null) {
    currentDeps = [];
  }
  for (_i = 0, _len = nextDep.length; _i < _len; _i++) {
    dep = nextDep[_i];
    if (_.findWhere(currentDeps, dep)) {
      continue;
    }
    if (lemon.dependencies[dep]) {
      recursiveResolve(lemon.dependencies[dep], currentDeps);
    } else {
      currentDeps.push(dep);
    }
  }
  return currentDeps;
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/lemon/core/validation.coffee.js                                                                        //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
this.Validation = {};

Validation.isEmail = function(email) {
  var reg, reg1;
  reg = /^\w+[\+\.\w-]*@([\w-]+\.)*\w+[\w-]*\.([a-z]{2,4}|\d+)$/i;
  reg1 = /^[0-9A-Za-z]+[0-9A-Za-z_]*@[\w\d.]+.\w{2,4}$/;
  return reg.test(email);
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/lemon/core/command.coffee.js                                                                           //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.sessionCleanList = ['registerAccountValid', 'registerSecretValid', 'loginValid', 'allowCreateStaffAccount'];

lemon.listSession = function() {
  var key, obj, _ref, _results;
  _ref = Session.keys;
  _results = [];
  for (key in _ref) {
    obj = _ref[key];
    _results.push(console.log(key));
  }
  return _results;
};

lemon.cleanSession = function() {
  var key, obj, _ref, _results;
  console.log('cleaning sessions');
  _ref = Session.keys;
  _results = [];
  for (key in _ref) {
    obj = _ref[key];
    if (_.contains(lemon.sessionCleanList, key)) {
      _results.push(delete Session.keys[key]);
    }
  }
  return _results;
};

lemon.logout = function(redirectUrl) {
  if (redirectUrl == null) {
    redirectUrl = '/';
  }
  Meteor.logout();
  Apps.setupHistories = [];
  lemon.cleanSession();
  return Meteor.setTimeout(function() {
    if (redirectUrl) {
      return Router.go(redirectUrl);
    }
  }, 1000);
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/lemon/core/schema/model.coffee.js                                                                      //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
this.modelBase = (function() {
  function modelBase(data) {
    this.data = data;
    this.id = this.data._id;
  }

  modelBase.create = function(option) {
    return this.schema.insert(option);
  };

  modelBase.findOne = function(option) {
    var found;
    found = this.schema.findOne(option);
    if (found) {
      return new this(found);
    }
    return void 0;
  };

  modelBase.find = function(option) {
    var found;
    found = this.schema.find(option);
    if (found) {
      return new this(found);
    }
    return void 0;
  };

  modelBase.remove = function(option) {
    return this.schema.remove(option);
  };

  modelBase.update = function(id, option) {
    return this.schema.update(id, option);
  };

  return modelBase;

})();
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/lemon/core/schema/core.coffee.js                                                                       //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var exceptions, extendObject, generateModel, generateSchema, root,
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

root = typeof global !== "undefined" && global !== null ? global : window;

exceptions = ['helpers'];

extendObject = function(source, destination) {
  var name, value, _ref, _results;
  for (name in source) {
    value = source[name];
    if (!_(exceptions).contains(name)) {
      destination[name] = value;
    }
  }
  _ref = source.prototype;
  _results = [];
  for (name in _ref) {
    value = _ref[name];
    _results.push(destination.prototype[name] = value);
  }
  return _results;
};

generateSchema = function(name) {
  Schema[name] = new Meteor.Collection(name);
  if (typeof extensionObj !== "undefined" && extensionObj !== null ? extensionObj.helpers : void 0) {
    Schema[name].helpers(extensionObj.helpers);
  }
  return Schema[name].attachSchema(simpleSchema[name]);
};

generateModel = function(name, extensionObj) {
  var singularName;
  singularName = extensionObj.name;
  root[singularName] = (function(_super) {
    __extends(_Class, _super);

    function _Class() {
      return _Class.__super__.constructor.apply(this, arguments);
    }

    return _Class;

  })(modelBase);
  extendObject(extensionObj, root[singularName]);
  root[singularName].schema = Schema[name];
  root[singularName].prototype.schema = Schema[name];
  return console.log("added " + singularName);
};

Schema.add = function(name, extensionObj) {
  if (extensionObj == null) {
    extensionObj = void 0;
  }
  generateSchema(name, extensionObj);
  if (extensionObj) {
    return generateModel(name, extensionObj);
  }
};

Schema.list = function() {
  var i, name, value;
  i = 1;
  for (name in Schema) {
    value = Schema[name];
    if (value instanceof Mongo.Collection) {
      console.log("" + i + ". " + name);
      i++;
    }
  }
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/lemon/core/schema/built.in.coffee.js                                                                   //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
simpleSchema.Version = new SimpleSchema({
  createdAt: {
    type: Date,
    autoValue: function() {
      if (this.isInsert) {
        return new Date;
      } else if (this.isUpsert) {
        return {
          $setOnInsert: new Date
        };
      } else {
        this.unset();
      }
    }
  },
  updateAt: {
    type: Date,
    autoValue: function() {
      if (this.isUpdate) {
        return new Date();
      }
    },
    denyInsert: true,
    optional: true
  }
});

simpleSchema.Location = new SimpleSchema({
  address: {
    type: [String],
    optional: true
  },
  areas: {
    type: [String],
    optional: true
  }
});

simpleSchema.ChildProduct = new SimpleSchema({
  product: {
    type: String
  },
  quality: {
    type: Number
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/lemon/core/component/core.coffee.js                                                                    //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var bindingDatePicker, bindingElements, bindingExtras, bindingSwitch, bindingToolTip, toggleExtra;

this.Component = {};

Component.helpers = {};

Component.helpers.arrangeAppLayout = function() {
  var newHeight;
  newHeight = $(window).height() - $("#header").outerHeight() - $("#footer").outerHeight() - 6;
  return $("#container").css('height', newHeight);
};

Component.helpers.invokeIfNeccessary = function(method, context) {
  if (method) {
    return method.apply(context, arguments);
  }
};

Component.helpers.customBinding = function(uiOptions, context) {
  var name, value, _results;
  context.ui = {};
  _results = [];
  for (name in uiOptions) {
    value = uiOptions[name];
    if (typeof value === 'string') {
      _results.push(context.ui[name] = context.find(value));
    }
  }
  return _results;
};

Component.helpers.autoBinding = function(context) {
  var _ref;
  context.ui = (_ref = context.ui) != null ? _ref : {};
  bindingToolTip(context);
  bindingElements(context);
  bindingSwitch(context);
  bindingDatePicker(context);
  return bindingExtras(context);
};

bindingToolTip = function(context) {
  return $("[data-toggle='tooltip']").tooltip({
    container: 'body'
  });
};

bindingElements = function(context) {
  var item, name, _i, _len, _ref, _results;
  _ref = context.findAll("input[name]:not([binding])");
  _results = [];
  for (_i = 0, _len = _ref.length; _i < _len; _i++) {
    item = _ref[_i];
    name = $(item).attr('name');
    context.ui[name] = item;
    _results.push(context.ui["$" + name] = $(item));
  }
  return _results;
};

bindingSwitch = function(context) {
  var item, _i, _len, _ref, _results;
  context["switch"] = {};
  _ref = context.findAll("input[binding='switch'][name]");
  _results = [];
  for (_i = 0, _len = _ref.length; _i < _len; _i++) {
    item = _ref[_i];
    _results.push(context["switch"][$(item).attr('name')] = new Switchery(item));
  }
  return _results;
};

toggleExtra = function(name, context, mode) {
  var currentExtra;
  currentExtra = context.ui.extras[name];
  if (!currentExtra) {
    return;
  }
  if (mode) {
    currentExtra.$element.show();
  } else {
    currentExtra.$element.hide();
  }
  return Component.helpers.arrangeAppLayout();
};

bindingDatePicker = function(context) {
  var $item, item, name, options, _i, _len, _ref, _results;
  context.datePicker = {};
  _ref = context.findAll("[binding='datePicker'][name]");
  _results = [];
  for (_i = 0, _len = _ref.length; _i < _len; _i++) {
    item = _ref[_i];
    $item = $(item);
    name = $item.attr('name');
    options = {};
    options.language = 'vi';
    if ($item.attr('todayHighlight') === true) {
      options.todayHighlight = true;
    }
    $item.datepicker(options);
    _results.push(context.datePicker["$" + name] = $item);
  }
  return _results;
};

bindingExtras = function(context) {
  var $extra, extra, name, visible, _i, _len, _ref, _ref1;
  context.ui.extras = {};
  _ref = context.findAll(".editor-row.extra[name]");
  for (_i = 0, _len = _ref.length; _i < _len; _i++) {
    extra = _ref[_i];
    $extra = $(extra);
    name = $extra.attr('name');
    visible = (_ref1 = $extra.attr('visibility')) != null ? _ref1 : false;
    if (visible) {
      $extra.show();
    }
    context.ui.extras[name] = {
      visibility: visible,
      $element: $extra
    };
  }
  return context.ui.extras.toggleExtra = function(name, mode) {
    if (mode == null) {
      mode = true;
    }
    return toggleExtra(name, context, mode);
  };
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/lemon/core/component/widget.coffee.js                                                                  //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var exceptions, helpers;

helpers = Component.helpers;

exceptions = ['ui', 'rendered'];

lemon.defineWidget = function(source, destination) {
  var name, value;
  for (name in destination) {
    value = destination[name];
    if (!_(exceptions).contains(name)) {
      source[name] = value;
    }
  }
  return source.rendered = function() {
    if (destination.ui) {
      helpers.customBinding(destination.ui, this);
    }
    return helpers.invokeIfNeccessary(destination.rendered, this);
  };
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/lemon/core/component/app.coffee.js                                                                     //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var exceptions, helpers;

helpers = Component.helpers;

exceptions = ['ui', 'rendered'];

lemon.defineApp = function(source, destination) {
  var name, value;
  for (name in destination) {
    value = destination[name];
    if (!_(exceptions).contains(name)) {
      source[name] = value;
    }
  }
  return source.rendered = function() {
    if (destination.ui) {
      helpers.customBinding(destination.ui, this);
    }
    helpers.autoBinding(this);
    helpers.invokeIfNeccessary(destination.rendered, this);
    return helpers.arrangeAppLayout();
  };
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/lemon/system/seeds.coffee.js                                                                           //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var cleanExceptions;

Meteor.methods({
  remmoveCollection: function(collectionName) {
    return Schema[collectionName].remove({});
  },
  removeUserCollection: function() {
    return Meteor.users.remove({});
  }
});

cleanExceptions = ['systems', 'migrations'];

db.clean = function() {
  return zone.run(function() {
    var i, name, value;
    Meteor.call('removeUserCollection');
    i = 1;
    for (name in Schema) {
      value = Schema[name];
      if (!(value instanceof Mongo.Collection && !_(cleanExceptions).contains(name))) {
        continue;
      }
      Meteor.call('remmoveCollection', name);
      i++;
    }
    return console.log("Database clean complete on " + i + " collections");
  });
};

db.seed = function() {
  return zone.run(function() {
    var i, script, _i, _len, _ref;
    i = 0;
    _ref = modulus.seedScripts;
    for (_i = 0, _len = _ref.length; _i < _len; _i++) {
      script = _ref[_i];
      script();
      i++;
    }
    return console.log("Seeding complete, there are " + i + " scripts executed!");
  });
};

db.setup = function() {
  db.clean();
  return db.seed();
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/lemon/system/migrate.coffee.js                                                                         //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
db.migrate = function() {
  return console.log('migrating..');
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/lemon/system/schema/migration.coffee.js                                                                //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
simpleSchema.migrations = new SimpleSchema({
  systemVersion: {
    type: String
  },
  creator: {
    type: String,
    optional: true
  },
  owner: {
    type: String,
    optional: true
  },
  description: {
    type: String
  },
  group: {
    type: [String]
  },
  color: {
    type: String,
    optional: true
  },
  version: {
    type: simpleSchema.Version
  }
});

Schema.add('migrations');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/lemon/system/schema/system.coffee.js                                                                   //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
simpleSchema.systems = new SimpleSchema({
  version: {
    type: String
  },
  updateAt: {
    type: Date,
    autoValue: function() {
      return new Date();
    }
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/lemon/system/system.coffee.js                                                                          //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var System, doneKPIs, finishAfterCurrentVersion, getNextVersion;

finishAfterCurrentVersion = function(currentVersion) {
  return {
    'version.updateAt': {
      $gt: currentVersion.updateAt
    }
  };
};

doneKPIs = {
  status: 'done'
};

getNextVersion = function(currentVersion, step) {
  var nextSubversion, subversion, version;
  subversion = currentVersion.version.substring(2);
  version = currentVersion.version.substring(0, 1);
  nextSubversion = Math.round((Number(subversion) + step) * 10) / 10;
  if (nextSubversion > 10) {
    nextSubversion = Math.round((nextSubversion - 10) * 10) / 10;
    version++;
  }
  return "" + version + "." + nextSubversion;
};

Schema.add('systems', System = (function() {
  function System() {}

  System.init = function() {
    if (Schema.systems.find().count() === 0) {
      return Schema.systems.insert({
        version: '0.0.1'
      });
    }
  };

  System.upgrade = function(step) {
    if (step == null) {
      step = 0.1;
    }
    return zone.run((function(_this) {
      return function() {
        var currentVersion, nextVersion, update, updates, _i, _len;
        currentVersion = _this.schema.findOne();
        nextVersion = getNextVersion(currentVersion, step);
        updates = Schema.kaizens.find({
          $and: [doneKPIs, finishAfterCurrentVersion(currentVersion)]
        }).fetch();
        if (updates.length === 0) {
          return console.log("Upgrading cancelled, there is no change since previous update!");
        } else {
          for (_i = 0, _len = updates.length; _i < _len; _i++) {
            update = updates[_i];
            Schema.migrations.insert({
              systemVersion: nextVersion,
              description: update.description,
              creator: update.creator,
              owner: update.owner,
              group: [update.group]
            });
          }
          _this.schema.update(currentVersion._id, {
            $set: {
              version: nextVersion
            }
          });
          return console.log("System successfully upgraded to version " + nextVersion);
        }
      };
    })(this));
  };

  System.checkUpdates = function() {
    return zone.run((function(_this) {
      return function() {
        var currentVersion, update, updates, _i, _len, _results;
        currentVersion = Schema.systems.findOne();
        updates = Schema.kaizens.find({
          $and: [doneKPIs, finishAfterCurrentVersion(currentVersion)]
        }).fetch();
        console.log("There is " + updates.length + " updates since previous version:");
        _results = [];
        for (_i = 0, _len = updates.length; _i < _len; _i++) {
          update = updates[_i];
          _results.push(console.log("" + update.group + ": " + update.description));
        }
        return _results;
      };
    })(this));
  };

  return System;

})());

if (Meteor.isClient) {
  Meteor.subscribe('system');
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/lemon/system/schema/user.option.coffee.js                                                              //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Schema.userOptions = new Mongo.Collection('userOptions');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/lemon/system/schema/user.session.coffee.js                                                             //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Schema.userSessions = new Mongo.Collection('userSessions');

this.UserSession = {
  set: function(key, value) {
    var found, options, userSession;
    if (!Meteor.userId()) {
      return false;
    }
    options = {};
    options[key] = value;
    found = Schema.userSessions.findOne({
      user: Meteor.userId()
    });
    if (found) {
      return Schema.userSessions.update(found._id, {
        $set: options
      });
    } else {
      options.user = Meteor.userId();
      return userSession = Schema.userSessions.insert(options);
    }
  },
  get: function(key) {
    var _ref;
    return (_ref = Schema.userSessions.findOne({
      user: Meteor.userId()
    })) != null ? _ref[key] : void 0;
  }
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/lemon/system/schema/role.coffee.js                                                                     //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
simpleSchema.roles = new SimpleSchema({
  group: {
    type: String
  },
  parent: {
    type: String,
    optional: true
  },
  creator: {
    type: String,
    optional: true
  },
  name: {
    type: String
  },
  description: {
    type: String,
    optional: true
  },
  roles: {
    type: String,
    optional: true
  },
  permissions: {
    type: [String],
    optional: true
  },
  version: {
    type: simpleSchema.Version
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/lemon/system/role.coffee.js                                                                            //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var Role;

Schema.add('roles', Role = (function() {
  function Role() {}

  Role.addRolesFor = function(profileId, roles) {
    return Schema.userProfiles.update(profileId, {
      $set: {
        roles: roles
      }
    });
  };

  Role.isInRole = function(userId, name) {};

  Role.rolesOf = function(permissions) {
    var role, roles, _i, _len, _ref;
    roles = [];
    _ref = this.schema.find({
      permissions: {
        $elemMatch: {
          $in: [permissions, Apps.Merchant.Permissions.su.key]
        }
      }
    }).fetch();
    for (_i = 0, _len = _ref.length; _i < _len; _i++) {
      role = _ref[_i];
      roles.push(role.name);
    }
    return roles;
  };

  Role.permissionsOf = function(profile) {
    var currentProfile, currentRole, permissions, role, _i, _len, _ref;
    if (typeof profile !== 'string') {
      currentProfile = profile;
    } else {
      currentProfile = Schema.userProfiles.findOne(profile);
      if (!currentProfile) {
        return [];
      }
    }
    permissions = [];
    _ref = currentProfile.roles;
    for (_i = 0, _len = _ref.length; _i < _len; _i++) {
      role = _ref[_i];
      currentRole = this.schema.findOne(role);
      if (currentRole) {
        permissions = _.union(permissions, currentRole.permissions);
      }
    }
    return permissions;
  };

  Role.hasPermission = function(profileId, name) {
    var currentProfile, permissions;
    currentProfile = Schema.userProfiles.findOne(profileId);
    if (!currentProfile) {
      return [];
    }
    permissions = this.permissionsOf(currentProfile);
    return _.contains(currentProfile.roles, 'admin') || _.contains(permissions, name);
  };

  return Role;

})());
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/lemon/system/schema/kaizen.coffee.js                                                                   //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
simpleSchema.kaizens = new SimpleSchema({
  creator: {
    type: String
  },
  owner: {
    type: String,
    optional: true
  },
  group: {
    type: String,
    optional: true
  },
  description: {
    type: String
  },
  priority: {
    type: Number
  },
  totalDuration: {
    type: Number,
    optional: true
  },
  remake: {
    type: Number
  },
  duration: {
    type: Number
  },
  selectDate: {
    type: Date,
    optional: true
  },
  starDate: {
    type: Date,
    optional: true
  },
  finishDate: {
    type: Date,
    optional: true
  },
  lateDuration: {
    type: Boolean
  },
  deleted: {
    type: Boolean
  },
  status: {
    type: String
  },
  version: {
    type: simpleSchema.Version
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/lemon/system/kaizen.coffee.js                                                                          //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var Kaizen;

Schema.add('kaizens', Kaizen = (function() {
  function Kaizen() {}

  Kaizen["new"] = function() {};

  return Kaizen;

})());
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/lemon/notification/schema/notification.coffee.js                                                       //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
simpleSchema.notifications = new SimpleSchema({
  sender: {
    type: String,
    optional: true
  },
  receiver: {
    type: String,
    optional: true
  },
  message: {
    type: String
  },
  isRequest: {
    type: Boolean,
    defaultValue: false
  },
  notificationType: {
    type: String
  },
  characteristic: {
    type: String,
    optional: true
  },
  seen: {
    type: Boolean,
    defaultValue: false
  },
  confirmed: {
    type: Boolean,
    defaultValue: false
  },
  version: {
    type: simpleSchema.Version
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/lemon/notification/notification.coffee.js                                                              //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var Notification;

Schema.add('notifications', Notification = (function() {
  function Notification() {}

  Notification.prototype.dump = "";

  return Notification;

})());
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/lemon/messenger/schema/message.coffee.js                                                               //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
simpleSchema.messages = new SimpleSchema({
  sender: {
    type: String
  },
  receiver: {
    type: String
  },
  message: {
    type: String
  },
  reads: {
    type: [String],
    optional: true
  },
  version: {
    type: simpleSchema.Version
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/lemon/messenger/messenger.coffee.js                                                                    //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var Messenger;

Schema.add('messages', Messenger = (function() {
  function Messenger() {}

  Messenger.say = function(message, receiver) {
    return zone.run((function(_this) {
      return function() {
        return _this.schema.insert({
          sender: Meteor.userId(),
          receiver: receiver,
          message: message
        });
      };
    })(this));
  };

  Messenger.read = function(messageId) {
    return zone.run((function(_this) {
      return function() {
        var currentMessage;
        currentMessage = _this.schema.findOne(messageId);
        if (currentMessage) {
          return _this.schema.update(messageId, {
            $push: {
              reads: Meteor.userId()
            }
          });
        }
      };
    })(this));
  };

  return Messenger;

})());
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package.lemon = {};

})();

//# sourceMappingURL=lemon.js.map

(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['lemon-icon'] = {};

})();

//# sourceMappingURL=lemon-icon.js.map

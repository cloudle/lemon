(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['multiply:iron-router-progress'] = {};

})();

//# sourceMappingURL=multiply_iron-router-progress.js.map

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Apps.Merchant.salesInit.push(function() {
  return logics.sales.selectOrder = function(orderId) {
    return UserSession.set('currentOrder', orderId);
  };
});

})();

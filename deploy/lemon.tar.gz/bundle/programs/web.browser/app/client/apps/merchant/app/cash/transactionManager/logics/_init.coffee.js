(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
logics.transactionManager = {
  newTransaction: {}
};

Apps.Merchant.transactionManagerInit = [];

Apps.Merchant.transactionManagerReactiveRun = [];

Apps.Merchant.transactionManagerInit.push(function(scope) {
  Session.setDefault('receivable', '0');
  Session.setDefault('transactionFilter', '1');
  Session.setDefault('createNewTransaction', {
    customerId: 'skyReset',
    description: '',
    totalCash: 0,
    depositCash: 0,
    maxCash: 0
  });
  return logics.transactionManager.availableCustomers = [];
});

Apps.Merchant.transactionManagerReactiveRun.push(function(scope) {
  var merchant, receivableFilter, transaction, transactionFilter, _ref;
  if (Session.get('myProfile') && Session.get('receivable') && Session.get('transactionFilter')) {
    merchant = {
      merchant: Session.get('myProfile').currentMerchant
    };
    receivableFilter = Session.get('receivable') === '0' ? {
      receivable: true
    } : {
      receivable: false
    };
    transactionFilter = (function() {
      switch (Session.get('transactionFilter')) {
        case '1':
          return {
            debitCash: {
              $gt: 0
            }
          };
        case '2':
          return {
            debitCash: {
              $gt: 0
            }
          };
        case '3':
          return {
            debitCash: 0
          };
      }
    })();
    transaction = Schema.transactions.find({
      $and: [merchant, receivableFilter, transactionFilter]
    });
    logics.transactionManager.transactionDetailFilter = transaction;
  }
  Session.set('currentTransaction', Schema.transactions.findOne((_ref = Session.get('currentTransaction')) != null ? _ref._id : void 0));
  if (Session.get('currentTransaction')) {
    scope.transactionDetails = Schema.transactionDetails.find({
      transaction: Session.get('currentTransaction')._id
    });
  }
  if (Session.get('unSecureMode')) {
    return Session.set('currentSelectCustomer');
  } else {

  }
});

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var formatSaleReturnSearch;

formatSaleReturnSearch = function(item) {
  if (item.status) {
    return "" + item.orderCode + " [Chưa trả] ";
  } else {
    return "" + item.orderCode + " [Đang trả] ";
  }
};

Apps.Merchant.returnsInit.push(function(scope) {
  return logics.returns.saleSelectOptions = {
    query: function(query) {
      return query.callback({
        results: _.filter(logics.returns.availableSales.fetch(), function(item) {
          var unsignedName, unsignedTerm;
          unsignedTerm = Helpers.RemoveVnSigns(query.term);
          unsignedName = Helpers.RemoveVnSigns(item.orderCode);
          return unsignedName.indexOf(unsignedTerm) > -1;
        }),
        text: 'orderCode'
      });
    },
    initSelection: function(element, callback) {
      var _ref;
      return callback((_ref = logics.returns.currentSale) != null ? _ref : 'skyReset');
    },
    reactiveValueGetter: function() {
      var _ref;
      return (_ref = logics.returns.currentSale) != null ? _ref : 'skyReset';
    },
    changeAction: function(e) {
      var saleDetail;
      UserSession.set('currentSale', e.added._id);
      if (!(Schema.sales.findOne(e.added._id)).currentProductDetail) {
        if (saleDetail = Schema.saleDetails.findOne({
          sale: e.added._id
        })) {
          return Schema.sales.update(e.added._id, {
            $set: {
              currentProductDetail: saleDetail._id,
              currentQuality: 1
            }
          });
        }
      }
    },
    formatSelection: formatSaleReturnSearch,
    formatResult: formatSaleReturnSearch,
    id: '_id',
    placeholder: 'CHỌN PHIẾU BÁN HÀNG'
  };
});

})();

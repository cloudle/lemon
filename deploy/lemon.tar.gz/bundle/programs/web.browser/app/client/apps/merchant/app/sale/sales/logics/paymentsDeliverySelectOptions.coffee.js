(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var changedActionSelectPaymentsDelivery, formatPaymentMethodSearch;

formatPaymentMethodSearch = function(item) {
  if (item) {
    return "" + item.display;
  }
};

changedActionSelectPaymentsDelivery = function(paymentsDelivery, currentOrder) {
  var customer, option, _ref, _ref1, _ref2;
  option = {
    paymentsDelivery: paymentsDelivery
  };
  if (paymentsDelivery === 1) {
    if (customer = Schema.customers.findOne(currentOrder.buyer)) {
      option.contactName = (_ref = customer.name) != null ? _ref : null;
      option.contactPhone = (_ref1 = customer.phone) != null ? _ref1 : null;
      option.deliveryAddress = (_ref2 = customer.address) != null ? _ref2 : null;
      option.comment = 'Giao trong ngày';
      option.deliveryDate = new Date;
      $("[name=deliveryDate]").datepicker('setDate', option.deliveryDate);
    } else {
      console.log('Sai customer');
      return;
    }
  }
  return Schema.orders.update(currentOrder._id, {
    $set: option
  });
};

Apps.Merchant.salesInit.push(function() {
  return logics.sales.paymentsDeliverySelectOptions = {
    query: function(query) {
      return query.callback({
        results: Apps.Merchant.DeliveryTypes,
        text: 'id'
      });
    },
    initSelection: function(element, callback) {
      var _ref;
      return callback(_.findWhere(Apps.Merchant.DeliveryTypes, {
        _id: (_ref = Session.get('currentOrder')) != null ? _ref.paymentsDelivery : void 0
      }));
    },
    formatSelection: formatPaymentMethodSearch,
    formatResult: formatPaymentMethodSearch,
    placeholder: 'CHỌN SẢN PTGD',
    minimumResultsForSearch: -1,
    changeAction: function(e) {
      return changedActionSelectPaymentsDelivery(e.added._id, logics.sales.currentOrder);
    },
    reactiveValueGetter: function() {
      var _ref;
      return _.findWhere(Apps.Merchant.DeliveryTypes, {
        _id: (_ref = Session.get('currentOrder')) != null ? _ref.paymentsDelivery : void 0
      });
    }
  };
});

})();

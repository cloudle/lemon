(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var customerManagerRoute;

customerManagerRoute = {
  template: 'customerManager',
  waitOnDependency: 'customerManager',
  onBeforeAction: function() {
    if (this.ready()) {
      Apps.setup(logics.customerManager, Apps.Merchant.customerManagerInit, 'customerManager');
      return this.next();
    }
  },
  data: function() {
    logics.customerManager.reactiveRun();
    return {
      gridOptions: logics.customerManager.gridOptions,
      allowCreate: logics.customerManager.allowCreate
    };
  }
};

lemon.addRoute([customerManagerRoute], Apps.Merchant.RouterBase);

})();

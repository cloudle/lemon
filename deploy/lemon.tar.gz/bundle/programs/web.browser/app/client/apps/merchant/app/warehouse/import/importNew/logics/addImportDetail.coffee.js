(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var checkValidationOption, optionImportDetail, reUpdateImportDetail;

Apps.Merchant.importInit.push(function(scope) {
  return logics["import"].reCalculateImport = function(importId) {
    var currentImport, detail, importDetails, option, totalPrice, _i, _len;
    if (currentImport = Schema.imports.findOne({
      _id: importId,
      warehouse: Session.get('myProfile').currentWarehouse,
      merchant: Session.get('myProfile').currentMerchant
    })) {
      importDetails = Schema.importDetails.find({
        "import": importId
      }).fetch();
      totalPrice = 0;
      if (importDetails.length > 0) {
        for (_i = 0, _len = importDetails.length; _i < _len; _i++) {
          detail = importDetails[_i];
          totalPrice += detail.importQuality * detail.importPrice;
          option = {
            totalPrice: totalPrice,
            deposit: totalPrice,
            debit: 0
          };
        }
      } else {
        option = {
          totalPrice: 0,
          deposit: 0,
          debit: 0
        };
      }
      return Import.update(importId, {
        $set: option
      });
    }
  };
});

reUpdateImportDetail = function(newImportDetail, oldImportDetail) {
  var totalPrice;
  totalPrice = newImportDetail.importQuality * oldImportDetail.importPrice;
  return Schema.importDetails.update(oldImportDetail._id, {
    $inc: {
      importQuality: newImportDetail.importQuality,
      totalPrice: totalPrice
    }
  }, function(error, result) {
    if (error) {
      return console.log(error);
    }
  });
};

optionImportDetail = function(option, currentImport) {
  option.merchant = currentImport.merchant;
  option.warehouse = currentImport.warehouse;
  option["import"] = currentImport._id;
  option.totalPrice = option.importQuality * option.importPrice;
  return option;
};

checkValidationOption = function(option, currentImport) {
  return true;
};

Apps.Merchant.importInit.push(function(scope) {
  return logics["import"].addImportDetail = function(event, template) {
    var currentImport, findImportDetail, importDetail, option, productionDate;
    option = {
      product: Session.get('currentImport').currentProduct,
      importQuality: Session.get('currentImport').currentQuality,
      importPrice: Session.get('currentImport').currentImportPrice,
      provider: Session.get('currentImport').currentProvider,
      salePrice: Session.get('currentImport').currentPrice ? Session.get('currentImport').currentPrice : void 0
    };
    productionDate = logics["import"].getProductionDate();
    if (productionDate && Session.get('timesUseProduct') > 0) {
      option.productionDate = productionDate;
      option.timeUse = Session.get('timesUseProduct');
      option.expire = new Date(productionDate.getFullYear(), productionDate.getMonth(), productionDate.getDate() + option.timeUse);
    }
    if (currentImport = Schema.imports.findOne({
      _id: Session.get('currentImport')._id
    })) {
      importDetail = optionImportDetail(option, currentImport);
      findImportDetail = Schema.importDetails.findOne({
        "import": importDetail["import"],
        product: importDetail.product,
        provider: importDetail.provider,
        importPrice: importDetail.importPrice,
        expire: importDetail.expire
      });
      if (findImportDetail) {
        reUpdateImportDetail(importDetail, findImportDetail);
      } else {
        Schema.importDetails.insert(importDetail, function(error, result) {
          if (error) {
            return console.log(error);
          }
        });
      }
      return logics["import"].reCalculateImport(Session.get('currentImport')._id);
    }
  };
});

})();

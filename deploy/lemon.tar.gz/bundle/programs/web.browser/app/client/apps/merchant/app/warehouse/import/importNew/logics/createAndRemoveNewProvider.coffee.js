(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Apps.Merchant.importInit.push(function(scope) {
  logics["import"].createNewProvider = function(event, template) {
    var address, name, phone, result;
    name = template.find(".name").value;
    phone = template.find(".phone").value;
    address = template.find(".address").value;
    result = Provider.createNew(name, phone, address);
    if (result.error) {
      return console.log(result.error);
    } else {
      template.find(".name").value = null;
      template.find(".address").value = null;
      return template.find(".phone").value = null;
    }
  };
  return logics["import"].removeNewProvider = function(providerId) {
    var result;
    result = Provider.destroyByCreator(providerId);
    if (result.error) {
      return console.log(result.error);
    }
  };
});

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var getPermissionGroups, roleManagerRoute;

getPermissionGroups = function() {
  var group, index, name, permission, results, _i, _len, _ref, _ref1, _ref2;
  results = [];
  _ref = Apps.Merchant.PermissionGroups;
  for (name in _ref) {
    group = _ref[name];
    _ref1 = group.children;
    for (index = _i = 0, _len = _ref1.length; _i < _len; index = ++_i) {
      permission = _ref1[index];
      group.children[index] = (_ref2 = Apps.Merchant.Permissions[permission]) != null ? _ref2 : permission;
    }
    results.push(group);
  }
  console.log(results);
  return results;
};

roleManagerRoute = {
  template: 'roleManager',
  waitOn: function() {
    return lemon.dependencies.resolve('roleManager', Apps.MerchantSubscriber);
  },
  data: function() {
    return {
      permissionGroups: getPermissionGroups(),
      roleSelectOptions: logics.roleManager.roleSelectOptions
    };
  }
};

lemon.addRoute([roleManagerRoute], Apps.Merchant.RouterBase);

})();

(function(){
Template.__define__("returns", (function() {
  var view = this;
  return [ HTML.DIV({
    id: "header"
  }, HTML.Raw('<div class="caption-row"><div class="title">Trả Hàng</div></div>'), "\n", HTML.DIV({
    "class": "editor-row"
  }, HTML.DIV({
    "class": "editor-wrapper",
    style: "width: 200px"
  }, HTML.Raw('<span class="ilabel">chọn phiếu bán hàng</span>'), "\n", Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("saleSelectOptions")),
      "class": Spacebars.call("field")
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("iSelect"));
  })), "\n", HTML.DIV({
    "class": "editor-wrapper",
    style: "width: 500px"
  }, HTML.Raw('<span class="ilabel optional">chọn hàng trả</span>'), "\n", Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("productSelectOptions")),
      "class": Spacebars.call("field")
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("iSelect"));
  })), "\n", HTML.DIV({
    "class": "editor-wrapper",
    style: "width: 100px"
  }, HTML.Raw('<span class="ilabel optional">số lượng trả</span>'), "\n", Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("returnQualityOptions"))
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("iSpinEdit"));
  })), "\n", HTML.DIV({
    "class": "editor-wrapper",
    style: function() {
      return [ "width:100px; ", Spacebars.mustache(view.lookup("hideAddReturnDetail")) ];
    }
  }, HTML.Raw('<button class="lemon btn lime icon-reply-all-1 addReturnDetail" type="submit">TRẢ</button>')))), HTML.DIV({
    id: "content"
  }, Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("gridOptions"))
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("iGrid"));
  })), HTML.DIV({
    id: "footer"
  }, HTML.DIV({
    "class": "editor-row"
  }, HTML.DIV({
    "class": [ "editor-wrapper", " ", "right" ],
    style: "width: 500px"
  }, HTML.Raw('<span class="ilabel">ghi chú</span>'), "\n", HTML.INPUT({
    "class": "comment",
    value: function() {
      return Spacebars.mustache(Spacebars.dot(view.lookup("currentReturn"), "comment"));
    }
  }))), "\n", HTML.DIV({
    "class": "editor-row"
  }, HTML.DIV({
    "class": [ "editor-wrapper", " ", "right" ],
    style: function() {
      return [ "width:100px; ", Spacebars.mustache(view.lookup("hideSubmitReturn")) ];
    }
  }, HTML.Raw('<button class="btn btn-default submitReturn" type="submit">ĐÃ DUYỆT</button>')), "\n", HTML.DIV({
    "class": [ "editor-wrapper", " ", "right" ],
    style: function() {
      return [ "width:110px; ", Spacebars.mustache(view.lookup("hideEditReturn")) ];
    }
  }, HTML.Raw('<button class="btn btn-default editReturn" type="submit">CHỈNH SỬA</button>')), "\n", HTML.DIV({
    "class": [ "editor-wrapper", " ", "right" ],
    style: function() {
      return [ "width:190px; ", Spacebars.mustache(view.lookup("hideFinishReturn")) ];
    }
  }, HTML.Raw('<button class="btn btn-default finishReturn" type="submit">XÁC NHẬN, CHỜ DUYỆT</button>')), "\n", HTML.DIV({
    "class": [ "editor-wrapper", " ", "right" ],
    style: "width: 100px"
  }, HTML.Raw('<span class="ilabel optional"> tỗng tiền</span>'), "\n", HTML.INPUT({
    "class": "totalPrice",
    value: function() {
      return Spacebars.mustache(Spacebars.dot(view.lookup("currentReturn"), "finallyPrice"));
    },
    disabled: ""
  })), "\n", HTML.DIV({
    "class": [ "editor-wrapper", " ", "right" ],
    style: "width: 180px"
  }, HTML.Raw('<span class="ilabel center optional">khấu hao</span>'), "\n", Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("discountCashOptions"))
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("iSpinEdit"));
  })), "\n", HTML.DIV({
    "class": [ "editor-wrapper", " ", "right" ],
    style: "width:110px"
  }, HTML.Raw('<span class="ilabel center">giá %</span>'), "\n", Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("discountPercentOptions"))
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("iSpinEdit"));
  })), "\n", HTML.DIV({
    "class": [ "editor-wrapper", " ", "right" ],
    style: "width: 150px"
  }, HTML.Raw('<span class="ilabel optional"> người tạo</span>'), "\n", HTML.INPUT({
    "class": "totalPrice",
    value: function() {
      return Spacebars.mustache(Spacebars.dot(view.lookup("currentReturn"), "creatorName"));
    },
    disabled: ""
  })))) ];
}));

})();

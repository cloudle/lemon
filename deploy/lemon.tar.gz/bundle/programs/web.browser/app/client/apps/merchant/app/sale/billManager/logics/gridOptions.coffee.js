(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Apps.Merchant.billManagerInit.push(function(scope) {
  return logics.billManager.gridOptions = {
    itemTemplate: 'billThumbnail',
    reactiveSourceGetter: function() {
      return logics.billManager.availableBills;
    },
    wrapperClasses: 'detail-grid row'
  };
});

})();

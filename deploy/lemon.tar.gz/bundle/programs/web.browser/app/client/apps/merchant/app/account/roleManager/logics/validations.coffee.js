(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
logics.roleManager.checkAllowCreate = function(context) {
  var existedRole, groupName;
  groupName = context.ui.$newGroupName.val();
  if (!groupName || groupName.length < 1) {
    Session.set('allowCreateNewRole', false);
    return;
  }
  existedRole = Schema.roles.findOne({
    name: groupName
  });
  return Session.set('allowCreateNewRole', existedRole === void 0);
};

})();

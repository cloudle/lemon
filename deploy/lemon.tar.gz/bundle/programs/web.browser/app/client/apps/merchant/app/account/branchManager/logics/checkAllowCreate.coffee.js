(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
logics.branchManager.checkAllowCreate = function(context) {
  var name;
  name = context.ui.$name.val();
  if (name.length > 0) {
    if (_.findWhere(Session.get("availableMerchant"), {
      name: name
    })) {
      return Session.set('allowCreateNewBranch', false);
    } else {
      return Session.set('allowCreateNewBranch', true);
    }
  } else {
    return Session.set('allowCreateNewBranch', false);
  }
};

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
logics.inventoryHistory = {};

Apps.Merchant.inventoryHistoryInit = [];

Apps.Merchant.inventoryHistoryReactiveRun = [];

Apps.Merchant.inventoryHistoryInit.push(function(scope) {
  var date, firstDay, lastDay;
  date = new Date();
  firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
  lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0);
  Session.set('inventoryHistoryFilterStartDate', firstDay);
  Session.set('inventoryHistoryFilterToDate', lastDay);
  return scope.availableMerchants = Schema.merchants.find({
    $or: [
      {
        _id: Session.get('myProfile').parentMerchant
      }, {
        parent: Session.get('myProfile').parentMerchant
      }
    ]
  });
});

Apps.Merchant.inventoryHistoryReactiveRun.push(function(scope) {
  var _ref, _ref1, _ref2;
  if (Session.get('mySession') && Session.get('myProfile')) {
    if (scope.currentMerchant = Schema.merchants.findOne(Session.get('mySession').currentInventoryBranchSelection)) {
      scope.currentWarehouse = Schema.warehouses.findOne({
        _id: Session.get('mySession').currentInventoryWarehouseSelection,
        merchant: scope.currentMerchant._id
      });
      if (!scope.currentWarehouse) {
        scope.currentWarehouse = Schema.warehouses.findOne({
          isRoot: true,
          merchant: scope.currentMerchant._id
        });
        UserSession.set('currentInventoryWarehouseSelection', (_ref = (_ref1 = scope.currentWarehouse) != null ? _ref1._id : void 0) != null ? _ref : 'skyReset');
      }
    } else {
      scope.currentMerchant = Schema.merchants.findOne(Session.get('myProfile').currentMerchant);
      scope.currentWarehouse = Schema.merchants.findOne(Session.get('myProfile').currentWarehouse);
      UserSession.set('currentInventoryBranchSelection', Session.get('myProfile').currentMerchant);
      UserSession.set('currentInventoryWarehouseSelection', Session.get('myProfile').currentWarehouse);
    }
  }
  if (scope.currentMerchant) {
    scope.availableWarehouses = Schema.warehouses.find({
      merchant: scope.currentMerchant._id
    });
  }
  if (((_ref2 = Session.get('mySession')) != null ? _ref2.currentInventoryWarehouseSelection : void 0) && Session.get('inventoryHistoryFilterStartDate') && Session.get('inventoryHistoryFilterToDate')) {
    scope.availableInventories = Inventory.findHistory(Session.get('inventoryHistoryFilterStartDate'), Session.get('inventoryHistoryFilterToDate'), Session.get('mySession').currentInventoryWarehouseSelection);
  }
  if (Session.get('currentInventoryHistory')) {
    scope.currentInventoryDetailHistory = Schema.inventoryDetails.find({
      inventory: Session.get('currentInventoryHistory')._id,
      lostQuality: {
        $gt: 0
      }
    });
    return scope.currentInventoryProductLostHistory = Schema.productLosts.find({
      inventory: Session.get('currentInventoryHistory')._id
    });
  }
});

})();

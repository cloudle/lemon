(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var formatWarehouseSearch;

formatWarehouseSearch = function(item) {
  if (item) {
    return "" + item.name;
  }
};

Apps.Merchant.importHistoryInit.push(function(scope) {
  return scope.warehouseSelectOptions = {
    query: function(query) {
      return query.callback({
        results: scope.availableWarehouses.fetch()
      });
    },
    initSelection: function(element, callback) {
      var _ref, _ref1;
      return callback((_ref = Schema.warehouses.findOne((_ref1 = Session.get('mySession')) != null ? _ref1.currentImportWarehouse : void 0)) != null ? _ref : 'skyReset');
    },
    reactiveValueGetter: function() {
      var _ref, _ref1;
      return (_ref = (_ref1 = Session.get('mySession')) != null ? _ref1.currentImportWarehouse : void 0) != null ? _ref : 'skyReset';
    },
    changeAction: function(e) {
      scope.currentWarehouse = e.added;
      return Schema.userSessions.update(Session.get('mySession')._id, {
        $set: {
          currentImportWarehouse: e.added._id
        }
      });
    },
    minimumResultsForSearch: -1,
    formatSelection: formatWarehouseSearch,
    formatResult: formatWarehouseSearch,
    placeholder: 'CHỌN CHI NHÁNH'
  };
});

})();

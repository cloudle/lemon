(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineApp(Template.warehouseManager, {
  events: {
    "input input": function(event, template) {
      return logics.warehouseManager.checkAllowCreate(template);
    },
    "click #createWarehouse": function(event, template) {
      return logics.warehouseManager.createWarehouse(template);
    }
  }
});

})();

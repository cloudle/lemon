(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var scope;

scope = logics.staffManager;

lemon.addRoute({
  template: 'staffManager',
  waitOnDependency: 'staffManager',
  onBeforeAction: function() {
    if (this.ready()) {
      Apps.setup(scope, Apps.Merchant.staffManagerInit, 'staffManager');
      return this.next();
    }
  },
  data: function() {
    Apps.setup(scope, Apps.Merchant.staffManagerReactiveRun);
    return {
      gridOptions: scope.gridOptions,
      roleSelectOptions: scope.roleSelectOptions,
      branchSelectOptions: scope.branchSelectOptions,
      warehouseSelectOptions: scope.warehouseSelectOptions
    };
  }
}, Apps.Merchant.RouterBase);

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineApp(Template.branchManager, {
  events: {
    "input input": function(event, template) {
      return logics.branchManager.checkAllowCreate(template);
    },
    "click #createBranch": function(event, template) {
      return logics.branchManager.createBranch(template);
    }
  }
});

})();

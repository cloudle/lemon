(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Apps.Merchant.transactionManagerInit.push(function(scope) {
  scope.updateDescription = function(description) {
    var createNewTransaction, _ref;
    if (((_ref = Session.get('createNewTransaction')) != null ? _ref.customerId : void 0) !== 'skyReset') {
      if (description.value.length >= 0) {
        createNewTransaction = Session.get('createNewTransaction');
        createNewTransaction.description = description.value;
        return Session.set('createNewTransaction', createNewTransaction);
      }
    } else {
      return description.value = Session.get('createNewTransaction').description;
    }
  };
  scope.updateDebtDate = function() {
    var createNewTransaction, date, debtDate, deliveryToDate, toDate, _ref, _ref1;
    date = $("[name=debtDate]").datepicker().data().datepicker.dates[0];
    toDate = new Date;
    if (date && ((_ref = Session.get('createNewTransaction')) != null ? _ref.customerId : void 0) === 'skyReset') {
      createNewTransaction = Session.get('createNewTransaction');
      createNewTransaction.debtDate = void 0;
      Session.set('createNewTransaction', createNewTransaction);
      $("[name=debtDate]").datepicker('setDate', void 0);
    }
    if (date && ((_ref1 = Session.get('createNewTransaction')) != null ? _ref1.customerId : void 0) !== 'skyReset') {
      deliveryToDate = new Date(toDate.getFullYear(), toDate.getMonth(), toDate.getDate());
      debtDate = new Date(date.getFullYear(), date.getMonth(), date.getDate());
      if (debtDate > deliveryToDate) {
        debtDate = deliveryToDate;
        $("[name=debtDate]").datepicker('setDate', debtDate);
      }
      createNewTransaction = Session.get('createNewTransaction');
      createNewTransaction.debtDate = debtDate;
      return Session.set('createNewTransaction', createNewTransaction);
    }
  };
  scope.showTransactionDetail = function() {
    Session.set('showAddTransactionDetail', true);
    return $("[name=createDebtDate]").datepicker('setDate', new Date());
  };
  return scope.createNewTransactionDetail = function() {
    return Meteor.call('addTransactionDetail', Session.get('currentTransaction')._id, Session.get('depositCashNewTransactionDetail'), Session.get('transactionDetailPaymentDate'), function(error, result) {
      if (error) {
        return console.log(error);
      } else {
        Session.set('depositCashNewTransactionDetail', 0);
        Session.set('transactionDetailPaymentDate', new Date());
        return $("[name=createDebtDate]").datepicker('setDate', Session.get('transactionDetailPaymentDate'));
      }
    });
  };
});

})();

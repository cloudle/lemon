(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Apps.Merchant.staffManagerInit.push(function(scope) {
  scope.resetForm = function(context) {
    var item, _i, _len, _ref;
    _ref = context.findAll("[name]");
    for (_i = 0, _len = _ref.length; _i < _len; _i++) {
      item = _ref[_i];
      $(item).val('');
    }
    return Session.set('currentRoleSelection', []);
  };
  return scope.createStaffAccount = function(template) {
    var dateOfBirth, email, fullName, newMemberName, newProfile, password, role, roles, startWorkingDate, _i, _len, _ref, _ref1;
    dateOfBirth = template.datePicker.$dateOfBirth.data('datepicker').dates[0];
    startWorkingDate = template.datePicker.$startWorkingDate.data('datepicker').dates[0];
    email = template.ui.$email.val();
    password = template.ui.$password.val();
    fullName = template.ui.$fullName.val();
    if (!(Meteor.users.findOne({
      'emails.address': email
    }) || Schema.userProfiles.findOne({
      fullName: fullName
    }))) {
      roles = [];
      if (((_ref = Session.get('currentRoleSelection')) != null ? _ref.length : void 0) > 0) {
        _ref1 = Session.get('currentRoleSelection');
        for (_i = 0, _len = _ref1.length; _i < _len; _i++) {
          role = _ref1[_i];
          roles.push(role.name);
        }
      }
      newProfile = {
        parentMerchant: Session.get("myProfile").parentMerchant,
        currentMerchant: Session.get("mySession").createStaffBranchSelection,
        currentWarehouse: Session.get("mySession").createStaffWarehouseSelection,
        creator: Session.get("myProfile").user,
        isRoot: false,
        fullName: fullName,
        gender: fullName ? Session.get("createStaffGenderSelection") : void 0,
        dateOfBirth: dateOfBirth ? dateOfBirth : void 0,
        startWorkingDate: startWorkingDate ? startWorkingDate : void 0,
        roles: roles.length > 0 ? roles : void 0,
        systemVersion: Schema.systems.findOne().version
      };
      Meteor.call("createMerchantStaff", email, password, newProfile);
      newMemberName = fullName != null ? fullName : email;
      return scope.resetForm(template);
    }
  };
});

})();

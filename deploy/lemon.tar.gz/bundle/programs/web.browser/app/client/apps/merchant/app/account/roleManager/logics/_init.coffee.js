(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
logics.roleManager = {};

logics.roleManager.rolesTemplateContext = void 0;

})();

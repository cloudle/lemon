(function(){
Template.__define__("warehouseManager", (function() {
  var view = this;
  return [ HTML.DIV({
    id: "header"
  }, HTML.Raw('<div class="caption-row"><div class="title">QUẢN LÝ KHO HÀNG</div></div>'), "\n", HTML.DIV({
    "class": "editor-row"
  }, HTML.Raw('<!--.editor-wrapper(style="width:150px")-->'), "\n", HTML.Raw("<!--  span.ilabel.optional chi nhánh-->"), "\n", HTML.Raw('<!--  +iSelect(options=merchantSelectOptions class="field")-->'), "\n", HTML.Raw('<div class="editor-wrapper"><span class="ilabel">tên kho</span>\n<input name="name" maxlength="40"></div>'), "\n", HTML.Raw('<div class="editor-wrapper" style="width: 300px"><span class="ilabel optional">địa chỉ</span>\n<input name="address"></div>'), "\n", HTML.DIV({
    "class": "editor-wrapper"
  }, HTML.BUTTON({
    "class": function() {
      return [ "lemon", " ", "btn", " ", "lime", " ", "icon-plus-circled", " ", Spacebars.mustache(view.lookup("allowCreate")) ];
    },
    id: "createWarehouse"
  }, "THÊM MỚI")))), HTML.DIV({
    id: "content"
  }, Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("gridOptions"))
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("iGrid"));
  })) ];
}));

})();

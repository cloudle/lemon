(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Apps.Merchant.inventoryHistoryInit.push(function(scope) {
  return logics.inventoryHistory.gridOptions = {
    itemTemplate: 'inventoryHistoryThumbnail',
    reactiveSourceGetter: function() {
      return logics.inventoryHistory.availableInventories;
    },
    wrapperClasses: 'detail-grid row'
  };
});

})();

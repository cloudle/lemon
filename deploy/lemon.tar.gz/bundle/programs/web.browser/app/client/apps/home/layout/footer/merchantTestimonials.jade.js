(function(){
Template.__define__("merchantTestimonials", (function() {
  var view = this;
  return [ HTML.DIV({
    id: "home-comment-wrapper"
  }, HTML.IMG({
    "class": "avatar",
    src: function() {
      return [ "images/avatars/", Spacebars.mustache(Spacebars.dot(view.lookup("currentComment"), "avatar")) ];
    }
  }), "\n", HTML.DIV({
    "class": "owner-info"
  }, HTML.SPAN({
    "class": "name"
  }, Blaze.View(function() {
    return Spacebars.mustache(Spacebars.dot(view.lookup("currentComment"), "name"));
  })), "\n", HTML.SPAN({
    "class": "position"
  }, Blaze.View(function() {
    return Spacebars.mustache(Spacebars.dot(view.lookup("currentComment"), "position"));
  }))), "\n", HTML.SPAN({
    "class": [ "comment", " ", "icon-quote" ]
  }, Blaze.View(function() {
    return Spacebars.mustache(Spacebars.dot(view.lookup("currentComment"), "comment"));
  }))), HTML.Raw('<div class="navigateCommands"><div class="btn previousCommand icon-left-open-big"></div>\n<div class="btn nextCommand icon-right-open-big"></div></div>') ];
}));

})();

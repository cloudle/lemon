(function(){
Template.__define__("merchantTest", (function() {
  var view = this;
  return HTML.Raw('<div id="header"><div class="caption-row"><div class="title">TEST PAGE</div></div></div><div id="content"><div class="segments-container size3"><div id="step1" class="segments-column"><h1>col1</h1></div>\n<div id="step2" class="segments-column"><h1>col2</h1></div>\n<div id="step3" class="segments-column"><h1>col3</h1></div></div></div>');
}));

})();

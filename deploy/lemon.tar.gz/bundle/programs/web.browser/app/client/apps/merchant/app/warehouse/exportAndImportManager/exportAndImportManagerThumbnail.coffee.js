(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineWidget(Template.exportAndImportManagerThumbnail, {
  buyerName: function() {
    var _ref;
    return (_ref = Schema.customers.findOne(this.buyer)) != null ? _ref.name : void 0;
  },
  sellerName: function() {
    var _ref;
    return (_ref = Schema.userProfiles.findOne(this.seller)) != null ? _ref.fullName : void 0;
  },
  formatNumber: function(number) {
    return accounting.formatNumber(number);
  },
  showInput: function() {
    var _ref, _ref1, _ref2, _ref3, _ref4, _ref5, _ref6, _ref7, _ref8;
    if ((this.status === (_ref = this.received) && _ref === false) && ((this.submitted === (_ref2 = this.exported) && _ref2 === (_ref1 = this.imported)) && _ref1 === true) && this.paymentsDelivery !== 0) {
      return "display: none";
    }
    if ((this.status === (_ref3 = this.received) && _ref3 === false) && ((this.submitted === (_ref5 = this.exported) && _ref5 === (_ref4 = this.imported)) && _ref4 === true) && this.paymentsDelivery !== 1) {
      return "display: none";
    }
    if (((this.status === (_ref7 = this.received) && _ref7 === (_ref6 = this.exported)) && _ref6 === false) && (this.submitted === (_ref8 = this.imported) && _ref8 === true) && this.paymentsDelivery !== 1) {
      return "display: none";
    }
  },
  showInputText: function() {
    var _ref, _ref1, _ref2, _ref3, _ref4, _ref5, _ref6, _ref7, _ref8;
    if ((this.status === (_ref = this.received) && _ref === true) && ((this.submitted === (_ref2 = this.exported) && _ref2 === (_ref1 = this.imported)) && _ref1 === false) && this.paymentsDelivery === 0) {
      return 'Xuất Bán Hàng';
    }
    if ((this.status === (_ref3 = this.received) && _ref3 === true) && ((this.submitted === (_ref5 = this.exported) && _ref5 === (_ref4 = this.imported)) && _ref4 === false) && this.paymentsDelivery === 1) {
      return 'Xuất Giao Hàng';
    }
    if (((this.status === (_ref7 = this.received) && _ref7 === (_ref6 = this.exported)) && _ref6 === true) && (this.submitted === (_ref8 = this.imported) && _ref8 === false) && this.paymentsDelivery === 1) {
      return 'Đã Nhận Hàng';
    }
  },
  events: {
    "click .createSaleExport": function() {
      return Meteor.call('createSaleExport', this._id, function(error, result) {
        if (error) {
          return console.log(error.error);
        } else {
          return console.log(result);
        }
      });
    }
  }
});

})();

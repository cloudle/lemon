(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
logics.customerManager.checkAllowCreate = function(context) {
  var fullName, phone;
  fullName = context.ui.$fullName.val();
  phone = context.ui.$phone.val();
  if (fullName.length > 0 && phone.length > 0) {
    if (_.findWhere(Session.get("availableCustomers"), {
      name: fullName,
      phone: phone
    })) {
      return Session.set('allowCreateNewCustomer', false);
    } else {
      return Session.set('allowCreateNewCustomer', true);
    }
  } else {
    return Session.set('allowCreateNewCustomer', false);
  }
};

})();

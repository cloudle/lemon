(function(){
Template.__define__("transactionManagerDetail", (function() {
  var view = this;
  return HTML.ASIDE({
    "class": [ "modal", " ", "swipe", " ", "left" ],
    id: "transactionManagerDetail"
  }, HTML.DIV({
    "class": [ "modal-dialog", " ", "sale-bill-preview" ]
  }, HTML.Raw('<div class="modal-header"><button class="close" type="button" data-dismiss="modal"><span aria-hidden="true">&times;</span>\n<span class="sr-only">Close</span></button>\n<h4 class="modal-title"><i class="icon-search-8"></i>\n<span>CHI TIẾT CÔNG NỢ</span></h4></div>'), "\n", HTML.DIV({
    "class": [ "modal-body", " ", "printable-area" ]
  }, HTML.SPAN(Blaze.View(function() {
    return Spacebars.mustache(view.lookup("groupType"), Spacebars.dot(view.lookup("transaction"), "group"));
  }), " (", Blaze.View(function() {
    return Spacebars.mustache(view.lookup("formatDate"), Spacebars.dot(view.lookup("transaction"), "debtDate"));
  }), ")", HTML.Raw("<br>")), "\n", HTML.SPAN("Nhân viên: ", Blaze.View(function() {
    return Spacebars.mustache(view.lookup("userNameFromId"), Spacebars.dot(view.lookup("transaction"), "creator"));
  }), " ", HTML.Raw("<br>")), "\n", HTML.SPAN("Khách Hàng: ", Blaze.View(function() {
    return Spacebars.mustache(view.lookup("ownerNameFromId"), Spacebars.dot(view.lookup("transaction"), "owner"));
  }), " ", HTML.Raw("<br>")), "\n", HTML.SPAN("Tình trạng: ", Blaze.View(function() {
    return Spacebars.mustache(view.lookup("status"));
  }), " (đã trả ", Blaze.View(function() {
    return Spacebars.mustache(view.lookup("countDetail"));
  }), " lần) ", HTML.Raw("<br>")), "\n", HTML.SPAN("Lý do: ", Blaze.View(function() {
    return Spacebars.mustache(Spacebars.dot(view.lookup("transaction"), "description"));
  }), HTML.Raw("<br>")), "\n", HTML.UL(Blaze.Each(function() {
    return Spacebars.call(view.lookup("transactionDetail"));
  }, function() {
    return HTML.LI({
      "class": "order-detail"
    }, HTML.DIV({
      "class": "product-name"
    }, HTML.B(Blaze.View(function() {
      return Spacebars.mustache(view.lookup("formatDate"), view.lookup("paymentDate"));
    })), " (tạo bởi: ", HTML.B(Blaze.View(function() {
      return Spacebars.mustache(view.lookup("userNameFromId"), view.lookup("creator"));
    }), " "), ")"), "\n", HTML.DIV({
      "class": "product-price"
    }, HTML.SPAN({
      "class": "individual-price"
    }, "Đã trả: ", Blaze.View(function() {
      return Spacebars.mustache(view.lookup("formatNumber"), view.lookup("depositCash"));
    })), "\n", HTML.SPAN({
      "class": "final-price"
    }, "Nợ còn: ", Blaze.View(function() {
      return Spacebars.mustache(view.lookup("formatNumber"), view.lookup("debitCash"));
    }))));
  })), "\n", HTML.DIV({
    "class": "bill-summary"
  }, HTML.SPAN("Tỗng tiền: ", HTML.B(Blaze.View(function() {
    return Spacebars.mustache(view.lookup("formatNumber"), Spacebars.dot(view.lookup("transaction"), "totalCash"));
  })), " VNĐ ", HTML.Raw("<br>")), "\n", HTML.SPAN("Đã trả: ", HTML.B(Blaze.View(function() {
    return Spacebars.mustache(view.lookup("formatNumber"), Spacebars.dot(view.lookup("transaction"), "depositCash"));
  })), " VNĐ")), "\n", HTML.DIV({
    "class": "bill-footer"
  }, HTML.Raw("<span>Còn nợ:</span>"), "\n", HTML.SPAN({
    "class": "bill-final"
  }, HTML.B(Blaze.View(function() {
    return Spacebars.mustache(view.lookup("formatNumber"), Spacebars.dot(view.lookup("transaction"), "debitCash"));
  })), " VNĐ"))), "\n", HTML.DIV({
    "class": "modal-footer"
  }, Blaze.If(function() {
    return Spacebars.call(view.lookup("showDeleteTransaction"));
  }, function() {
    return HTML.BUTTON({
      "class": [ "lemon", " ", "btn", " ", "pumpkin", " ", "icon-minus-circled", " ", "deleteTransaction" ],
      "data-dismiss": "modal"
    }, "Xóa Phiếu");
  }), "\n", Blaze.If(function() {
    return Spacebars.call(view.lookup("allowAddDetail"));
  }, function() {
    return [ Blaze.If(function() {
      return Spacebars.call(view.lookup("showAddDetail"));
    }, function() {
      return HTML.BUTTON({
        "class": [ "lemon", " ", "btn", " ", "lime", " ", "icon-plus-circled", " ", "showTransactionDetail" ]
      }, "Thêm Trả Tiền");
    }), "\n", HTML.DIV({
      "class": "editor-row",
      style: function() {
        return Spacebars.mustache(view.lookup("createTransactionDetail"));
      }
    }, HTML.DIV({
      "class": "editor-wrapper",
      style: "width:150px"
    }, HTML.SPAN({
      "class": "ilabel"
    }, "tiền trả"), "\n", Spacebars.TemplateWith(function() {
      return {
        options: Spacebars.call(view.lookup("depositCashOptions")),
        "class": Spacebars.call("field")
      };
    }, function() {
      return Spacebars.include(view.lookupTemplate("iSpinEdit"));
    })), "\n", HTML.DIV({
      "class": "editor-wrapper",
      style: "width: 90px"
    }, HTML.SPAN({
      "class": "ilabel"
    }, "ngày trả"), "\n", HTML.INPUT({
      "class": "createDebtDate",
      name: "createDebtDate",
      binding: "datePicker",
      todayHighlight: "true",
      maxlength: "20"
    })), "\n", HTML.DIV({
      "class": "editor-wrapper"
    }, HTML.BUTTON({
      "class": [ "lemon", " ", "btn", " ", "lime", " ", "icon-plus-circled", " ", "createTransactionDetail" ],
      type: "submit"
    }, "Thêm")), "\n", HTML.DIV({
      "class": "editor-wrapper"
    }, HTML.BUTTON({
      "class": [ "lemon", " ", "btn", " ", "pumpkin", " ", "cancelCreateTransactionDetail" ],
      type: "submit"
    }, "Hủy"))) ];
  }))));
}));

})();

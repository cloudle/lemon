(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
logics.returns = {};

Apps.Merchant.returnsInit = [];

Apps.Merchant.returnsInit.push(function(scope) {
  return logics.returns.availableSales = Sale.findAvailableReturn(Session.get('myProfile'));
});

logics.returns.reactiveRun = function() {
  if (Session.get('mySession')) {
    logics.returns.currentSale = Schema.sales.findOne(Session.get('mySession').currentSale);
    logics.returns.currentReturn = Schema.returns.findOne({
      sale: Session.get('mySession').currentSale,
      status: {
        $ne: 2
      }
    });
  }
  if (logics.returns.currentSale) {
    Session.set('currentSale', logics.returns.currentSale);
    Meteor.subscribe('saleDetailAndProductAndReturn', logics.returns.currentSale._id);
    logics.returns.availableSaleDetails = Schema.saleDetails.find({
      sale: logics.returns.currentSale._id
    });
  } else {
    Session.set('currentSale');
  }
  if (logics.returns.currentReturn) {
    Meteor.subscribe('returnDetails', logics.returns.currentReturn._id);
    return logics.returns.availableReturnDetails = Schema.returnDetails.find({
      "return": logics.returns.currentReturn._id
    });
  } else {
    return logics.returns.availableReturnDetails = Schema.returnDetails.find({
      "return": 'null'
    });
  }
};

})();

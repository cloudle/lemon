(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
logics.returns.finishReturn = function(returnId) {
  var currentReturn, error, returnDetail, userProfile, _i, _len, _ref;
  try {
    if (!(userProfile = Schema.userProfiles.findOne({
      user: Meteor.userId()
    }))) {
      throw 'Lỗi, Bạn chưa đăng nhập.';
    }
    if (!(currentReturn = Schema.returns.findOne({
      _id: returnId,
      creator: userProfile.user
    }))) {
      throw 'Lỗi, Phiếu trả không chính xác.';
    }
    if (Schema.returnDetails.find({
      "return": currentReturn._id
    }).count() < 1) {
      throw 'Lỗi, Phiếu trả hàng rỗng, không thể xác nhận.';
    }
    if (currentReturn.status === 0) {
      Schema.returns.update(currentReturn._id, {
        $set: {
          status: 1
        }
      });
      _ref = Schema.returnDetails.find({
        "return": currentReturn._id,
        submit: false
      }).fetch();
      for (_i = 0, _len = _ref.length; _i < _len; _i++) {
        returnDetail = _ref[_i];
        Schema.returnDetails.update(returnDetail._id, {
          $set: {
            submit: true
          }
        });
      }
      throw 'Ok, Phiếu đã được xác nhận từ nhân viên';
    }
    if (currentReturn.status === 1) {
      throw 'Lỗi, Phiếu đã được xác nhận, đang chờ duyệt, không thể thao tác.';
    }
    if (currentReturn.status === 2) {
      throw 'Lỗi, Phiếu đã được duyệt, không thể thao tác.';
    }
  } catch (_error) {
    error = _error;
    return console.log(error);
  }
};

})();

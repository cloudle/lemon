(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var calculateImportPrice;

calculateImportPrice = function(val) {
  var option, _ref, _ref1, _ref2;
  option = {
    currentImportPrice: val
  };
  if (((_ref = Session.get('currentImport')) != null ? _ref.currentPrice : void 0) < val) {
    option.currentPrice = val;
  }
  Import.update((_ref1 = Session.get('currentImport')) != null ? _ref1._id : void 0, {
    $set: option
  });
  return Product.update((_ref2 = Session.get('currentImport')) != null ? _ref2.currentProduct : void 0, {
    $set: {
      importPrice: val
    }
  });
};

Apps.Merchant.importInit.push(function(scope) {
  console.log;
  return logics["import"].importPriceOptions = {
    reactiveSetter: function(val) {
      return calculateImportPrice(val);
    },
    reactiveValue: function() {
      var _ref, _ref1;
      return (_ref = (_ref1 = Session.get('currentImport')) != null ? _ref1.currentImportPrice : void 0) != null ? _ref : 0;
    },
    reactiveMax: function() {
      return 9999999999;
    },
    reactiveMin: function() {
      return 0;
    },
    reactiveStep: function() {
      return 1000;
    },
    others: {
      forcestepdivisibility: 'none'
    }
  };
});

})();

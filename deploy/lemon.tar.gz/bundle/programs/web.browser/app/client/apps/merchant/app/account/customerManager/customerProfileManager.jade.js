(function(){
Template.__define__("customerProfileManager", (function() {
  var view = this;
  return HTML.Raw('<aside class="modal swipe left" id="customerProfileManager"><div class="modal-dialog"><div class="modal-header"><button class="close" type="button" data-dismiss="modal"><span aria-hidden="true">&times;</span>\n<span class="sr-only">Close</span></button>\n<h4 class="modal-title"><i class="icon-search-8"></i>\n<span>HỒ SƠ MACKAY</span></h4></div>\n<div class="modal-body printable-area"><h1>body!</h1></div>\n<div class="modal-footer"><button class="lemon btn pumpkin" type="button" data-dismiss="modal">ĐÓNG</button>\n<button class="lemon btn lime icon-ok-circled">LƯU</button></div></div></aside>');
}));

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineWidget(Template.importProductThumbnail, {
  expire: function() {
    if (this.expire) {
      return moment(this.expire).fromNow();
    }
  },
  events: {
    "dblclick .full-desc.trash": function() {
      Schema.importDetails.remove(this._id);
      return logics["import"].reCalculateImport(this["import"]);
    }
  }
});

})();

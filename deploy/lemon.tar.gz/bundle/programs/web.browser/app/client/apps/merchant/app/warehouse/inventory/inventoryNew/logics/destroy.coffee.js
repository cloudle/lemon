(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
logics.inventoryManager.destroyInventory = function(warehouseId) {
  var detail, userSession, warehouse, _i, _len, _ref;
  userSession = Schema.userSessions.findOne({
    user: Meteor.userId()
  });
  if (!userSession) {
    return console.log('Bạn chưa đăng nhập');
  }
  warehouse = Schema.warehouses.findOne({
    _id: warehouseId,
    merchant: userSession.currentInventoryBranchSelection
  });
  if (!warehouse) {
    return console.log('Kho hang khong ton tai');
  }
  if (warehouse.checkingInventory === false) {
    console.log('Kho hang khong co dang kiem kho');
  }
  _ref = Schema.inventoryDetails.find({
    inventory: warehouse.inventory
  }).fetch();
  for (_i = 0, _len = _ref.length; _i < _len; _i++) {
    detail = _ref[_i];
    Schema.inventoryDetails.remove(detail._id);
  }
  Schema.inventories.remove(warehouse.inventory);
  Schema.warehouses.update(warehouse._id, {
    $set: {
      checkingInventory: false
    },
    $unset: {
      inventory: ""
    }
  });
  return console.log('Hủy Phiếu Kiểm Kho Thành Công');
};

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var setTime;

setTime = function() {
  return Session.set('realtime-now', new Date());
};

lemon.defineWidget(Template.salePrinter, {
  dayOfWeek: function() {
    return moment(Session.get('realtime-now')).format("dddd");
  },
  timeDMY: function() {
    return moment(Session.get('realtime-now')).format("DD/MM/YYYY");
  },
  timeHM: function() {
    return moment(Session.get('realtime-now')).format("hh:mm");
  },
  timeS: function() {
    return moment(Session.get('realtime-now')).format("ss");
  },
  soldPrice: function() {
    return this.price - (this.price * this.discountPercent);
  },
  discountVisible: function() {
    return this.discountPercent > 0;
  },
  created: function() {
    return this.timeInterval = Meteor.setInterval(setTime, 1000);
  },
  destroyed: function() {
    return Meteor.clearInterval(this.timeInterval);
  },
  events: {
    "click .print-button": function() {
      return window.print();
    }
  }
});

})();

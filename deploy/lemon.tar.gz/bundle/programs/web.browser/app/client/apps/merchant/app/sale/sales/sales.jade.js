(function(){
Template.__define__("sales", (function() {
  var view = this;
  return [ Spacebars.TemplateWith(function() {
    return {
      orderDetails: Spacebars.call(view.lookup("currentOrderDetails")),
      order: Spacebars.call(view.lookup("currentOrder"))
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("salePrinter"));
  }), HTML.DIV({
    id: "header"
  }, HTML.Raw('<div class="caption-row"><div class="title">Bán hàng</div>\n<div class="commands"><input binding="switch" type="checkbox" name="advancedMode">\n<!--+iSelect(options=warehouseSelectOptions class="field")-->\n</div></div>'), "\n", HTML.DIV({
    "class": "editor-row"
  }, HTML.DIV({
    "class": "editor-wrapper",
    style: "width: 250px"
  }, HTML.Raw('<span class="ilabel">sản phẩm</span>'), "\n", Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("productSelectOptions")),
      "class": Spacebars.call("field")
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("iSelect"));
  })), "\n", HTML.DIV({
    "class": "editor-wrapper",
    style: "width: 100px"
  }, HTML.Raw('<span class="ilabel center">số lượng</span>'), "\n", Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("productQualityOptions"))
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("iSpinEdit"));
  })), "\n", HTML.DIV({
    "class": "editor-wrapper",
    style: "width: 150px"
  }, HTML.Raw('<span class="ilabel center">giá bán</span>'), "\n", Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("productPriceOptions"))
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("iSpinEdit"));
  })), "\n", HTML.DIV({
    "class": "editor-wrapper",
    style: "width:70px"
  }, HTML.BUTTON({
    "class": function() {
      return [ "lemon", " ", "btn", " ", "lime", " ", "icon-plus-circled", " ", "addOrderDetail", " ", Spacebars.mustache(view.lookup("allowAllOrderDetail")) ];
    },
    type: "submit"
  }, "THÊM")), "\n", HTML.DIV({
    "class": [ "editor-wrapper", " ", "right" ],
    style: "width: 150px"
  }, HTML.Raw('<span class="ilabel optional">giá tổng</span>'), "\n", HTML.INPUT({
    "class": "quality",
    value: function() {
      return Spacebars.mustache(view.lookup("formatNumber"), view.lookup("finalPriceProduct"));
    },
    disabled: ""
  })), "\n", HTML.DIV({
    "class": [ "editor-wrapper", " ", "right" ],
    style: "width: 150px"
  }, HTML.Raw('<span class="ilabel center optional">giảm giá</span>'), "\n", Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("productDiscountCashOptions"))
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("iSpinEdit"));
  })), "\n", HTML.DIV({
    "class": [ "editor-wrapper", " ", "right" ],
    style: "width:100px"
  }, HTML.Raw('<span class="ilabel center optional">giảm %</span>'), "\n", Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("productDiscountPercentOptions"))
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("iSpinEdit"));
  })))), HTML.DIV({
    id: "content",
    "class": "sales-app"
  }, Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("saleDetailOptions")),
      wrapperClass: Spacebars.call("detail-grid row"),
      animation: Spacebars.call("bounceInDown")
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("gridComponent"));
  })), HTML.DIV({
    id: "footer"
  }, HTML.DIV({
    "class": [ "editor-row", " ", "extra" ],
    name: "delivery"
  }, HTML.DIV({
    "class": [ "editor-wrapper", " ", "right" ],
    style: "width:200px"
  }, HTML.Raw('<span class="ilabel">ghi chú</span>'), "\n", HTML.INPUT({
    "class": "comment",
    value: function() {
      return [ Spacebars.mustache(Spacebars.dot(view.lookup("deliveryDetail"), "comment")) ];
    }
  })), "\n", HTML.Raw('<div class="editor-wrapper right" style="width:100px"><span class="ilabel">ngày giao hàng</span>\n<input name="deliveryDate" binding="datePicker" todayHighlight="true" maxlength="20"></div>'), "\n", HTML.DIV({
    "class": [ "editor-wrapper", " ", "right" ],
    style: "width:350px"
  }, HTML.Raw('<span class="ilabel">địa chỉ giao hàng</span>'), "\n", HTML.INPUT({
    "class": "deliveryAddress",
    value: function() {
      return [ Spacebars.mustache(Spacebars.dot(view.lookup("deliveryDetail"), "deliveryAddress")) ];
    }
  })), "\n", HTML.DIV({
    "class": [ "editor-wrapper", " ", "right" ],
    style: "width:130px"
  }, HTML.Raw('<span class="ilabel">số điện thoại</span>'), "\n", HTML.INPUT({
    "class": "contactPhone",
    value: function() {
      return [ Spacebars.mustache(Spacebars.dot(view.lookup("deliveryDetail"), "contactPhone")) ];
    }
  })), "\n", HTML.DIV({
    "class": [ "editor-wrapper", " ", "right" ],
    style: "width:170px"
  }, HTML.Raw('<span class="ilabel">tên người nhận</span>'), "\n", HTML.INPUT({
    "class": "contactName",
    value: function() {
      return [ Spacebars.mustache(Spacebars.dot(view.lookup("deliveryDetail"), "contactName")) ];
    }
  }))), "\n", HTML.DIV({
    "class": [ "editor-row", " ", "extra" ],
    name: "advanced"
  }, HTML.DIV({
    "class": "editor-wrapper",
    style: "width: 200px; margin-right: 5px;"
  }, HTML.Raw('<span class="ilabel optional">nhân viên</span>'), "\n", Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("sellerSelectOptions")),
      "class": Spacebars.call("field")
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("iSelect"));
  })), "\n", HTML.DIV({
    "class": "editor-wrapper",
    style: "width: 120px"
  }, HTML.Raw('<span class="ilabel optional">thanh toán</span>'), "\n", Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("paymentMethodSelectOption")),
      "class": Spacebars.call("field")
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("iSelect"));
  })), "\n", HTML.DIV({
    "class": [ "editor-wrapper", " ", "right" ],
    style: "width: 195px"
  }, HTML.Raw('<span class="ilabel optional">phương thức giảm giá</span>'), "\n", Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("billDiscountSelectOption")),
      "class": Spacebars.call("field")
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("iSelect"));
  })), "\n", HTML.DIV({
    "class": [ "editor-wrapper", " ", "right" ],
    style: "width: 190px"
  }, HTML.Raw('<span class="ilabel center optional">giảm giá</span>'), "\n", Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("billCashDiscountOptions"))
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("iSpinEdit"));
  })), "\n", HTML.DIV({
    "class": [ "editor-wrapper", " ", "right" ],
    style: "width:110px"
  }, HTML.Raw('<span class="ilabel center optional">giảm %</span>'), "\n", Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("billPercentDiscountOptions"))
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("iSpinEdit"));
  }))), "\n", HTML.DIV({
    "class": "editor-row"
  }, HTML.DIV({
    "class": "editor-wrapper",
    style: "width: 180px"
  }, HTML.Raw('<span class="ilabel optional">khách hàng</span>'), "\n", Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("customerSelectOptions")),
      "class": Spacebars.call("field")
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("iSelect"));
  })), "\n", HTML.DIV({
    "class": "editor-wrapper",
    style: "width: 120px"
  }, HTML.Raw('<span class="ilabel optional">giao hàng</span>'), "\n", Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("paymentsDeliverySelectOption")),
      "class": Spacebars.call("field")
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("iSelect"));
  })), "\n", HTML.DIV({
    "class": [ "editor-wrapper", " ", "pull-right" ]
  }, HTML.BUTTON({
    "class": function() {
      return [ "lemon", " ", "btn", " ", "lime", " ", "pull-right", " ", "finish", " ", Spacebars.mustache(view.lookup("allowSuccessOrder")) ];
    },
    type: "submit",
    style: "margin-right: 5px;"
  }, "HOÀN TẤT")), "\n", HTML.Raw('<div class="editor-wrapper pull-right"><button class="lemon btn blue pull-right print-preview" type="submit"><span class="icon-print-6"></span></button></div>'), "\n", HTML.DIV({
    "class": [ "editor-wrapper", " ", "pull-right" ],
    style: "width: 120px"
  }, HTML.Raw('<span class="ilabel optional right">thực thu</span>'), "\n", HTML.INPUT({
    "class": "quality",
    value: function() {
      return Spacebars.mustache(view.lookup("formatNumber"), Spacebars.dot(view.lookup("currentOrder"), "finalPrice"));
    },
    disabled: ""
  })), "\n", HTML.DIV({
    "class": [ "editor-wrapper", " ", "pull-right" ],
    style: "width: 120px"
  }, HTML.Raw('<span class="ilabel right">số dư</span>'), "\n", HTML.INPUT({
    "class": "debit",
    value: function() {
      return Spacebars.mustache(view.lookup("formatNumber"), view.lookup("currentDebit"));
    },
    disabled: ""
  })), "\n", HTML.DIV({
    "class": [ "editor-wrapper", " ", "pull-right" ],
    style: "width: 190px"
  }, HTML.Raw('<span class="ilabel center">tiền nhận vào</span>'), "\n", Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("depositOptions"))
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("iSpinEdit"));
  })), "\n", HTML.Raw('<!--.col.col-auto.pull-right(style="width: 120px")-->'), "\n", HTML.Raw("<!--  span.ilabel.center.optional tạm tính-->"), "\n", HTML.Raw('<!--  input.quality(value="{{currentOrder.totalPrice}}")-->'), "\n", ""), "\n", Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("tabOptions"))
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("tabComponent"));
  })) ];
}));

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var calculateCurrentDiscountCash;

calculateCurrentDiscountCash = function(val) {
  var option, total;
  option = {};
  option.currentDiscountPercent = val;
  total = logics.sales.currentOrder.currentQuality * logics.sales.currentOrder.currentPrice;
  if (val > 0) {
    option.currentDiscountCash = Math.round(total / 100 * val);
  } else {
    option.currentDiscountCash = 0;
  }
  if (logics.sales.currentOrder) {
    return Schema.orders.update(logics.sales.currentOrder._id, {
      $set: option
    });
  }
};

Apps.Merchant.salesInit.push(function() {
  return logics.sales.discountPercentOptions = {
    reactiveSetter: function(val) {
      return calculateCurrentDiscountCash(val);
    },
    reactiveValue: function() {
      var _ref, _ref1;
      return (_ref = (_ref1 = logics.sales.currentOrder) != null ? _ref1.currentDiscountPercent : void 0) != null ? _ref : 0;
    },
    reactiveMax: function() {
      return 100;
    },
    reactiveMin: function() {
      return 0;
    },
    reactiveStep: function() {
      return 1;
    }
  };
});

})();

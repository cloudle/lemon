(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var stockManagerRoute;

stockManagerRoute = {
  template: 'stockManager',
  waitOnDependency: 'stockManager',
  onBeforeAction: function() {
    if (this.ready()) {
      Apps.setup(logics.stockManager, Apps.Merchant.stockManagerInit, 'stockManager');
      return this.next();
    }
  },
  data: function() {
    var _ref, _ref1, _ref2, _ref3;
    logics.stockManager.reactiveRun();
    return {
      totalQualityProduct: (_ref = logics.stockManager.totalQualityProduct()) != null ? _ref : 0,
      totalStockProduct: (_ref1 = logics.stockManager.totalStockProduct()) != null ? _ref1 : 0,
      totalProduct: (_ref2 = (_ref3 = logics.stockManager.availableProducts) != null ? _ref3.count() : void 0) != null ? _ref2 : 0,
      gridOptions: logics.stockManager.gridOptions
    };
  }
};

lemon.addRoute([stockManagerRoute], Apps.Merchant.RouterBase);

})();

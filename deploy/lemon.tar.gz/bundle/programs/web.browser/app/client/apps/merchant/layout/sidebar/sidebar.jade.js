(function(){
Template.__define__("sidebar", (function() {
  var view = this;
  return HTML.DIV({
    id: "sidebar"
  }, HTML.DIV({
    "class": function() {
      return [ "collapse-toggle", " ", Spacebars.mustache(view.lookup("appCollapseClass")) ];
    }
  }), "\n", HTML.UL({
    "class": "messenger-list"
  }, Spacebars.TemplateWith(function() {
    return Spacebars.call(view.lookup("myProfile"));
  }, function() {
    return Spacebars.include(view.lookupTemplate("myAvatarItem"));
  }), "\n", Blaze.Each(function() {
    return Spacebars.call(view.lookup("friends"));
  }, function() {
    return Spacebars.include(view.lookupTemplate("chatAvatarItem"));
  })), "\n", Spacebars.include(view.lookupTemplate("messenger")));
}));

})();

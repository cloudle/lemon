(function(){
Template.__define__("addProvider", (function() {
  var view = this;
  return HTML.ASIDE({
    "class": [ "modal", " ", "swipe", " ", "left" ],
    id: "addProvider"
  }, HTML.DIV({
    "class": [ "modal-dialog", " ", "sale-bill-preview" ]
  }, HTML.Raw('<div class="modal-header"><button class="close" type="button" data-dismiss="modal"><span aria-hidden="true">&times;</span>\n<span class="sr-only">Close</span></button>\n<h4 class="modal-title"><i class="icon-search-8"></i>\nTHÊM NHÀ PHÂN PHỐI</h4></div>'), "\n", HTML.DIV({
    "class": [ "modal-body", " ", "printable-area" ]
  }, HTML.Raw('<div class="header"></div>'), "\n", HTML.Raw('<div class="merchant-info"><input class="form-control name" type="text" placeholder="Tên Công Ty">\n<input class="form-control address" type="text" placeholder="Địa Chỉ">\n<input class="form-control phone" type="text" placeholder="Số Điện Thoại">\n<div align="right"><a class="btn btn-danger create-provider">Tạo mới</a></div></div>'), "\n", HTML.UL(Blaze.Each(function() {
    return Spacebars.call(view.lookup("myCreateProvider"));
  }, function() {
    return HTML.LI({
      "class": "order-detail"
    }, HTML.DIV({
      "class": "product-name"
    }, Blaze.View(function() {
      return Spacebars.mustache(view.lookup("name"));
    }), "\n", Blaze.If(function() {
      return Spacebars.call(view.lookup("allowDelete"));
    }, function() {
      return HTML.BUTTON({
        "class": [ "btn", " ", "delete-provider" ],
        type: "button"
      }, "x");
    })), "\n", HTML.DIV({
      "class": "product-price"
    }, HTML.SPAN({
      "class": "individual-price"
    }, Blaze.View(function() {
      return Spacebars.mustache(view.lookup("phone"));
    })), "\n", HTML.SPAN({
      "class": "final-price"
    }, Blaze.View(function() {
      return Spacebars.mustache(view.lookup("address"));
    }))));
  })), "\n", HTML.Raw("<!--.bill-summary-->"), "\n", HTML.Raw("<!--.bill-footer-->")), "\n", HTML.Raw('<div class="modal-footer"><button class="btn btn-default" type="button" data-dismiss="modal">ĐÓNG</button></div>')));
}));

})();

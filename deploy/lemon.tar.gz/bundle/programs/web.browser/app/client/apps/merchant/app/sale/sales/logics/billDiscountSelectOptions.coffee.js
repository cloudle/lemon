(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var changedActionSelectDiscountCash, formatPaymentMethodSearch;

formatPaymentMethodSearch = function(item) {
  if (item) {
    return "" + item.display;
  }
};

changedActionSelectDiscountCash = function(discount) {
  var option;
  option = {
    billDiscount: discount
  };
  if (option.billDiscount) {
    option.discountCash = 0;
  }
  if (option.billDiscount) {
    option.discountPercent = 0;
  }
  Order.update(logics.sales.currentOrder._id, {
    $set: option
  });
  return logics.sales.reCalculateOrder(logics.sales.currentOrder._id);
};

Apps.Merchant.salesInit.push(function() {
  return logics.sales.billDiscountSelectOptions = {
    query: function(query) {
      return query.callback({
        results: Apps.Merchant.DiscountTypes,
        text: 'id'
      });
    },
    initSelection: function(element, callback) {
      var _ref;
      return callback(_.findWhere(Apps.Merchant.DiscountTypes, {
        _id: (_ref = Session.get('currentOrder')) != null ? _ref.billDiscount : void 0
      }));
    },
    formatSelection: formatPaymentMethodSearch,
    formatResult: formatPaymentMethodSearch,
    placeholder: 'CHỌN SẢN PTGD',
    minimumResultsForSearch: -1,
    changeAction: function(e) {
      return changedActionSelectDiscountCash(e.added._id);
    },
    reactiveValueGetter: function() {
      var _ref;
      return _.findWhere(Apps.Merchant.DiscountTypes, {
        _id: (_ref = Session.get('currentOrder')) != null ? _ref.billDiscount : void 0
      });
    }
  };
});

})();

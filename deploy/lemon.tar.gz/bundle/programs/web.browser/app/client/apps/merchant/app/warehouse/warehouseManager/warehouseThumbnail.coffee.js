(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineWidget(Template.warehouseThumbnail, {
  isntDelete: function() {
    if (!Schema.products.findOne({
      warehouse: this._id
    }) && this.isRoot === false) {
      return true;
    }
  },
  events: {
    "click .trash": function() {
      var product, warehouse;
      warehouse = Schema.warehouses.findOne({
        _id: this._id,
        isRoot: false
      });
      if (warehouse) {
        product = Schema.products.findOne({
          warehouse: warehouse._id
        });
        if (!product) {
          Schema.warehouses.remove(warehouse._id);
          return MetroSummary.updateMetroSummaryBy(['warehouse']);
        }
      }
    }
  }
});

})();

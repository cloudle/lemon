(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var calculateDepositAndDebit;

calculateDepositAndDebit = function(deposit, currentOrder) {
  var option;
  if (deposit >= currentOrder.finalPrice) {
    option = {
      currentDeposit: deposit,
      paymentMethod: 0,
      deposit: currentOrder.finalPrice,
      debit: 0
    };
  } else {
    option = {
      currentDeposit: deposit,
      paymentMethod: 1,
      deposit: deposit,
      debit: currentOrder.finalPrice - deposit
    };
  }
  return Order.update(currentOrder._id, {
    $set: option
  });
};

Apps.Merchant.salesInit.push(function() {
  return logics.sales.depositOptions = {
    reactiveSetter: function(val) {
      return calculateDepositAndDebit(val, logics.sales.currentOrder);
    },
    reactiveValue: function() {
      var _ref, _ref1;
      return (_ref = (_ref1 = Session.get('currentOrder')) != null ? _ref1.currentDeposit : void 0) != null ? _ref : 0;
    },
    reactiveMax: function() {
      return 99999999999;
    },
    reactiveMin: function() {
      return 0;
    },
    reactiveStep: function() {
      return 1000;
    },
    others: {
      forcestepdivisibility: 'none'
    }
  };
});

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
logics.warehouseManager.checkAllowCreate = function(context) {
  var name;
  name = context.ui.$name.val();
  if (name.length > 0) {
    return Session.set('allowCreateNewWarehouse', true);
  } else {
    return Session.set('allowCreateNewWarehouse', false);
  }
};

})();

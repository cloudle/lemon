(function(){
Template.__define__("importProductThumbnail", (function() {
  var view = this;
  return HTML.DIV({
    "class": "col"
  }, HTML.DIV({
    "class": function() {
      return [ "thumbnails", " ", [ Spacebars.mustache(view.lookup("styles")) ] ];
    }
  }, HTML.DIV({
    "class": "left-caption"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("expire"));
  })), "\n", HTML.DIV({
    "class": "right-caption"
  }, "(", Blaze.View(function() {
    return Spacebars.mustache(view.lookup("productCodeFromId"), view.lookup("product"));
  }), ") - ", Blaze.View(function() {
    return Spacebars.mustache(view.lookup("productNameFromId"), view.lookup("product"));
  })), "\n", HTML.Raw("<!--.avatar(style=\"background-image: url('images/missing.jpg')\")-->"), "\n", HTML.DIV({
    "class": [ "short-desc", " ", "quality" ]
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("pad"), view.lookup("importQuality"));
  })), "\n", HTML.DIV({
    "class": [ "full-desc", " ", "price" ]
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("formatNumber"), view.lookup("totalPrice"));
  }), " ", HTML.Raw("<small>VNĐ</small>")), "\n", HTML.DIV({
    "class": "single-price"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("formatNumber"), view.lookup("importPrice"));
  }), " VNĐ"), "\n", HTML.Raw('<div class="full-desc trash"><a href="#"><i class="icon-bag"></i></a></div>')));
}));

})();

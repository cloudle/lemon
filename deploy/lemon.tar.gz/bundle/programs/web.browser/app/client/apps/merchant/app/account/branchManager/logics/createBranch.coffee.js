(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var resetForm;

resetForm = function(context) {
  var item, _i, _len, _ref, _results;
  _ref = context.findAll("[name]");
  _results = [];
  for (_i = 0, _len = _ref.length; _i < _len; _i++) {
    item = _ref[_i];
    _results.push($(item).val(''));
  }
  return _results;
};

logics.branchManager.createBranch = function(context) {
  var address, name;
  name = context.ui.$name.val();
  address = context.ui.$address.val();
  if (Schema.merchants.findOne({
    name: name
  })) {
    return console.log('Chi Nhanh Ton Tai');
  } else {
    return Meteor.call('createNewBranch', name, address, function(error, result) {
      if (error) {
        return console.log(error.error);
      } else {
        resetForm(context);
        return Session.set('allowCreateNewBranch', false);
      }
    });
  }
};

})();

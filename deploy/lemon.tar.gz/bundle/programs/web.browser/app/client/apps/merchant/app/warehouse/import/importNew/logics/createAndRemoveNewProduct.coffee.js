(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Apps.Merchant.importInit.push(function(scope) {
  logics["import"].createNewProduct = function(event, template) {
    var name, productCode, result, skulls, warehouseId;
    warehouseId = Session.get('myProfile').currentWarehouse;
    productCode = template.find(".productCode").value;
    name = template.find(".name").value;
    skulls = [template.find(".skull").value];
    result = Product.createNew(productCode, name, skulls, warehouseId);
    console.log(result);
    if (result.error) {
      return console.log(result.error);
    } else {
      template.find(".productCode").value = null;
      template.find(".name").value = null;
      return template.find(".skull").value = null;
    }
  };
  return logics["import"].destroyNewProduct = function(productId) {
    var result;
    result = Product.destroyByCreator(productId);
    if (result.error) {
      return console.log(result.error);
    }
  };
});

})();

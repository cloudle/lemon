(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var reCalculateOrderDetail;

reCalculateOrderDetail = function(orderDetail, quality) {
  var option;
  option = {
    quality: orderDetail.quality + quality
  };
  option.totalPrice = option.quality * orderDetail.price;
  option.discountCash = Math.round(option.totalPrice * orderDetail.discountPercent / 100);
  option.finalPrice = option.totalPrice - option.discountCash;
  Schema.orderDetails.update(orderDetail._id, {
    $set: option
  });
  return logics.sales.reCalculateOrder(orderDetail.order);
};

lemon.defineWidget(Template.saleProductThumbnail, {
  avatarUrl: function() {
    var currentProduct, _ref, _ref1;
    currentProduct = Schema.products.findOne(this.product);
    return (_ref = (_ref1 = AvatarImages.findOne(currentProduct != null ? currentProduct.image : void 0)) != null ? _ref1.url() : void 0) != null ? _ref : void 0;
  },
  meterStyle: function() {
    var cross, stockPercentage, _ref, _ref1, _ref2;
    cross = logics.sales.validation.getCrossProductQuality(this.product, this.order);
    stockPercentage = (((_ref = cross.product) != null ? _ref.availableQuality : void 0) - cross.quality) / ((_ref1 = (_ref2 = cross.product) != null ? _ref2.upperGapQuality : void 0) != null ? _ref1 : 100);
    return {
      percent: stockPercentage * 100,
      color: Helpers.ColorBetween(255, 0, 0, 135, 196, 57, stockPercentage, 3)
    };
  },
  events: {
    "click .trash": function(event, template) {
      OrderDetail.remove(this._id);
      return logics.sales.reCalculateOrder(this.order);
    },
    "click .command-button.up": function() {
      var cross;
      cross = logics.sales.validation.getCrossProductQuality(this.product, this.order);
      if ((cross.product.availableQuality - cross.quality) > 0) {
        return reCalculateOrderDetail(this, 1);
      }
    },
    "click .command-button.down": function() {
      if (this.quality > 1) {
        return reCalculateOrderDetail(this, -1);
      }
    }
  }
});

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Apps.Merchant.accountingManagerInit.push(function(scope) {
  return logics.accountingManager.confirmReceiveSale = function(currentSale) {
    var option, transaction, transactionDetail, _ref, _ref1, _ref2, _ref3, _ref4, _ref5, _ref6;
    if ((((currentSale.received === (_ref2 = currentSale.imported) && _ref2 === (_ref1 = currentSale.exported)) && _ref1 === (_ref = currentSale.submitted)) && _ref === false) && currentSale.status === true) {
      option = {
        received: true
      };
      if (currentSale.paymentsDelivery === 1) {
        option.status = false;
        Schema.deliveries.update(currentSale.delivery, {
          $set: {
            status: 1
          }
        });
      }
      transaction = Transaction.newBySale(currentSale);
      transactionDetail = TransactionDetail.newByTransaction(transaction);
      Schema.sales.update(currentSale._id, {
        $set: option
      });
      MetroSummary.updateMetroSummaryBySale(currentSale._id);
      console.log('Kế toán đã nhận tiền.');
    }
    if ((((currentSale.status === (_ref5 = currentSale.success) && _ref5 === (_ref4 = currentSale.received)) && _ref4 === (_ref3 = currentSale.exported)) && _ref3 === true) && (currentSale.submitted === (_ref6 = currentSale.imported) && _ref6 === false) && currentSale.paymentsDelivery === 1) {
      return console.log('ok 2');
    }
  };
});

})();

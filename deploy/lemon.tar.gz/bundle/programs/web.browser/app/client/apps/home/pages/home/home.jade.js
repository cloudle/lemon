(function(){
Template.__define__("home", (function() {
  var view = this;
  return [ HTML.Raw('<!--.slider(style="width: 100%; height: 450px;")-->'), HTML.DIV({
    "class": [ "home-wrapper", " ", "home-video-section" ]
  }, HTML.Raw('<div class="main-left"><div class="youtube-wrapper"><iframe width="623" height="350" src="//www.youtube.com/embed/lzpE9_dMovU?rel=0&amp;showinfo=0&amp;autoplay=1" frameborder="0" allowfullscreen=""></iframe></div>\n<!--.title eds-->\n<!--p Mạng quản lý kinh doanh tho--></div>'), "\n", HTML.DIV({
    "class": "main-right"
  }, Blaze.If(function() {
    return Spacebars.call(view.lookup("authenticated"));
  }, function() {
    return HTML.DIV({
      "class": [ "login-section", " ", "animated", " ", "fadeInDown" ]
    }, HTML.DIV({
      id: "gotoMerchantButton",
      "class": [ "btn", " ", "icon-shop" ]
    }), "\n", HTML.DIV({
      id: "logoutButton",
      "class": [ "btn", " ", "icon-power", " ", "background-pumpkin" ]
    }));
  }, function() {
    return HTML.DIV({
      "class": [ "login-section", " ", "animated", " ", "fadeInDown" ]
    }, HTML.INPUT({
      "class": "login-field",
      id: "authAlias",
      type: "text",
      placeholder: function() {
        return Spacebars.mustache(view.lookup("i18n"), "form.userAccount");
      },
      maxlength: "50",
      tabindex: "1"
    }), "\n", HTML.INPUT({
      "class": "login-field",
      id: "authSecret",
      type: "password",
      placeholder: function() {
        return Spacebars.mustache(view.lookup("i18n"), "form.password");
      },
      maxlength: "30",
      tabindex: "2"
    }), "\n", HTML.DIV({
      id: "authButton",
      "class": function() {
        return [ "btn", " ", "icon-forward-3", " ", Spacebars.mustache(view.lookup("sessionGet"), "loginValid") ];
      },
      tabindex: "3"
    }));
  }), "\n", HTML.Raw('<div class="caption">ĐĂNG KÝ!</div>'), "\n", HTML.DIV({
    "class": "registeration-section"
  }, HTML.DIV({
    "class": "lemon-field"
  }, HTML.INPUT({
    id: "account",
    type: "text",
    placeholder: function() {
      return [ Spacebars.mustache(view.lookup("i18n"), "form.userAccount"), " *" ];
    }
  })), "\n", HTML.DIV({
    "class": [ "lemon-field", " ", "group", " ", "row" ]
  }, HTML.DIV({
    "class": [ "col", " ", "col-sm-7" ]
  }, HTML.INPUT({
    "class": function() {
      return [ "secret-field", " ", Spacebars.mustache(view.lookup("registerSecretValid")) ];
    },
    id: "secret",
    type: "password",
    placeholder: function() {
      return [ Spacebars.mustache(view.lookup("i18n"), "form.password"), "  *" ];
    }
  })), "\n", HTML.DIV({
    "class": [ "col", " ", "col-sm-5" ]
  }, HTML.INPUT({
    "class": function() {
      return [ "secret-field", " ", Spacebars.mustache(view.lookup("registerSecretValid")) ];
    },
    id: "secretConfirm",
    type: "password",
    placeholder: function() {
      return [ Spacebars.mustache(view.lookup("i18n"), "form.confirm"), " *" ];
    }
  }))), "\n", HTML.DIV({
    "class": [ "lemon-field", " ", "group", " ", "row" ]
  }, HTML.DIV({
    "class": [ "col", " ", "col-sm-7" ]
  }, HTML.INPUT({
    id: "companyName",
    type: "text",
    placeholder: function() {
      return Spacebars.mustache(view.lookup("i18n"), "form.companyName");
    }
  })), "\n", HTML.DIV({
    "class": [ "col", " ", "col-sm-5" ]
  }, HTML.INPUT({
    id: "companyPhone",
    type: "text",
    placeholder: function() {
      return Spacebars.mustache(view.lookup("i18n"), "form.contactPhone");
    },
    maxlength: "11"
  }))), "\n", HTML.Raw('<div class="lemon-field"><div class="accept-terms"><b>Đăng ký</b> sử dụng cũng đồng nghĩa với việc Bạn đã đọc và <b>đồng ý</b> với <b>Điều khoản</b> của Chúng tôi.</div></div>'), "\n", HTML.DIV({
    id: "merchantRegister",
    "class": function() {
      return [ "btn", " ", Spacebars.mustache(view.lookup("registerValid")) ];
    }
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("i18n"), "register");
  })), "\n", HTML.DIV({
    id: "terms",
    "class": function() {
      return [ "btn", " ", Spacebars.mustache(view.lookup("termButtonActive")) ];
    }
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("i18n"), "term");
  }))))), HTML.Raw('<div class="home-wrapper home-after-video-section"><div class="home-splitter"></div></div><div class="home-wrapper home-before-footer-section"><div class="home-splitter"></div></div>') ];
}));

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineWidget(Template.deliveryManagerThumbnail, {
  showSelectCommand: function() {
    return this.status === 1;
  },
  showStartCommand: function() {
    return this.status === 3;
  },
  showConfirmCommand: function() {
    return this.status === 4;
  },
  showFinishCommand: function() {
    return this.status === 6 || this.status === 9;
  },
  showCancelCommand: function() {
    return _.contains([2, 4, 5, 8, 9], this.status);
  },
  showStatus: function(status) {
    switch (status) {
      case 1:
        return 'Chưa được nhận ';
      case 2:
        return 'Chờ xác nhận kho';
      case 3:
        return 'Đã xác nhận xuất kho';
      case 4:
        return 'Đang Giao Hàng';
      case 5:
        return 'Giao Thành Công';
      case 6:
        return 'Kế Toán Đã Nhận Tiền';
      case 7:
        return 'Kết Thúc';
      case 8:
        return 'Giao Thất Bại';
      case 9:
        return 'Kho Đã Nhận Hàng';
      case 10:
        return 'Hoàn Tất';
    }
  },
  buttonSuccessText: function(status) {
    switch (status) {
      case 1:
        return 'nhận đơn giao hàng';
      case 3:
        return 'xác nhận đi giao hàng';
      case 4:
        return 'Thành Công';
      case 5:
        return 'Chờ Xác Nhận Của Kế Toán';
      case 6:
        return 'Xác Nhận';
      case 8:
        return 'Chờ Xác Nhân Của Kho';
      case 9:
        return 'Xác Nhận';
    }
  },
  buttonUnSuccessText: function(status) {
    if (status === 4) {
      return 'Thất Bại';
    }
  },
  hideButtonSuccess: function(status) {
    if (_.contains([2, 5, 7, 8, 10], status)) {
      return "display: none";
    }
  },
  hideButtonUnSuccess: function(status) {
    if (status !== 4) {
      return "display: none";
    }
  },
  customerAlias: function() {
    var _ref, _ref1;
    return (_ref = (_ref1 = Schema.customers.findOne(this.buyer)) != null ? _ref1.name : void 0) != null ? _ref : this.contactName;
  },
  avatarUrl: function() {
    var buyer, _ref;
    buyer = Schema.customers.findOne(this.buyer);
    if (!buyer) {
      return void 0;
    }
    return (_ref = AvatarImages.findOne(buyer.avatar)) != null ? _ref.url() : void 0;
  },
  events: {
    "click .select-command": function(event, template) {
      return Meteor.call("updateDelivery", this._id, 'select', function(error, result) {
        if (error) {
          return console.log(error);
        }
      });
    },
    "click .start-command": function() {
      return Meteor.call("updateDelivery", this._id, 'start', function(error, result) {
        if (error) {
          return console.log(error);
        }
      });
    },
    "click .fail-command": function() {
      return Meteor.call("updateDelivery", this._id, 'fail', function(error, result) {
        if (error) {
          return console.log(error);
        }
      });
    },
    "click .success-command": function() {
      return Meteor.call("updateDelivery", this._id, 'success', function(error, result) {
        if (error) {
          return console.log(error);
        }
      });
    },
    "click .finish-command": function() {
      return Meteor.call("updateDelivery", this._id, 'finish', function(error, result) {
        if (error) {
          return console.log(error);
        }
      });
    },
    "click .cancel-command": function(event, template) {
      return Meteor.call("updateDelivery", this._id, 'cancel', function(error, result) {
        if (error) {
          return console.log(error);
        }
      });
    }
  }
});

})();

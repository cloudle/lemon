(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Apps.Merchant.returnsInit.push(function(scope) {
  return logics.returns.gridOptions = {
    itemTemplate: 'returnProductThumbnail',
    reactiveSourceGetter: function() {
      return logics.returns.availableReturnDetails;
    },
    wrapperClasses: 'detail-grid row'
  };
});

})();

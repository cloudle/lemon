(function(){
Template.__define__("inventoryHistoryDetail", (function() {
  var view = this;
  return HTML.ASIDE({
    "class": [ "modal", " ", "swipe", " ", "left" ],
    id: "inventoryHistoryDetail"
  }, HTML.DIV({
    "class": [ "modal-dialog", " ", "sale-bill-preview" ]
  }, HTML.Raw('<div class="modal-header"><button class="close" type="button" data-dismiss="modal"><span aria-hidden="true">&times;</span>\n<span class="sr-only">Close</span></button>\n<h4 class="modal-title"><i class="icon-search-8"></i>\n<span>CHI TIẾT KIỂM KHO</span></h4></div>'), "\n", HTML.DIV({
    "class": [ "modal-body", " ", "printable-area" ]
  }, HTML.Raw('<div class="header"></div>'), "\n", HTML.DIV({
    "class": "merchant-info"
  }, HTML.SPAN({
    "class": "marchant-address"
  }, [ "Người tạo: ", Blaze.View(function() {
    return Spacebars.mustache(view.lookup("userNameFromId"), Spacebars.dot(view.lookup("inventory"), "creator"));
  }), " ", HTML.Raw("<br>") ], "\n", [ "Miêu tả: ", Blaze.View(function() {
    return Spacebars.mustache(Spacebars.dot(view.lookup("inventory"), "description"));
  }), " ", HTML.Raw("<br>") ], "\n", [ "Trạng thái: ", Blaze.View(function() {
    return Spacebars.mustache(view.lookup("status"));
  }) ])), "\n", HTML.UL(Blaze.If(function() {
    return Spacebars.call(Spacebars.dot(view.lookup("inventory"), "submit"));
  }, function() {
    return Blaze.Each(function() {
      return Spacebars.call(view.lookup("productLost"));
    }, function() {
      return HTML.LI({
        "class": "order-detail"
      }, HTML.DIV({
        "class": "product-name"
      }, HTML.B(Blaze.View(function() {
        return Spacebars.mustache(view.lookup("productNameFromId"), view.lookup("product"));
      })), " ", Blaze.View(function() {
        return Spacebars.mustache(view.lookup("skullsNameFromId"), view.lookup("product"));
      })), "\n", HTML.DIV({
        "class": "product-price"
      }, HTML.SPAN({
        "class": "individual-price"
      }, "* Mất: ", Blaze.View(function() {
        return Spacebars.mustache(view.lookup("formatNumber"), view.lookup("lostQuality"));
      })), "\n", HTML.Comment("span.final-price {{formatNumber totalPrice}}")));
    });
  }, function() {
    return Blaze.Each(function() {
      return Spacebars.call(view.lookup("inventoryDetails"));
    }, function() {
      return HTML.LI({
        "class": "order-detail"
      }, HTML.DIV({
        "class": "product-name"
      }, HTML.B(Blaze.View(function() {
        return Spacebars.mustache(view.lookup("productNameFromId"), view.lookup("product"));
      })), " ", Blaze.View(function() {
        return Spacebars.mustache(view.lookup("skullsNameFromId"), view.lookup("product"));
      })), "\n", HTML.DIV({
        "class": "product-price"
      }, HTML.SPAN({
        "class": "individual-price"
      }, "* Mất: ", Blaze.View(function() {
        return Spacebars.mustache(view.lookup("formatNumber"), view.lookup("lostQuality"));
      })), "\n", HTML.Comment("span.final-price {{formatNumber totalPrice}}"), "\n", null));
    });
  })), "\n", HTML.Raw("<!--.bill-summary-->"), "\n", HTML.Raw("<!--  span tổng cộng-->"), "\n", HTML.Raw("<!--  span.bill-final <b>{{formatNumber import.totalPrice}}</b> VNĐ-->"), "\n", HTML.Raw("<!--.bill-footer-->")), "\n", HTML.DIV({
    "class": "modal-footer"
  }, Blaze.If(function() {
    return Spacebars.call(view.lookup("showFinish"));
  }, function() {
    return HTML.BUTTON({
      "class": [ "lemon", " ", "btn", " ", "lime", " ", "icon-ok-6", " ", "finish" ]
    }, "XÁC NHẬN");
  }))));
}));

})();

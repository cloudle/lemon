(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
logics.returns.reCalculateReturn = function(returnId) {
  var detail, option, returnDetails, saleReturn, _i, _len;
  if (!(saleReturn = Schema.returns.findOne(returnId))) {
    return console.log("Phiếu trả hàng không tồn tại.");
  }
  returnDetails = Schema.returnDetails.find({
    "return": saleReturn._id
  }).fetch();
  option = {
    totalPrice: 0,
    productQuality: 0,
    productSale: 0
  };
  if (returnDetails.length > 0) {
    for (_i = 0, _len = returnDetails.length; _i < _len; _i++) {
      detail = returnDetails[_i];
      option.totalPrice += Math.round(detail.price * detail.returnQuality * (100 - detail.discountPercent) / 100);
      option.productQuality += detail.returnQuality;
      option.productSale += 1;
    }
    option.discountCash = (saleReturn.discountPercent * option.totalPrice) / 100;
    option.finallyPrice = option.totalPrice - option.discountCash;
  }
  return Schema.returns.update(saleReturn._id, {
    $set: option
  });
};

})();

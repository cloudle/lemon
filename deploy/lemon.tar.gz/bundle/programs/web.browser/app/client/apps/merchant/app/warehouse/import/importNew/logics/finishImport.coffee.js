(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var navigateNewTab;

navigateNewTab = function(currentImportId) {
  var allTabs, currentIndex, currentLength, currentSource, nextIndex;
  allTabs = logics["import"].myHistory.fetch();
  currentSource = _.findWhere(allTabs, {
    _id: currentImportId
  });
  currentIndex = allTabs.indexOf(currentSource);
  currentLength = allTabs.length;
  if (currentLength > 1) {
    nextIndex = currentIndex === currentLength - 1 ? currentIndex - 1 : currentIndex + 1;
    return UserSession.set('currentImport', allTabs[nextIndex]._id);
  } else {
    return logics["import"].createImportAndSelected();
  }
};

Apps.Merchant.importInit.push(function(scope) {
  return logics["import"].finish = function(importId) {
    var currentImport, importDetail, importDetails, myProfile, option1, option2, product, productDetail, transaction, transactionDetail, warehouseImport, _i, _j, _len, _len1;
    if (myProfile = Schema.userProfiles.findOne({
      user: Meteor.userId()
    })) {
      currentImport = Schema.imports.findOne({
        _id: importId,
        submitted: true,
        finish: false,
        merchant: myProfile.currentMerchant
      });
      if (currentImport) {
        importDetails = Schema.importDetails.find({
          "import": importId
        }).fetch();
        for (_i = 0, _len = importDetails.length; _i < _len; _i++) {
          importDetail = importDetails[_i];
          product = Schema.products.findOne(importDetail.product);
          if (!product) {
            return console.log('Không tìm thấy sản phẩm id:' + importDetail.product);
          }
        }
        for (_j = 0, _len1 = importDetails.length; _j < _len1; _j++) {
          importDetail = importDetails[_j];
          productDetail = ProductDetail.newProductDetail(currentImport, importDetail);
          Schema.productDetails.insert(productDetail, function(error, result) {
            if (error) {
              return console.log('Sai thông tin sản phẩm nhập kho');
            }
          });
          product = Schema.products.findOne(importDetail.product);
          option1 = {
            totalQuality: importDetail.importQuality,
            availableQuality: importDetail.importQuality,
            inStockQuality: importDetail.importQuality
          };
          option2 = {
            provider: importDetail.provider,
            importPrice: importDetail.importPrice
          };
          if (importDetail.salePrice) {
            option2.price = importDetail.salePrice;
          }
          Schema.products.update(product._id, {
            $inc: option1,
            $set: option2
          }, function(error, result) {
            if (error) {
              return console.log('Sai thông tin sản phẩm nhập kho');
            }
          });
        }
        navigateNewTab(currentImport._id);
        Schema.imports.update(currentImport._id, {
          $set: {
            finish: true,
            submitted: true
          }
        });
        warehouseImport = Schema.imports.findOne(importId);
        transaction = Transaction.newByImport(warehouseImport);
        transactionDetail = TransactionDetail.newByTransaction(transaction);
        MetroSummary.updateMetroSummaryByImport(importId);
      }
      return 'Phiếu nhập kho đã được duyệt';
    } else {
      return 'Đã có lỗi trong quá trình xác nhận';
    }
  };
});

})();

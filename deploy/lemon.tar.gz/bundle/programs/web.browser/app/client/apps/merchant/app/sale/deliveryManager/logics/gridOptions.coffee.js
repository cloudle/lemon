(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Apps.Merchant.deliveryManagerInit.push(function(scope) {
  scope.waitingGridOptions = {
    itemTemplate: 'deliveryManagerThumbnail',
    reactiveSourceGetter: function() {
      return scope.waitingDeliveries;
    }
  };
  scope.deliveringGridOptions = {
    itemTemplate: 'deliveryManagerThumbnail',
    reactiveSourceGetter: function() {
      return scope.deliveringDeliveries;
    }
  };
  return scope.doneGridOptions = {
    itemTemplate: 'deliveryManagerThumbnail',
    reactiveSourceGetter: function() {
      return scope.doneDeliveries;
    }
  };
});

})();

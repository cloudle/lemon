(function(){
Template.__define__("inventory", (function() {
  var view = this;
  return [ HTML.DIV({
    id: "header"
  }, HTML.Raw('<div class="caption-row"><div class="title">Kiểm Kho</div></div>'), "\n", HTML.DIV({
    "class": "editor-row"
  }, HTML.Raw('<div class="editor-wrapper pull-right"><button class="lemon btn amethyst icon-history inventoryHistory" type="submit">LỊCH SỬ</button></div>'), "\n", HTML.DIV({
    "class": "editor-wrapper",
    style: "width: 200px"
  }, HTML.Raw('<span class="ilabel">chi nhánh</span>'), "\n", Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("merchantSelectOptions")),
      "class": Spacebars.call("field")
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("iSelect"));
  })), "\n", HTML.DIV({
    "class": "editor-wrapper",
    style: "width: 200px"
  }, HTML.Raw('<span class="ilabel">kho</span>'), "\n", Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("warehouseSelectOptions")),
      "class": Spacebars.call("field")
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("iSelect"));
  })), "\n", HTML.DIV({
    "class": "editor-wrapper",
    style: function() {
      return [ "width: 200px; ", Spacebars.mustache(view.lookup("showDescription")) ];
    }
  }, HTML.Raw('<span class="ilabel">lý do kiểm kho</span>'), "\n", HTML.INPUT({
    name: "description",
    maxlength: "200",
    value: function() {
      return Spacebars.mustache(Spacebars.dot(view.lookup("currentInventory"), "description"));
    }
  })), "\n", HTML.DIV({
    "class": "editor-wrapper",
    style: function() {
      return [ "width:100px; ", Spacebars.mustache(view.lookup("showCreate")) ];
    }
  }, HTML.BUTTON({
    "class": function() {
      return [ "lemon", " ", "btn", " ", "lime", " ", "icon-plus-circled", " ", "createInventory", " ", Spacebars.mustache(view.lookup("allowCreate")) ];
    }
  }, "Tạo")), "\n", HTML.DIV({
    "class": "editor-wrapper",
    style: function() {
      return [ "width:100px; ", Spacebars.mustache(view.lookup("showDestroy")) ];
    }
  }, HTML.Raw('<button class="lemon btn pumpkin destroyInventory">Hủy</button>')), "\n", HTML.DIV({
    "class": "editor-wrapper",
    style: function() {
      return [ "width:100px; ", Spacebars.mustache(view.lookup("showSubmit")) ];
    }
  }, HTML.Raw('<button class="lemon btn lime icon-ok-6 submitInventory">Xác Nhận</button>')))), HTML.DIV({
    id: "content"
  }, Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("gridOptions"))
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("iGrid"));
  })) ];
}));

})();

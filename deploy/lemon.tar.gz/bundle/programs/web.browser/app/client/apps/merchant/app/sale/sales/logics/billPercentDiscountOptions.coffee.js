(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var calculateBillDiscountCash, reactiveMaxPercentDiscount, reactiveMinBillPercentDiscount;

calculateBillDiscountCash = function(discountPercent, currentOrder) {
  var option;
  if (currentOrder.billDiscount) {
    option = {
      discountPercent: discountPercent
    };
    if (discountPercent > 0) {
      if (discountPercent === 100) {
        option.discountCash = currentOrder.totalPrice;
      } else {
        option.discountCash = Math.round(currentOrder.totalPrice * option.discountPercent / 100);
      }
    } else {
      option.discountCash = 0;
    }
    option.finalPrice = currentOrder.totalPrice - option.discountCash;
  }
  return Order.update(currentOrder._id, {
    $set: option
  });
};

reactiveMaxPercentDiscount = function() {
  var _ref, _ref1, _ref2;
  if ((_ref = Session.get('currentOrder')) != null ? _ref.billDiscount : void 0) {
    return 100;
  } else {
    return (_ref1 = (_ref2 = Session.get('currentOrder')) != null ? _ref2.discountPercent : void 0) != null ? _ref1 : 0;
  }
};

reactiveMinBillPercentDiscount = function() {
  var _ref, _ref1, _ref2;
  if ((_ref = Session.get('currentOrder')) != null ? _ref.billDiscount : void 0) {
    return 0;
  } else {
    return (_ref1 = (_ref2 = Session.get('currentOrder')) != null ? _ref2.discountPercent : void 0) != null ? _ref1 : 0;
  }
};

Apps.Merchant.salesInit.push(function() {
  return logics.sales.billPercentDiscountOptions = {
    reactiveSetter: function(val) {
      return calculateBillDiscountCash(val, Session.get('currentOrder'));
    },
    reactiveValue: function() {
      var _ref, _ref1;
      return (_ref = Math.round(((_ref1 = Session.get('currentOrder')) != null ? _ref1.discountPercent : void 0) * 100) / 100) != null ? _ref : 0;
    },
    reactiveMax: function() {
      return reactiveMaxPercentDiscount();
    },
    reactiveMin: function() {
      return reactiveMinBillPercentDiscount();
    },
    reactiveStep: function() {
      return 1;
    },
    others: {
      forcestepdivisibility: 'none',
      decimals: 2
    }
  };
});

})();

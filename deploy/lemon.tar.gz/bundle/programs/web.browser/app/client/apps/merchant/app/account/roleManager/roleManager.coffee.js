(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineApp(Template.roleManager, {
  allowCreate: function() {
    if (Session.get('allowCreateNewRole')) {
      return '';
    } else {
      return 'disabled';
    }
  },
  created: function() {
    return logics.roleManager.rolesTemplateContext = this;
  },
  events: {
    "input [name='newGroupName']": function(event, template) {
      return logics.roleManager.checkAllowCreate(template);
    },
    "click #newGroupButton:not(.disabled)": function(event, template) {
      return logics.roleManager.createNewRole(event, template);
    },
    "click #updateButton": function(event, template) {
      return logics.roleManager.saveRoleOptions(event, template);
    }
  }
});

})();

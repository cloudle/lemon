(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var scope;

scope = logics.merchantWizard;

lemon.addRoute({
  path: '/merchantWizard',
  layoutTemplate: 'subHomeLayout',
  waitOnDependency: 'merchantPurchase',
  onBeforeAction: function() {
    if (this.ready()) {
      Apps.setup(scope, Apps.Home.merchantWizardInit, 'merchantWizard');
      return this.next();
    }
  },
  data: function() {
    Apps.setup(scope, Apps.Home.merchantWizardReactive);
    return {
      trialPackageOption: scope.trialPackageOption,
      oneYearsPackageOption: scope.oneYearsPackageOption,
      threeYearsPackageOption: scope.threeYearsPackageOption,
      fiveYearsPackageOption: scope.fiveYearsPackageOption,
      purchase: scope.purchase
    };
  }
});

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Apps.Merchant.importInit.push(function(scope) {
  return logics["import"].importDetailOptions = {
    itemTemplate: 'importProductThumbnail',
    reactiveSourceGetter: function() {
      return logics["import"].currentImportDetails;
    },
    wrapperClasses: 'detail-grid row'
  };
});

})();

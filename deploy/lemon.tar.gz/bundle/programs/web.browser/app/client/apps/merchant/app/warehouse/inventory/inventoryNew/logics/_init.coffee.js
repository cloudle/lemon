(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
logics.inventoryManager = {};

Apps.Merchant.inventoryManagerInit = [];

Apps.Merchant.inventoryReactiveRun = [];

Apps.Merchant.inventoryManagerInit.push(function(scope) {
  Session.setDefault('showCreateNewInventory', true);
  Session.setDefault('allowCreateNewInventory', false);
  return scope.availableMerchants = Schema.merchants.find({
    $or: [
      {
        _id: Session.get('myProfile').parentMerchant
      }, {
        parent: Session.get('myProfile').parentMerchant
      }
    ]
  });
});

Apps.Merchant.inventoryReactiveRun.push(function(scope) {
  var detail, _i, _len, _ref, _ref1, _ref2, _ref3, _ref4, _ref5, _ref6, _results;
  if (Session.get('mySession') && Session.get('myProfile')) {
    if (scope.currentMerchant = Schema.merchants.findOne(Session.get('mySession').currentInventoryBranchSelection)) {
      scope.currentWarehouse = Schema.warehouses.findOne({
        _id: Session.get('mySession').currentInventoryWarehouseSelection,
        merchant: scope.currentMerchant._id
      });
      if (!scope.currentWarehouse) {
        scope.currentWarehouse = Schema.warehouses.findOne({
          isRoot: true,
          merchant: scope.currentMerchant._id
        });
        UserSession.set('currentInventoryWarehouseSelection', (_ref = (_ref1 = scope.currentWarehouse) != null ? _ref1._id : void 0) != null ? _ref : 'skyReset');
      }
    } else {
      scope.currentMerchant = Schema.merchants.findOne(Session.get('myProfile').currentMerchant);
      scope.currentWarehouse = Schema.merchants.findOne(Session.get('myProfile').currentWarehouse);
      UserSession.set('currentInventoryBranchSelection', Session.get('myProfile').currentMerchant);
      UserSession.set('currentInventoryWarehouseSelection', Session.get('myProfile').currentWarehouse);
    }
  }
  if (scope.currentWarehouse) {
    scope.availableWarehouses = Schema.warehouses.find({
      merchant: scope.currentWarehouse.merchant
    });
    scope.productDetails = Schema.productDetails.find({
      warehouse: scope.currentWarehouse._id
    });
    if (scope.currentWarehouse.inventory) {
      if (scope.currentInventory) {
        if (scope.currentInventory._id !== scope.currentWarehouse.inventory) {
          scope.currentInventory = Schema.inventories.findOne(scope.currentWarehouse.inventory);
          Meteor.subscribe('inventoryDetailInWarehouse', scope.currentInventory._id);
        }
      } else {
        scope.currentInventory = Schema.inventories.findOne(scope.currentWarehouse.inventory);
        Meteor.subscribe('inventoryDetailInWarehouse', scope.currentInventory._id);
      }
      scope.inventoryDetails = Schema.inventoryDetails.find({
        inventory: scope.currentInventory._id
      });
    }
  }
  scope.allowCreate = ((_ref2 = scope.currentWarehouse) != null ? _ref2.checkingInventory : void 0) || !Session.get('allowCreateNewInventory') ? 'disabled' : '';
  scope.showCreate = ((_ref3 = scope.currentWarehouse) != null ? _ref3.checkingInventory : void 0) ? "display: none" : "";
  scope.showDescription = ((_ref4 = scope.currentWarehouse) != null ? _ref4.checkingInventory : void 0) === true ? "display: none" : "";
  scope.showDestroy = scope.currentInventory ? "" : "display: none";
  if (scope.currentInventory && ((_ref5 = scope.inventoryDetails) != null ? _ref5.count() : void 0) > 0) {
    scope.showSubmit = "";
    _ref6 = scope.inventoryDetails.fetch();
    _results = [];
    for (_i = 0, _len = _ref6.length; _i < _len; _i++) {
      detail = _ref6[_i];
      if (detail.lock === false || detail.submit === false || detail.success === true) {
        scope.showSubmit = "display: none";
        break;
      } else {
        _results.push(void 0);
      }
    }
    return _results;
  } else {
    return scope.showSubmit = "display: none";
  }
});

})();

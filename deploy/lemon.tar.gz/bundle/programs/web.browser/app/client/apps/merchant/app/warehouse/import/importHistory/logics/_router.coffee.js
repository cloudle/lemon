(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var importHistoryRoute;

importHistoryRoute = {
  template: 'importHistory',
  waitOnDependency: 'importHistory',
  onBeforeAction: function() {
    if (this.ready()) {
      Apps.setup(logics.importHistory, Apps.Merchant.importHistoryInit, 'importHistory');
      return this.next();
    }
  },
  data: function() {
    Apps.setup(logics.importHistory, Apps.Merchant.importHistoryReactiveRun);
    return {
      gridOptions: logics.importHistory.gridOptions,
      branchSelectOptions: logics.importHistory.branchSelectOptions,
      warehouseSelectOptions: logics.importHistory.warehouseSelectOptions,
      currentImport: Session.get('currentImportHistory'),
      currentImportDetail: logics.importHistory.currentImportHistoryDetail
    };
  }
};

lemon.addRoute([importHistoryRoute], Apps.Merchant.RouterBase);

})();

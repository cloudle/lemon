(function(){
Template.__define__("exportAndImportManager", (function() {
  var view = this;
  return [ HTML.Raw('<div id="header"><div class="caption-row"><div class="title">XÁC NHẬN XUẤT NHẬP KHO</div></div>\n<div class="editor-row"><div class="editor-wrapper" style="width: 100px"><span class="ilabel right">xem từ ngày</span>\n<input name="fromDate" binding="datePicker" todayHighlight="true" maxlength="20"></div>\n<div class="editor-wrapper" style="width: 100px"><span class="ilabel">đến ngày</span>\n<input name="toDate" binding="datePicker" todayHighlight="true" maxlength="20"></div>\n<div class="editor-wrapper"><button class="lemon btn lime icon-ok-6" id="filterBills">ÁP DỤNG</button></div>\n<!--.editor-wrapper.pull-right(style="width: 200px")-->\n<!--  span.ilabel chọn kho-->\n<!--  +iSelect(options=warehouseSelectOptions class="field")-->\n</div></div>'), HTML.DIV({
    id: "content"
  }, Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("gridOptions"))
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("iGrid"));
  })) ];
}));

})();

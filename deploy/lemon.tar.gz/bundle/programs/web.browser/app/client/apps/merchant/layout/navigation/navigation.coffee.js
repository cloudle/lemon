(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineApp(Template.navigation, {
  unreadMessageCount: function() {
    return logics.merchantNotification.unreadMessages.count();
  },
  unreadNotifiesCount: function() {
    return logics.merchantNotification.unreadNotifies.count();
  },
  unreadRequestCount: function() {
    return logics.merchantNotification.unreadRequests.count();
  },
  subMenus: function() {
    return Session.get('subMenus');
  },
  tourVisible: function() {
    return true;
  },
  events: {
    "click #logoutButton": function(event, template) {
      return lemon.logout('/');
    },
    "click a.branding": function() {
      Session.set('autoNatigateDashboardOff', true);
      return Router.go('/');
    },
    "click .tour-toggle": function() {
      var _ref;
      return (_ref = Apps.currentTour) != null ? _ref.restart() : void 0;
    }
  }
});

})();

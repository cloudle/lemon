(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineWidget(Template.transportHistoryThumbnail, {
  colorClass: function() {
    if (this.submit === false && this.success === false) {
      return 'lime';
    }
    if (this.submit === true && this.success === false) {
      return 'orange';
    }
    if (this.submit === true && this.success === true) {
      return 'belize-hole';
    }
  },
  status: function() {
    if (this.submit === false && this.success === false) {
      return 'Checking';
    }
    if (this.submit === true && this.success === false) {
      return 'Fail';
    }
    if (this.submit === true && this.success === true) {
      return 'Success';
    }
  },
  creatorName: function(id) {
    var _ref;
    return (_ref = Schema.userProfiles.findOne({
      user: id
    })) != null ? _ref.fullName : void 0;
  },
  createDate: function() {
    return moment(this.version.updateAt).format("DD/MM/YYYY");
  },
  events: {
    'click .full-desc.trash': function() {
      return UserSession.get('currentInventoryHistory', this._id);
    }
  }
});

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Apps.Merchant.transactionManagerInit.push(function(scope) {
  scope.totalCashOptions = {
    reactiveSetter: function(val) {
      var createNewTransaction;
      createNewTransaction = Session.get('createNewTransaction');
      createNewTransaction.totalCash = val;
      return Session.set('createNewTransaction', createNewTransaction);
    },
    reactiveValue: function() {
      var _ref, _ref1;
      return (_ref = (_ref1 = Session.get('createNewTransaction')) != null ? _ref1.totalCash : void 0) != null ? _ref : 0;
    },
    reactiveMax: function() {
      var _ref, _ref1;
      return (_ref = (_ref1 = Session.get('createNewTransaction')) != null ? _ref1.maxCash : void 0) != null ? _ref : 0;
    },
    reactiveMin: function() {
      return 0;
    },
    reactiveStep: function() {
      return 10000;
    }
  };
  return scope.depositCashOptions = {
    reactiveSetter: function(val) {
      var createNewTransaction;
      createNewTransaction = Session.get('createNewTransaction');
      createNewTransaction.depositCash = val;
      return Session.set('createNewTransaction', createNewTransaction);
    },
    reactiveValue: function() {
      var _ref, _ref1;
      return (_ref = (_ref1 = Session.get('createNewTransaction')) != null ? _ref1.depositCash : void 0) != null ? _ref : 0;
    },
    reactiveMax: function() {
      var _ref, _ref1;
      return (_ref = (_ref1 = Session.get('createNewTransaction')) != null ? _ref1.totalCash : void 0) != null ? _ref : 0;
    },
    reactiveMin: function() {
      return 0;
    },
    reactiveStep: function() {
      return 10000;
    }
  };
});

})();

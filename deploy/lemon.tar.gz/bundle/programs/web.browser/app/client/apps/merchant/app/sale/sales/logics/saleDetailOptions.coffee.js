(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Apps.Merchant.salesInit.push(function() {
  return logics.sales.saleDetailOptions = {
    itemTemplate: 'saleProductThumbnail',
    reactiveSourceGetter: function() {
      return logics.sales.currentOrderDetails;
    }
  };
});

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineApp(Template.customerManager, {
  created: function() {
    Session.setDefault('allowCreateNewCustomer', false);
    return Session.setDefault('genderNewCustomer', true);
  },
  events: {
    "input input": function(event, template) {
      return logics.customerManager.checkAllowCreate(template);
    },
    "click #createCustomerAccount": function(event, template) {
      return logics.customerManager.createNewCustomer(template);
    },
    "change [name='genderMode']": function(event, template) {
      return Session.set('genderNewCustomer', event.target.checked);
    },
    "click .thumbnails": function(event, template) {
      return $(template.find('#customerProfileManager')).modal();
    },
    "click .excel-customer": function(event, template) {
      return $(".excelFileSource").click();
    },
    "change .excelFileSource": function(event, template) {
      var $excelSource;
      if (event.target.files.length > 0) {
        console.log('importing');
        $excelSource = $(".excelFileSource");
        $excelSource.parse({
          config: {
            complete: function(results, file) {
              if (file.type === "text/csv") {
                return console.log(results.data);
              }
            }
          }
        });
        return $excelSource.val("");
      }
    }
  }
});

})();

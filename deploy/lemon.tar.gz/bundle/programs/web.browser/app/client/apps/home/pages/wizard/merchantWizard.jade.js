(function(){
Template.__define__("merchantWizard", (function() {
  var view = this;
  return HTML.DIV({
    "class": "home-wrapper"
  }, HTML.Raw('<div class="merchant-wizard-instructions"><span class="caption">Chúc mừng bạn đã đăng ký thành công! <br></span>\n<span class="description">Chọn gói sản phẩm phù hợp và tiếp tục.</span></div>\n'), HTML.DIV({
    "class": "merchant-wizard-fields"
  }, HTML.DIV({
    "class": "editor-wrapper"
  }, HTML.Raw('<span class="ilabel optional">tên doanh nghiệp</span>'), "\n", HTML.INPUT({
    id: "companyName",
    type: "text",
    placeholder: "tên doanh nghiệp *",
    value: function() {
      return Spacebars.mustache(Spacebars.dot(view.lookup("purchase"), "companyName"));
    }
  })), "\n", HTML.DIV({
    "class": "editor-wrapper"
  }, HTML.Raw('<span class="ilabel optional">số điên thoại</span>'), "\n", HTML.INPUT({
    id: "companyPhone",
    type: "text",
    placeholder: "số điên thoại *",
    value: function() {
      return Spacebars.mustache(Spacebars.dot(view.lookup("purchase"), "contactPhone"));
    }
  })), "\n", HTML.DIV({
    "class": "editor-wrapper"
  }, HTML.Raw('<span class="ilabel optional right">tên chi nhánh chính</span>'), "\n", HTML.INPUT({
    id: "merchantName",
    type: "text",
    placeholder: "tên chi nhánh chính *",
    value: function() {
      return Spacebars.mustache(Spacebars.dot(view.lookup("purchase"), "merchantName"));
    }
  })), "\n", HTML.DIV({
    "class": "editor-wrapper"
  }, HTML.Raw('<span class="ilabel optional right">tên kho hàng chính</span>'), "\n", HTML.INPUT({
    id: "warehouseName",
    type: "text",
    placeholder: "tên kho hàng chính *",
    value: function() {
      return Spacebars.mustache(Spacebars.dot(view.lookup("purchase"), "warehouseName"));
    }
  }))), "\n", HTML.DIV({
    "class": [ "price-table-group", " ", "row" ]
  }, HTML.DIV({
    "class": [ "col", " ", "col-sm-3" ]
  }, Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("trialPackageOption"))
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("merchantPriceTable"));
  })), "\n", HTML.DIV({
    "class": [ "col", " ", "col-sm-3" ]
  }, Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("oneYearsPackageOption"))
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("merchantPriceTable"));
  })), "\n", HTML.DIV({
    "class": [ "col", " ", "col-sm-3" ]
  }, Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("threeYearsPackageOption"))
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("merchantPriceTable"));
  })), "\n", HTML.DIV({
    "class": [ "col", " ", "col-sm-3" ]
  }, Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("fiveYearsPackageOption"))
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("merchantPriceTable"));
  }))), "\n", HTML.TABLE({
    "class": "wizard-price-addon"
  }, HTML.TR(HTML.TD(), "\n", HTML.TD({
    width: "15%",
    align: "right"
  }, "SỐ LƯỢNG"), "\n", HTML.TD({
    width: "20%",
    align: "right"
  }, "GIÁ ĐƠN VỊ"), "\n", HTML.TD({
    width: "15%",
    align: "right"
  }, "THỜI HẠN ", HTML.SUP("(NĂM)")), "\n", HTML.TD({
    width: "20%",
    align: "right"
  }, "TỔNG CỘNG")), "\n", HTML.TR(HTML.TD(HTML.SPAN({
    "class": "icon-group"
  }), "\n", HTML.SPAN({
    "class": "pull-right"
  }, "TÀI KHOẢN CỘNG THÊM")), "\n", HTML.TD({
    align: "right"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("sessionGet"), "wizardAccountPlus");
  })), "\n", HTML.TD({
    align: "right"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("formatNumber"), view.lookup("accountExtendPrice"));
  }), " VNĐ"), "\n", HTML.TD({
    align: "right"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("packageYears"));
  })), "\n", HTML.TD({
    align: "right"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("formatNumber"), view.lookup("finalAccountExtendPrice"));
  }), " VNĐ")), "\n", HTML.TR(HTML.TD(HTML.SPAN({
    "class": "icon-location-1"
  }), "\n", HTML.SPAN({
    "class": "pull-right"
  }, "CHI NHÁNH CỘNG THÊM")), "\n", HTML.TD({
    align: "right"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("sessionGet"), "wizardBranchPlus");
  })), "\n", HTML.TD({
    align: "right"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("formatNumber"), view.lookup("branchExtendPrice"));
  }), " VNĐ"), "\n", HTML.TD({
    align: "right"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("packageYears"));
  })), "\n", HTML.TD({
    align: "right"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("formatNumber"), view.lookup("finalBranchExtendPrice"));
  }), " VNĐ")), "\n", HTML.TR(HTML.TD(HTML.SPAN({
    "class": "icon-home-4"
  }), "\n", HTML.SPAN({
    "class": "pull-right"
  }, "KHO HÀNG CỘNG THÊM")), "\n", HTML.TD({
    align: "right"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("sessionGet"), "wizardWarehousePlus");
  })), "\n", HTML.TD({
    align: "right"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("formatNumber"), view.lookup("warehouseExtendPrice"));
  }), " VNĐ"), "\n", HTML.TD({
    align: "right"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("packageYears"));
  })), "\n", HTML.TD({
    "class": "bottom-dash",
    align: "right"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("formatNumber"), view.lookup("finalWarehouseExtendPrice"));
  }), " VNĐ")), "\n", HTML.TR(HTML.TD(), "\n", HTML.TD(), "\n", HTML.TD(), "\n", HTML.TD(), "\n", HTML.TD({
    "class": "bold-font",
    align: "right"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("formatNumber"), view.lookup("crossFinalExtendPrice"));
  }), " VNĐ")), "\n", HTML.TR(HTML.TD(), "\n", HTML.TD(), "\n", HTML.TD(), "\n", HTML.TD({
    align: "right"
  }, "+ ", Blaze.View(function() {
    return Spacebars.mustache(view.lookup("formatNumber"), view.lookup("packagePrice"));
  })), "\n", HTML.TD({
    "class": "bold-font",
    align: "right"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("formatNumber"), view.lookup("crossFinalPrice"));
  }), " VNĐ"))), "\n", HTML.DIV({
    "class": function() {
      return [ "finish-register", " ", "btn", " ", "icon-award", " ", Spacebars.mustache(view.lookup("updateValid")) ];
    }
  }, "HOÀN TẤT"), HTML.Raw('\n<div class="register-logout btn">ĐĂNG XUẤT</div>'));
}));

})();

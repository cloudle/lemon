(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var comments, navigateComment;

comments = [
  {
    name: function() {
      return 'Nguyễn Thị Ngọc Tuyền';
    },
    position: function() {
      return 'Khu du lịch sinh thái (Tiền Giang)';
    },
    avatar: function() {
      return 'c.tuyen.jpg';
    },
    comment: function() {
      return "Vào những ngày cuối tuần hay dịp lễ Tết, khách đến tham quan rất nhiều, hệ thống nhắc nhở tự động giúp chúng tôi chủ động hơn trong việc chăm sóc khách hàng.";
    }
  }, {
    name: function() {
      return 'Phan Ngọc Vinh';
    },
    position: function() {
      return 'Chủ xưởng gỗ Vinh Phát (Đắc Lắc)';
    },
    avatar: function() {
      return 'a.vinh.jpg';
    },
    comment: function() {
      return "Tôi đã tìm hiểu qua nhiều phần mềm quản lý trước khi quyết định sử dụng EDS. Đây là phần mềm tiện dụng nhất mà tôi từng biết, tôi rất ấn tượng với giao diện metro, rất đẹp và dễ hiểu.";
    }
  }, {
    name: function() {
      return 'Nguyễn Anh Phương';
    },
    position: function() {
      return 'Du học sinh (Mỹ)';
    },
    avatar: function() {
      return 'a.phuong.jpg';
    },
    comment: function() {
      return "Bạn sẽ cảm thấy may mắn khi đối thủ của mình chưa biết tới hệ thống này, nó là công cụ tạo ra sự khác biệt cho doanh nghiệp của bạn, tôi cá là bạn cũng sẽ bị ấn tượng bởi chức năng trò chuyện công việc giống như tôi.";
    }
  }, {
    name: function() {
      return 'Nguyễn Ngọc Giàu';
    },
    position: function() {
      return 'Chủ nhà hàng New Coffee Bar (Mỹ Tho - Tiền Giang)';
    },
    avatar: function() {
      return 'c.giau.jpg';
    },
    comment: function() {
      return "Việc kinh doanh của tôi đã thuận lợi hơn rất nhiều, có thể cùng lúc được nhiều việc hơn và tập trung vào tăng trưởng và mở rộng kinh doanh.";
    }
  }
];

navigateComment = function(step) {
  var currentCommentIndex;
  if (step == null) {
    step = 1;
  }
  currentCommentIndex = Session.get('currentCommentPosition');
  console.log(currentCommentIndex, comments.length);
  currentCommentIndex += step;
  if (currentCommentIndex >= comments.length) {
    currentCommentIndex = 0;
  } else if (currentCommentIndex < 0) {
    currentCommentIndex = comments.length - 1;
  }
  Session.set('currentCommentPosition', currentCommentIndex);
  return Sky.helpers.animateUsing("#home-comment-wrapper", "fadeIn");
};

lemon.defineWidget(Template.merchantTestimonials, {
  currentComment: function() {
    return comments[Session.get('currentCommentPosition')];
  },
  created: function() {
    return Session.set('currentCommentPosition', 0);
  },
  events: {
    'click .nextCommand': function() {
      return navigateComment();
    },
    'click .previousCommand': function() {
      return navigateComment(-1);
    }
  }
});

})();

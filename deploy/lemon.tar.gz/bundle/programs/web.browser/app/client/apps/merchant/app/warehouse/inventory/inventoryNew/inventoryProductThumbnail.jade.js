(function(){
Template.__define__("inventoryProductThumbnail", (function() {
  var view = this;
  return HTML.DIV({
    "class": "col"
  }, HTML.DIV({
    "class": function() {
      return [ "thumbnails", " ", [ Spacebars.mustache(view.lookup("colorClass")) ] ];
    }
  }, HTML.DIV({
    "class": "left-caption"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("expireDate"), Spacebars.dot(view.lookup("productDetail"), "expire"));
  })), "\n", HTML.DIV({
    "class": "right-caption"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("productNameFromId"), view.lookup("product"));
  })), "\n", HTML.DIV({
    "class": [ "short-desc", " ", "quality" ]
  }, HTML.Raw('<div class="col col-auto pull-right" style="width:120px"></div>'), "\n", Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("realQualityOptions"))
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("iSpinEdit"));
  })), "\n", HTML.DIV({
    "class": [ "full-desc", " ", "price" ]
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("status"));
  }), " -- Tồn Kho: ", Blaze.View(function() {
    return Spacebars.mustache(view.lookup("originalQuality"));
  })), "\n", HTML.DIV({
    "class": "single-price"
  }, "Đã Bán: ", Blaze.View(function() {
    return Spacebars.mustache(view.lookup("saleQuality"));
  }), " / Mất ", Blaze.View(function() {
    return Spacebars.mustache(view.lookup("lostQuality"));
  })), "\n", HTML.DIV({
    "class": [ "full-desc", " ", "trash" ]
  }, HTML.A({
    href: "#"
  }, HTML.I({
    "class": "icon-reply-3",
    style: function() {
      return Spacebars.mustache(view.lookup("hideReply"));
    }
  }), "\n", HTML.I({
    "class": "icon-lock",
    style: function() {
      return Spacebars.mustache(view.lookup("hideLock"));
    }
  }), "\n", HTML.I({
    "class": "icon-ok-6",
    style: function() {
      return Spacebars.mustache(view.lookup("hideCheck"));
    }
  })))));
}));

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
logics.billManager = {};

Apps.Merchant.billManagerInit = [];

Apps.Merchant.billManagerInit.push(function(scope) {
  var date, firstDay, lastDay;
  date = new Date();
  firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
  lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0);
  Session.set('billFilterStartDate', firstDay);
  return Session.set('billFilterToDate', lastDay);
});

logics.billManager.reactiveRun = function() {
  if (Session.get('billFilterStartDate') && Session.get('billFilterToDate') && Session.get('myProfile')) {
    logics.billManager.availableBills = Sale.findBillDetails(Session.get('billFilterStartDate'), Session.get('billFilterToDate'), Session.get('myProfile').currentWarehouse);
  }
  if (Session.get('currentBillManagerSale')) {
    return logics.billManager.currentSaleDetails = Schema.saleDetails.find({
      sale: Session.get('currentBillManagerSale')._id
    });
  }
};

})();

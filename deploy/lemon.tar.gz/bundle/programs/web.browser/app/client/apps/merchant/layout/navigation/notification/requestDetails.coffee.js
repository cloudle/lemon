(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineWidget(Template.requestDetails, {
  requests: function() {
    return logics.merchantNotification.requests;
  },
  unreadRequests: function() {
    return logics.merchantNotification.unreadRequests;
  }
});

})();

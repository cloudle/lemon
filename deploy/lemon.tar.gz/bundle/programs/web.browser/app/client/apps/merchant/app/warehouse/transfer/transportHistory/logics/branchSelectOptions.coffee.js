(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var formatMerchantSearch;

formatMerchantSearch = function(item) {
  if (item) {
    return "" + item.name;
  }
};

Apps.Merchant.transportHistoryInit.push(function(scope) {
  return scope.branchSelectOptions = {
    query: function(query) {
      return query.callback({
        results: scope.availableMerchants.fetch()
      });
    },
    initSelection: function(element, callback) {
      var _ref, _ref1;
      return callback((_ref = Schema.merchants.findOne((_ref1 = Session.get('mySession')) != null ? _ref1.currentTransportBranchSelection : void 0)) != null ? _ref : 'skyReset');
    },
    reactiveValueGetter: function() {
      var _ref, _ref1;
      return (_ref = (_ref1 = Session.get('mySession')) != null ? _ref1.currentTransportBranchSelection : void 0) != null ? _ref : 'skyReset';
    },
    changeAction: function(e) {
      var option;
      option = {
        currentTransportBranchSelection: e.added._id,
        currentTransportWarehouseSelection: Schema.warehouses.findOne({
          merchant: e.added._id,
          isRoot: true
        })._id
      };
      Schema.userSessions.update(Session.get('mySession')._id, {
        $set: option
      });
      return scope.availableWarehouses = Schema.warehouses.find({
        merchant: e.added._id
      });
    },
    minimumResultsForSearch: -1,
    formatSelection: formatMerchantSearch,
    formatResult: formatMerchantSearch,
    placeholder: 'CHỌN CHI NHÁNH'
  };
});

})();

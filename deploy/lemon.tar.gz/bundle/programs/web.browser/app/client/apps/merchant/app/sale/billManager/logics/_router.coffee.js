(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var billManagerRoute;

billManagerRoute = {
  template: 'billManager',
  waitOnDependency: 'billManager',
  onBeforeAction: function() {
    if (this.ready()) {
      Apps.setup(logics.billManager, Apps.Merchant.billManagerInit, 'billManager');
      return this.next();
    }
  },
  data: function() {
    logics.billManager.reactiveRun();
    return {
      gridOptions: logics.billManager.gridOptions,
      currentSale: Session.get('currentBillManagerSale'),
      currentSaleDetails: logics.billManager.currentSaleDetails
    };
  }
};

lemon.addRoute([billManagerRoute], Apps.Merchant.RouterBase);

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineApp(Template.transportHistory, {
  rendered: function() {
    $("[name=fromDate]").datepicker('setDate', Session.get('transportHistoryFilterStartDate'));
    return $("[name=toDate]").datepicker('setDate', Session.get('transportHistoryFilterToDate'));
  },
  events: {
    "click .createTransport": function(event, template) {
      return Router.go('/transport');
    },
    "click #filterTransportHistories": function(event, template) {
      Session.set('transportHistoryFilterStartDate', $("[name=fromDate]").datepicker().data().datepicker.dates[0]);
      return Session.set('transportHistoryFilterToDate', $("[name=toDate]").datepicker().data().datepicker.dates[0]);
    },
    "click .thumbnails": function(event, template) {
      Meteor.subscribe('productLostInTransport', this._id);
      Meteor.subscribe('transportDetailInWarehouse', this._id);
      Session.set('currentTransportHistory', this);
      return $(template.find('#transportHistoryDetail')).modal();
    }
  }
});

})();

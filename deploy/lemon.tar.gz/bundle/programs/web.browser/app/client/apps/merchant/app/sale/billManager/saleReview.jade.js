(function(){
Template.__define__("saleReview", (function() {
  var view = this;
  return HTML.ASIDE({
    "class": [ "modal", " ", "swipe", " ", "left" ],
    id: "salePreview"
  }, HTML.DIV({
    "class": [ "modal-dialog", " ", "sale-bill-preview" ]
  }, HTML.Raw('<div class="modal-header"><button class="close" type="button" data-dismiss="modal"><span aria-hidden="true">&times;</span>\n<span class="sr-only">Close</span></button>\n<h4 class="modal-title"><i class="icon-search-8"></i>\nXEM PHIẾU BÁN HÀNG</h4></div>'), "\n", HTML.DIV({
    "class": [ "modal-body", " ", "printable-area" ]
  }, HTML.DIV({
    "class": "header"
  }, HTML.SPAN(HTML.B(Blaze.View(function() {
    return Spacebars.mustache(view.lookup("timeDMY"));
  })), " ngày ", HTML.B(Blaze.View(function() {
    return Spacebars.mustache(view.lookup("fullDay"));
  })), ", ", HTML.Raw("<br>")), "\n", HTML.SPAN(HTML.B(Blaze.View(function() {
    return Spacebars.mustache(view.lookup("timeHM"));
  }), HTML.SUP(Blaze.View(function() {
    return Spacebars.mustache(view.lookup("timeS"));
  }))), " (giờ ăn trưa),", HTML.B(" ", Blaze.View(function() {
    return Spacebars.mustache(view.lookup("formatNumberK"), Spacebars.dot(view.lookup("sale"), "finalPrice"));
  })), "k")), "\n", HTML.Raw('<div class="merchant-info"><span class="merchant-name">C.TY GI DO <br></span>\n<span class="marchant-address">Dia chi cong ty gi do</span></div>'), "\n", HTML.UL(Blaze.Each(function() {
    return Spacebars.call(view.lookup("saleDetails"));
  }, function() {
    return HTML.LI({
      "class": "order-detail"
    }, HTML.DIV({
      "class": "product-name"
    }, HTML.B(Blaze.View(function() {
      return Spacebars.mustache(view.lookup("formatNumber"), view.lookup("quality"));
    })), " ", Blaze.View(function() {
      return Spacebars.mustache(view.lookup("productNameFromId"), view.lookup("product"));
    })), "\n", HTML.DIV({
      "class": "product-price"
    }, HTML.SPAN({
      "class": "individual-price"
    }, "* ", Blaze.View(function() {
      return Spacebars.mustache(view.lookup("formatNumber"), view.lookup("soldPrice"));
    })), "\n", Blaze.If(function() {
      return Spacebars.call(view.lookup("discountVisible"));
    }, function() {
      return HTML.SUP({
        "class": "discount"
      }, "(", HTML.B("-", Blaze.View(function() {
        return Spacebars.mustache(view.lookup("discountPercent"));
      })), "%) ", HTML.BR());
    }), "\n", HTML.SPAN({
      "class": "final-price"
    }, Blaze.View(function() {
      return Spacebars.mustache(view.lookup("formatNumber"), view.lookup("finalPrice"));
    }))));
  })), "\n", HTML.DIV({
    "class": "bill-summary"
  }, HTML.Raw("<span>tổng cộng</span>"), "\n", HTML.SPAN({
    "class": "bill-final"
  }, HTML.B(Blaze.View(function() {
    return Spacebars.mustache(view.lookup("formatNumber"), Spacebars.dot(view.lookup("sale"), "finalPrice"));
  })), " VNĐ")), "\n", HTML.Raw('<div class="bill-footer">HẸN GẶP LẠI</div>')), "\n", HTML.Raw('<div class="modal-footer"><button class="lemon btn pumpkin" type="button" data-dismiss="modal">ĐÓNG</button>\n<button class="lemon btn blue print-button" type="button"><span class="icon-print-6"></span></button></div>')));
}));

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Apps.Merchant.importInit.push(function(scope) {
  return logics["import"].qualityOptions = {
    reactiveSetter: function(val) {
      return Import.update(Session.get('currentImport')._id, {
        $set: {
          currentQuality: val
        }
      });
    },
    reactiveValue: function() {
      var _ref, _ref1;
      return (_ref = (_ref1 = Session.get('currentImport')) != null ? _ref1.currentQuality : void 0) != null ? _ref : 0;
    },
    reactiveMax: function() {
      return 9999;
    },
    reactiveMin: function() {
      return 0;
    },
    reactiveStep: function() {
      return 1;
    }
  };
});

})();

(function(){
Template.__define__("homeHeader", (function() {
  var view = this;
  return HTML.DIV({
    "class": "header-content"
  }, HTML.DIV({
    "class": "home-branding"
  }, HTML.Raw('<div class="logo-image"><img src="images/gera-white.png"></div>'), "\n", HTML.DIV({
    "class": "logo-text"
  }, HTML.Raw('<div class="caption">enterprise<b>dual</b>strategy\n<sup class="trademark">TM</sup></div>'), "\n", HTML.DIV({
    "class": "slogan"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("i18n"), "slogan");
  }))), "\n", HTML.Raw('<div class="social"><a class="icon-facebook-rect"></a>\n<a class="icon-twitter-bird"></a>\n<a class="icon-googleplus-rect"></a>\n<a class="icon-linkedin-rect"></a></div>'), "\n", HTML.Raw('<div class="phone"><i class="icon-mobile"></i>\n+84 838-<b>111</b>-766</div>'), "\n", HTML.DIV({
    "class": "languages"
  }, Blaze.Each(function() {
    return Spacebars.call(view.lookup("languages"));
  }, function() {
    return HTML.SPAN(Blaze.View(function() {
      return Spacebars.mustache(view.lookup("display"));
    }));
  }))), HTML.Raw('\n<div class="home-splitter"></div>'));
}));

})();

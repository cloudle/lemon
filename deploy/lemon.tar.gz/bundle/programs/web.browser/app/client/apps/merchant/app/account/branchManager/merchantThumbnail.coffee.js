(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineWidget(Template.merchantThumbnail, {
  isntDelete: function() {
    var metroSummary, _ref, _ref1, _ref2;
    if (((_ref = Session.get('myProfile')) != null ? _ref.parentMerchant : void 0) === this._id) {
      return false;
    } else {
      metroSummary = Schema.metroSummaries.findOne({
        merchant: this._id
      });
      if (!metroSummary || (((metroSummary.productCount === (_ref2 = metroSummary.customerCount) && _ref2 === (_ref1 = metroSummary.staffCount)) && _ref1 === 0))) {
        return true;
      } else {
        return false;
      }
    }
  },
  events: {
    "click .trash": function() {
      return Meteor.call('destroyBranch', this._id, function(error, result) {
        if (error) {
          return console.log(error.error);
        } else {
          return console.log(result);
        }
      });
    }
  }
});

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Apps.Merchant.importInit.push(function(scope) {
  return logics["import"].enabledEdit = function(importId) {
    var currentImport, importDetail, importDetails, _i, _len;
    currentImport = Schema.imports.findOne({
      _id: importId,
      finish: false,
      submitted: true
    });
    if (currentImport) {
      importDetails = Schema.importDetails.find({
        "import": importId
      }).fetch();
      if (importDetails.length > 0) {
        for (_i = 0, _len = importDetails.length; _i < _len; _i++) {
          importDetail = importDetails[_i];
          Schema.importDetails.update(importDetail._id, {
            $set: {
              submitted: false
            }
          });
        }
        Schema.imports.update(importId, {
          $set: {
            submitted: false
          }
        });
        return console.log('Phieu Co The Duoc Chinh Sua');
      }
    }
  };
});

})();

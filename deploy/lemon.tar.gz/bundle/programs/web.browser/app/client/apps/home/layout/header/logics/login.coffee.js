(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
logics.homeHeader.login = function(event, template) {
  return zone.run((function(_this) {
    return function() {
      var $login, $password;
      $login = $(template.find("#authAlias"));
      $password = $(template.find("#authSecret"));
      $.cookie('lastAuthAlias', $login.val());
      return Meteor.loginWithPassword($login.val(), $password.val(), function(error) {
        var currentLoginError, currentReason, _i, _len, _ref, _results;
        currentReason = error != null ? error.reason : void 0;
        if (!error) {
          Router.go('/merchant');
          return;
        }
        _ref = logics.homeHeader.loginErrors;
        _results = [];
        for (_i = 0, _len = _ref.length; _i < _len; _i++) {
          currentLoginError = _ref[_i];
          if (currentLoginError.reason === currentReason) {
            if (currentLoginError.isPasswordError) {
              _results.push($password.notify(i18n(currentLoginError.message), {
                position: "top right"
              }));
            } else {
              _results.push($login.notify(i18n(currentLoginError.message), {
                position: "top left"
              }));
            }
          } else {
            _results.push(void 0);
          }
        }
        return _results;
      });
    };
  })(this));
};

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Apps.Merchant.returnsInit.push(function(scope) {
  return logics.returns.returnQuality = function() {
    var findReturnDetail, product, _ref, _ref1;
    product = Schema.saleDetails.findOne((_ref = Session.get('currentSale')) != null ? _ref.currentProductDetail : void 0);
    if (product) {
      findReturnDetail = _.findWhere((_ref1 = logics.returns.availableReturnDetails) != null ? _ref1.fetch() : void 0, {
        productDetail: product.productDetail,
        discountPercent: product.discountPercent
      });
      if (findReturnDetail) {
        return product.quality - (product.returnQuality + findReturnDetail.returnQuality);
      } else {
        return product.quality - product.returnQuality;
      }
    }
  };
});

Apps.Merchant.returnsInit.push(function(scope) {
  return logics.returns.returnQualityOptions = {
    reactiveSetter: function(val) {
      var _ref;
      return Schema.sales.update((_ref = Session.get('currentSale')) != null ? _ref._id : void 0, {
        $set: {
          currentQuality: val
        }
      });
    },
    reactiveValue: function() {
      var _ref, _ref1;
      return (_ref = (_ref1 = Session.get('currentSale')) != null ? _ref1.currentQuality : void 0) != null ? _ref : 0;
    },
    reactiveMax: function() {
      return logics.returns.returnQuality();
    },
    reactiveMin: function() {
      if (logics.returns.returnQuality() > 0) {
        return 1;
      } else {
        return 0;
      }
    },
    reactiveStep: function() {
      return 1;
    }
  };
});

})();

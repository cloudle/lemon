(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var formatWarehouseSelect;

formatWarehouseSelect = function(item) {
  if (item) {
    return "" + item.name;
  }
};

Apps.Merchant.staffManagerInit.push(function(scope) {
  return scope.warehouseSelectOptions = {
    query: function(query) {
      return query.callback({
        results: scope.availableWarehouses.fetch()
      });
    },
    initSelection: function(element, callback) {
      var _ref;
      return callback((_ref = Schema.warehouses.findOne(Session.get('mySession').createStaffWarehouseSelection)) != null ? _ref : 'skyReset');
    },
    changeAction: function(e) {
      return UserSession.set('createStaffWarehouseSelection', e.added._id);
    },
    reactiveValueGetter: function() {
      var _ref;
      return (_ref = Session.get('mySession').createStaffWarehouseSelection) != null ? _ref : 'skyReset';
    },
    minimumResultsForSearch: -1,
    formatSelection: formatWarehouseSelect,
    formatResult: formatWarehouseSelect
  };
});

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var step1, step2;

step1 = {
  element: "#step1 h1",
  title: "Title of my step",
  content: "Content of my step"
};

step2 = {
  element: "#step2 h1",
  title: "Title of my step",
  content: "Content of my step"
};

Apps.Merchant.testInit.push(function(scope) {
  console.log('initializing tour', scope);
  scope.tour = new Tour({
    backdrop: true
  });
  scope.tour.addStep(step1);
  return scope.tour.addStep(step2);
});

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Apps.Merchant.importInit.push(function(scope) {
  logics["import"].getExpireDate = function() {
    var expire, expireDate;
    expire = $("[name=expire]").datepicker().data().datepicker.dates[0];
    if (expire > (new Date)) {
      return expireDate = new Date(expire.getFullYear(), expire.getMonth(), expire.getDate());
    } else {
      return null;
    }
  };
  return logics["import"].getProductionDate = function() {
    var productionDate;
    productionDate = $("[name=productionDate]").datepicker().data().datepicker.dates[0];
    if (productionDate && (productionDate < (new Date))) {
      return new Date(productionDate.getFullYear(), productionDate.getMonth(), productionDate.getDate());
    } else {
      return null;
    }
  };
});

})();

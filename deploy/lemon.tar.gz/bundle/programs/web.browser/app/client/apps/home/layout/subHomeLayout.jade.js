(function(){
Template.__define__("subHomeLayout", (function() {
  var view = this;
  return HTML.DIV({
    "class": "merchant-wizard-wrapper"
  }, HTML.SECTION({
    id: "homeHeader"
  }, HTML.DIV({
    "class": "home-wrapper"
  }, Spacebars.include(view.lookupTemplate("homeHeader")))), "\n", HTML.SECTION({
    id: "wizardContent"
  }, Spacebars.include(view.lookupTemplate("yield"))));
}));

})();

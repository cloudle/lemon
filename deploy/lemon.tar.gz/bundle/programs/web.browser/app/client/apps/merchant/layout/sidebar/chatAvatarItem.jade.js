(function(){
Template.__define__("chatAvatarItem", (function() {
  var view = this;
  return HTML.LI({
    "class": function() {
      return [ "chat-avatar", " ", Spacebars.mustache(view.lookup("myAvatar")) ];
    }
  }, HTML.DIV({
    "class": function() {
      return [ "online-status-orb", " ", Spacebars.mustache(view.lookup("onlineStatus"), view.lookup("user")) ];
    }
  }), "\n", HTML.I({
    "class": function() {
      return [ "icon-chat-5", " ", "has-message-status", " ", Spacebars.mustache(view.lookup("hasUnreadMessage")) ];
    }
  }), "\n", HTML.DIV({
    "class": "alias"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("shortAlias"));
  })), "\n", Spacebars.TemplateWith(function() {
    return {
      avatar: Spacebars.call(view.lookup("avatarUrl")),
      alias: Spacebars.call(view.lookup("fullName"))
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("avatarImageComponent"));
  }));
}));

})();

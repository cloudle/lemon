(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var formatCustomerSearch;

formatCustomerSearch = function(item) {
  if (item) {
    return "" + item.name;
  }
};

Apps.Merchant.transactionManagerInit.push(function(scope) {
  return scope.customerSelectOptions = {
    query: function(query) {
      return query.callback({
        results: _.filter(Schema.customers.find({}).fetch(), function(item) {
          var unsignedName, unsignedTerm;
          unsignedTerm = Helpers.RemoveVnSigns(query.term);
          unsignedName = Helpers.RemoveVnSigns(item.name);
          return unsignedName.indexOf(unsignedTerm) > -1;
        }),
        text: 'name'
      });
    },
    initSelection: function(element, callback) {
      var _ref;
      return callback((_ref = Schema.customers.findOne(Session.get('createNewTransaction').customerId)) != null ? _ref : 'skyReset');
    },
    reactiveValueGetter: function() {
      var _ref;
      return (_ref = Session.get('createNewTransaction').customerId) != null ? _ref : 'skyReset';
    },
    changeAction: function(e) {
      var createNewTransaction;
      if (e.added) {
        createNewTransaction = Session.get('createNewTransaction');
        createNewTransaction.customerId = e.added._id;
        createNewTransaction.description = '';
        createNewTransaction.maxCash = 90000000000;
        Session.set('createNewTransaction', createNewTransaction);
        return $("[name=debtDate]").datepicker('setDate', new Date);
      } else {
        createNewTransaction = Session.get('createNewTransaction');
        createNewTransaction.customerId = 'skyReset';
        createNewTransaction.description = '';
        createNewTransaction.maxCash = 0;
        Session.set('createNewTransaction', createNewTransaction);
        return $("[name=debtDate]").datepicker('setDate', void 0);
      }
    },
    placeholder: 'CHỌN NGƯỜI MUA',
    formatSelection: formatCustomerSearch,
    formatResult: formatCustomerSearch,
    others: {
      allowClear: true
    }
  };
});

})();

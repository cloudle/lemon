(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Apps.Merchant.branchManagerInit.push(function(scope) {
  return logics.branchManager.gridOptions = {
    itemTemplate: 'merchantThumbnail',
    reactiveSourceGetter: function() {
      return Schema.merchants.find({});
    },
    wrapperClasses: 'detail-grid row'
  };
});

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineWidget(Template.returnProductThumbnail, {
  avatarUrl: function() {
    var currentProduct, _ref, _ref1;
    currentProduct = Schema.products.findOne(this.product);
    return (_ref = (_ref1 = AvatarImages.findOne(currentProduct != null ? currentProduct.image : void 0)) != null ? _ref1.url() : void 0) != null ? _ref : void 0;
  },
  events: {
    "dblclick .trash": function() {
      return logics.returns.removeReturnDetail(this._id);
    }
  }
});

})();

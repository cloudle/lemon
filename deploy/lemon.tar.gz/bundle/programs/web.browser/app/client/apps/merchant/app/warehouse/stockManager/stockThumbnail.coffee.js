(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineWidget(Template.stockThumbnail, {
  allowDelete: function() {
    return this.totalQuality === 0;
  },
  avatarUrl: function() {
    return void 0;
  },
  meterStyle: function() {
    var stockPercentage, _ref;
    stockPercentage = this.availableQuality / ((_ref = this.upperGapQuality) != null ? _ref : 100);
    return {
      percent: stockPercentage * 100,
      color: Helpers.ColorBetween(255, 0, 0, 135, 196, 57, stockPercentage, 3)
    };
  },
  events: {
    "click .full-desc.trash": function() {
      var deletingProduct;
      if (deletingProduct = Schema.products.findOne(this._id)) {
        return Schema.products.remove(deletingProduct._id);
      }
    }
  }
});

})();

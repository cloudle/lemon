(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var returnsRoute;

returnsRoute = {
  template: 'returns',
  waitOnDependency: 'returnManager',
  onBeforeAction: function() {
    if (this.ready()) {
      Apps.setup(logics.returns, Apps.Merchant.returnsInit, 'returns');
      return this.next();
    }
  },
  data: function() {
    logics.returns.reactiveRun();
    return {
      currentReturn: logics.returns.currentReturn,
      saleSelectOptions: logics.returns.saleSelectOptions,
      productSelectOptions: logics.returns.productSelectOptions,
      returnQualityOptions: logics.returns.returnQualityOptions,
      discountCashOptions: logics.returns.discountCashOptions,
      discountPercentOptions: logics.returns.discountPercentOptions,
      gridOptions: logics.returns.gridOptions
    };
  }
};

lemon.addRoute([returnsRoute], Apps.Merchant.RouterBase);

})();

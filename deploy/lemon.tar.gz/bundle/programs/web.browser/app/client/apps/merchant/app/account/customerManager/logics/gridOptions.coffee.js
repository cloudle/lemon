(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Apps.Merchant.customerManagerInit.push(function(scope) {
  return logics.customerManager.gridOptions = {
    itemTemplate: 'customerThumbnail',
    reactiveSourceGetter: function() {
      return logics.customerManager.availableCustomers;
    },
    wrapperClasses: 'detail-grid row'
  };
});

})();

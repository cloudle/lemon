(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var calculateDiscountCashAndDiscountPercent;

calculateDiscountCashAndDiscountPercent = function(quality, currentOrder) {
  var option;
  if (logics.sales.currentProduct && currentOrder) {
    option = {
      currentQuality: quality
    };
    if (quality > 0 && currentOrder.currentPrice > 0) {
      option.currentDiscountPercent = Math.round(currentOrder.currentDiscountCash / (quality * currentOrder.currentPrice) * 100);
    } else {
      option.currentDiscountCash = 0;
      option.currentDiscountPercent = 0;
    }
    option.currentTotalPrice = quality * currentOrder.currentPrice;
    return Order.update(currentOrder._id, {
      $set: option
    });
  }
};

Apps.Merchant.salesReactiveRun.push(function(scope) {
  var cross;
  if (!scope.validation.getCrossProductQuality) {
    return;
  }
  if (logics.sales.currentProduct && logics.sales.currentOrder) {
    cross = logics.sales.validation.getCrossProductQuality(logics.sales.currentProduct._id, logics.sales.currentOrder._id);
    return Session.set('saleAppMaxQuality', cross.product.availableQuality - cross.quality);
  } else {
    return Session.set('saleAppMaxQuality', 0);
  }
});

Apps.Merchant.salesInit.push(function(scope) {
  return logics.sales.qualityOptions = {
    reactiveSetter: function(val) {
      return calculateDiscountCashAndDiscountPercent(val, logics.sales.currentOrder);
    },
    reactiveValue: function() {
      var _ref, _ref1;
      return (_ref = (_ref1 = logics.sales.currentOrder) != null ? _ref1.currentQuality : void 0) != null ? _ref : 0;
    },
    reactiveMax: function() {
      var _ref;
      return (_ref = Session.get('saleAppMaxQuality')) != null ? _ref : 0;
    },
    reactiveMin: function() {
      return 0;
    },
    reactiveStep: function() {
      return 1;
    }
  };
});

})();

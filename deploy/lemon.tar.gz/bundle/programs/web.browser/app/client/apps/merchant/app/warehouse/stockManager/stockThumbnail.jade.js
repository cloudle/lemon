(function(){
Template.__define__("stockThumbnail", (function() {
  var view = this;
  return HTML.DIV({
    "class": "col"
  }, HTML.DIV({
    "class": function() {
      return [ "thumbnails", " ", [ Spacebars.mustache(view.lookup("styles")) ] ];
    }
  }, Spacebars.TemplateWith(function() {
    return {
      avatar: Spacebars.call(view.lookup("avatarUrl")),
      alias: Spacebars.call(view.lookup("name"))
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("avatarImageComponent"));
  }), "\n", HTML.DIV({
    "class": "horizontal-meter"
  }, HTML.DIV({
    "class": "meter-wrapper"
  }, HTML.DIV({
    "class": "meter-progress",
    style: function() {
      return [ "height: ", Spacebars.mustache(Spacebars.dot(view.lookup("meterStyle"), "percent")), "%; background-color: ", Spacebars.mustache(Spacebars.dot(view.lookup("meterStyle"), "color")) ];
    }
  }))), "\n", HTML.DIV({
    "class": "right-caption"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("name"));
  })), "\n", HTML.DIV({
    "class": [ "short-desc", " ", "quality", " ", "small" ]
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("availableQuality"));
  }), "/", Blaze.View(function() {
    return Spacebars.mustache(view.lookup("inStockQuality"));
  })), "\n", HTML.DIV({
    "class": [ "full-desc", " ", "price" ]
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("formatNumber"), view.lookup("price"));
  }), " ", HTML.Raw("<small>VNĐ</small>")), "\n", HTML.DIV({
    "class": "discount"
  }, Blaze.If(function() {
    return false;
  }, function() {
    return HTML.SPAN({
      "class": "s4"
    }, "-", Blaze.View(function() {
      return Spacebars.mustache(view.lookup("round"), view.lookup("discountPercent"));
    }), HTML.SPAN({
      "class": "h5"
    }, "%"));
  })), "\n", HTML.DIV({
    "class": "single-price"
  }, "TỔNG NHẬP ", Blaze.View(function() {
    return Spacebars.mustache(view.lookup("totalQuality"));
  })), "\n", Blaze.If(function() {
    return Spacebars.call(view.lookup("allowDelete"));
  }, function() {
    return HTML.DIV({
      "class": [ "full-desc", " ", "trash" ]
    }, HTML.A({
      href: "#"
    }, HTML.I({
      "class": "icon-bag"
    })));
  })));
}));

})();

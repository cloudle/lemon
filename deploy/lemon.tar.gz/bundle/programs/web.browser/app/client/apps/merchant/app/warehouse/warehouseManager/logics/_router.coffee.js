(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var warehouseManagerRoute;

warehouseManagerRoute = {
  template: 'warehouseManager',
  waitOnDependency: 'warehouseManager',
  onBeforeAction: function() {
    if (this.ready()) {
      Apps.setup(logics.warehouseManager, Apps.Merchant.warehouseManagerInit, 'warehouseManager');
      return this.next();
    }
  },
  data: function() {
    logics.warehouseManager.reactiveRun();
    return {
      allowCreate: logics.warehouseManager.allowCreate,
      gridOptions: logics.warehouseManager.gridOptions
    };
  }
};

lemon.addRoute([warehouseManagerRoute], Apps.Merchant.RouterBase);

})();

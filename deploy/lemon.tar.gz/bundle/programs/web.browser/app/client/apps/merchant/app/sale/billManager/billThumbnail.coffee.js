(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineWidget(Template.billThumbnail, {
  isntDelete: function() {
    if (this.status === true && this.received === false) {
      return true;
    } else {
      return false;
    }
  },
  buyerName: function() {
    var _ref;
    return (_ref = Schema.customers.findOne(this.buyer)) != null ? _ref.name : void 0;
  },
  sellerName: function() {
    var _ref;
    return (_ref = Schema.userProfiles.findOne(this.seller)) != null ? _ref.fullName : void 0;
  },
  avatarUrl: function() {
    var buyer, _ref;
    buyer = Schema.customers.findOne(this.buyer);
    if (!buyer) {
      return void 0;
    }
    return (_ref = AvatarImages.findOne(buyer.avatar)) != null ? _ref.url() : void 0;
  },
  events: {
    "dblclick .full-desc.trash": function() {}
  }
});

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var reactiveMinSalePrice;

reactiveMinSalePrice = function() {
  var _ref, _ref1;
  if ((_ref = Session.get('currentImport')) != null ? _ref.currentPrice : void 0) {
    return (_ref1 = Session.get('currentImport')) != null ? _ref1.currentImportPrice : void 0;
  } else {
    return Number(0);
  }
};

Apps.Merchant.importInit.push(function(scope) {
  return logics["import"].salePriceOptions = {
    reactiveSetter: function(val) {
      return Import.update(Session.get('currentImport')._id, {
        $set: {
          currentPrice: val
        }
      });
    },
    reactiveValue: function() {
      var _ref, _ref1;
      return (_ref = (_ref1 = Session.get('currentImport')) != null ? _ref1.currentPrice : void 0) != null ? _ref : 0;
    },
    reactiveMax: function() {
      return 9999999999;
    },
    reactiveMin: function() {
      return reactiveMinSalePrice();
    },
    reactiveStep: function() {
      return 1000;
    },
    others: {
      forcestepdivisibility: 'none'
    }
  };
});

})();

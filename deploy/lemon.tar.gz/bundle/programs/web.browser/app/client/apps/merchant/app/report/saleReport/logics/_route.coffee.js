(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.addRoute({
  template: 'salesReport',
  path: 'report/sales',
  waitOnDependency: 'salesReport'
}, Apps.Merchant.RouterBase);

})();

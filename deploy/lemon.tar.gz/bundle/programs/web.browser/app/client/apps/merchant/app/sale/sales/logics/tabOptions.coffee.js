(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var destroySaleAndDetail;

destroySaleAndDetail = function(scope, orderId) {
  var order, orderDetail, _i, _len, _ref;
  order = Schema.orders.findOne({
    _id: orderId,
    creator: Session.get('myProfile').user,
    merchant: Session.get('myProfile').currentMerchant,
    warehouse: Session.get('myProfile').currentWarehouse
  });
  if (order) {
    _ref = Schema.orderDetails.find({
      order: order._id
    }).fetch();
    for (_i = 0, _len = _ref.length; _i < _len; _i++) {
      orderDetail = _ref[_i];
      Schema.orderDetails.remove(orderDetail._id);
    }
    Schema.orders.remove(order._id);
    return scope.currentOrderHistory.count();
  } else {
    return -1;
  }
};

Apps.Merchant.salesInit.push(function(scope) {
  return scope.tabOptions = {
    source: scope.currentOrderHistory,
    currentSource: 'currentOrder',
    caption: 'tabDisplay',
    key: '_id',
    createAction: function() {
      return scope.createNewOrderAndSelected();
    },
    destroyAction: function(instance) {
      return destroySaleAndDetail(scope, instance._id);
    },
    navigateAction: function(instance) {
      UserSession.set('currentOrder', instance._id);
      return Session.set('currentOrder', scope.currentOrder);
    }
  };
});

})();

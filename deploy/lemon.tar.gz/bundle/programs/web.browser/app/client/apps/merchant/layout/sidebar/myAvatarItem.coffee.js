(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineWidget(Template.myAvatarItem, {
  shortAlias: function() {
    var _ref, _ref1;
    return Helpers.shortName((_ref = this.fullName) != null ? _ref : (_ref1 = Meteor.users.findOne(this.user)) != null ? _ref1.emails[0].address : void 0);
  },
  avatarUrl: function() {
    var _ref;
    if (this.avatar) {
      return (_ref = AvatarImages.findOne(this.avatar)) != null ? _ref.url() : void 0;
    } else {
      return void 0;
    }
  },
  events: {
    "click .avatar": function(event, template) {
      return template.find('.avatarFileSelector').click();
    },
    "change .avatarFileSelector": function(event, template) {
      var files;
      files = event.target.files;
      if (files.length > 0) {
        return AvatarImages.insert(files[0], function(error, fileObj) {
          var _ref;
          console.log(error, fileObj);
          Schema.userProfiles.update(Session.get('myProfile')._id, {
            $set: {
              avatar: fileObj._id
            }
          });
          return (_ref = AvatarImages.findOne(Session.get('myProfile').avatar)) != null ? _ref.remove() : void 0;
        });
      }
    }
  }
});

})();

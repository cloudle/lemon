(function(){
Template.__define__("requestDetails", (function() {
  var view = this;
  return HTML.DIV({
    "class": "dropdown-menu",
    role: "menu"
  }, HTML.Raw('<div class="header-caption">PHÊ DUYỆT</div>\n'), HTML.UL({
    "class": "details"
  }, Blaze.Each(function() {
    return Spacebars.call(view.lookup("requests"));
  }, function() {
    return HTML.LI(Spacebars.TemplateWith(function() {
      return {
        avatar: Spacebars.call(view.lookup("notificationSenderAvatar")),
        alias: Spacebars.call(view.lookup("notificationSenderAvatar"))
      };
    }, function() {
      return Spacebars.include(view.lookupTemplate("avatarImageComponent"));
    }), "\n", HTML.DIV({
      "class": "content"
    }, Blaze.View(function() {
      return Spacebars.mustache(view.lookup("message"));
    })));
  })));
}));

})();

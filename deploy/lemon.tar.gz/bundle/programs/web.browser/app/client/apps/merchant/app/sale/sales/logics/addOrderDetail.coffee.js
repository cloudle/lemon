(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var checkingAddOrderDetail, insertNewOrderDetail, optionOrderDetail, reUpdateQualityOfOrderDetail;

optionOrderDetail = function(productId, quality, price, discountCash, currentOrder) {
  var discountPercent, option, totalPrice;
  totalPrice = quality * price;
  discountPercent = discountCash / totalPrice * 100;
  option = {
    order: currentOrder._id,
    product: productId,
    quality: quality,
    price: price,
    discountCash: discountCash,
    discountPercent: discountPercent,
    totalPrice: totalPrice,
    finalPrice: totalPrice - discountCash,
    styles: Helpers.RandomColor()
  };
  return option;
};

reUpdateQualityOfOrderDetail = function(newOrderDetail, oldOrderDetail) {
  var option;
  option = {};
  option.quality = oldOrderDetail.quality + newOrderDetail.quality;
  option.totalPrice = option.quality * oldOrderDetail.price;
  option.discountCash = Math.round(option.totalPrice * oldOrderDetail.discountPercent / 100);
  option.finalPrice = option.totalPrice - option.discountCash;
  return OrderDetail.update(oldOrderDetail._id, {
    $set: option
  });
};

insertNewOrderDetail = function(orderDetail) {
  return OrderDetail.create(orderDetail);
};

checkingAddOrderDetail = function(newOrderDetail, orderDetails) {
  var findOldOrderDetail;
  findOldOrderDetail = _.findWhere(orderDetails, {
    product: newOrderDetail.product,
    price: newOrderDetail.price,
    discountPercent: newOrderDetail.discountPercent
  });
  if (findOldOrderDetail) {
    return reUpdateQualityOfOrderDetail(newOrderDetail, findOldOrderDetail);
  } else {
    return insertNewOrderDetail(newOrderDetail);
  }
};

Apps.Merchant.salesInit.push(function() {
  return logics.sales.addOrderDetail = function(productId, quality, price, discountCash) {
    if (price == null) {
      price = null;
    }
    if (discountCash == null) {
      discountCash = null;
    }
    return zone.run((function(_this) {
      return function() {
        var currentOrder, newOrderDetail, orderDetails, product;
        currentOrder = logics.sales.currentOrder;
        if (!(product = Schema.products.findOne(productId))) {
          return console.log('productId không tồn tại.');
        }
        if (price === null) {
          price = product.price;
        }
        if (discountCash === null) {
          discountCash = 0;
        }
        if (logics.sales.validation.orderDetail(productId, quality, price, discountCash, product)) {
          orderDetails = Schema.orderDetails.find({
            order: currentOrder._id
          }).fetch();
          newOrderDetail = optionOrderDetail(productId, quality, price, discountCash, currentOrder);
          checkingAddOrderDetail(newOrderDetail, orderDetails);
          return logics.sales.reCalculateOrder(currentOrder._id);
        }
      };
    })(this));
  };
});

})();

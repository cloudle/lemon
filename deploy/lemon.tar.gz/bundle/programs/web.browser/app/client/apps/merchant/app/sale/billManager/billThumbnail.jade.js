(function(){
Template.__define__("billThumbnail", (function() {
  var view = this;
  return HTML.DIV({
    "class": "col"
  }, HTML.DIV({
    "class": function() {
      return [ "thumbnails", " ", "click-enabled", " ", Spacebars.mustache(view.lookup("styles")) ];
    }
  }, Spacebars.TemplateWith(function() {
    return {
      avatar: Spacebars.call(view.lookup("avatarUrl")),
      alias: Spacebars.call(view.lookup("buyerName"))
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("avatarImageComponent"));
  }), "\n", HTML.DIV({
    "class": "right-caption"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("buyerName"));
  }), " ", HTML.Raw("<br>"), " ", Blaze.View(function() {
    return Spacebars.mustache(view.lookup("sellerName"));
  })), "\n", HTML.DIV({
    "class": [ "full-desc", " ", "price" ]
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("formatNumber"), view.lookup("finalPrice"));
  }), " VNĐ"), "\n", Blaze.If(function() {
    return Spacebars.call(view.lookup("isntDelete"));
  }, function() {
    return HTML.DIV({
      "class": [ "full-desc", " ", "trash" ]
    }, HTML.A({
      href: "#"
    }, HTML.I({
      "class": "icon-bag"
    })));
  })));
}));

})();

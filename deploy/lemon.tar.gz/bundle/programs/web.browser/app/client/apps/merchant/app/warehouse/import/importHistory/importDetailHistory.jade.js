(function(){
Template.__define__("importHistoryDetail", (function() {
  var view = this;
  return HTML.ASIDE({
    "class": [ "modal", " ", "swipe", " ", "left" ],
    id: "importHistoryDetail"
  }, HTML.DIV({
    "class": [ "modal-dialog", " ", "sale-bill-preview" ]
  }, HTML.Raw('<div class="modal-header"><button class="close" type="button" data-dismiss="modal"><span aria-hidden="true">&times;</span>\n<span class="sr-only">Close</span></button>\n<h4 class="modal-title"><i class="icon-search-8"></i>\n<span>CHI TIẾT KIỂM KHO</span></h4></div>'), "\n", HTML.DIV({
    "class": [ "modal-body", " ", "printable-area" ]
  }, HTML.Raw('<div class="header"></div>'), "\n", HTML.DIV({
    "class": "merchant-info"
  }, HTML.SPAN({
    "class": "marchant-address"
  }, [ "Người tạo: ", Blaze.View(function() {
    return Spacebars.mustache(view.lookup("userNameFromId"), Spacebars.dot(view.lookup("import"), "creator"));
  }), " ", HTML.Raw("<br>") ], "\n", [ "Miêu tả: ", Blaze.View(function() {
    return Spacebars.mustache(Spacebars.dot(view.lookup("import"), "description"));
  }), " ", HTML.Raw("<br>") ], "\n", [ "Trạng thái: ", Blaze.View(function() {
    return Spacebars.mustache(view.lookup("status"));
  }) ])), "\n", HTML.UL(Blaze.Each(function() {
    return Spacebars.call(view.lookup("importDetails"));
  }, function() {
    return HTML.LI({
      "class": "order-detail"
    }, HTML.DIV({
      "class": "product-name"
    }, HTML.B(Blaze.View(function() {
      return Spacebars.mustache(view.lookup("productNameFromId"), view.lookup("product"));
    })), " ", Blaze.View(function() {
      return Spacebars.mustache(view.lookup("skullsNameFromId"), view.lookup("product"));
    })), "\n", HTML.DIV({
      "class": "product-price"
    }, HTML.SPAN({
      "class": "individual-price"
    }, "* ", Blaze.View(function() {
      return Spacebars.mustache(view.lookup("formatNumber"), view.lookup("importQuality"));
    }), " x ", Blaze.View(function() {
      return Spacebars.mustache(view.lookup("formatNumber"), view.lookup("importPrice"));
    })), "\n", HTML.SPAN({
      "class": "final-price"
    }, Blaze.View(function() {
      return Spacebars.mustache(view.lookup("formatNumber"), view.lookup("totalPrice"));
    }))));
  })), "\n", HTML.DIV({
    "class": "bill-summary"
  }, HTML.Raw("<span>tổng cộng</span>"), "\n", HTML.SPAN({
    "class": "bill-final"
  }, HTML.B(Blaze.View(function() {
    return Spacebars.mustache(view.lookup("formatNumber"), Spacebars.dot(view.lookup("import"), "totalPrice"));
  })), " VNĐ")), "\n", HTML.Raw("<!--.bill-footer-->")), "\n", HTML.DIV({
    "class": "modal-footer"
  }, Blaze.If(function() {
    return Spacebars.call(view.lookup("showFinish"));
  }, function() {
    return HTML.BUTTON({
      "class": [ "btn", " ", "btn-primary", " ", "finish" ]
    }, "XÁC NHẬN");
  }))));
}));

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineWidget(Template.importHistoryThumbnail, {
  createDate: function(date) {
    return moment(date).format("DD/MM/YYYY");
  },
  events: {
    'click .full-desc.trash': function() {
      return UserSession.get('currentInventoryHistory', this._id);
    }
  }
});

})();

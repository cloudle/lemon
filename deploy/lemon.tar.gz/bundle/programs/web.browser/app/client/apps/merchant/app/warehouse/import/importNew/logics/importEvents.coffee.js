(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Apps.Merchant.importInit.push(function(scope) {
  logics["import"].updateDescription = function(description, currentImport) {
    if (currentImport.finish === false && currentImport.submitted === false) {
      if (description.length > 1) {
        return Schema.imports.update(currentImport._id, {
          $set: {
            description: description
          }
        });
      } else {
        return description = currentImport.description;
      }
    }
  };
  return logics["import"].updateDeposit = function(deposit, currentImport) {
    var option;
    if (currentImport.finish === false && currentImport.submitted === false) {
      if (deposit > 0) {
        if (deposit > currentImport.totalPrice) {
          option = {
            deposit: currentImport.totalPrice,
            debit: 0
          };
        } else {
          option = {
            deposit: deposit,
            debit: currentImport.totalPrice - deposit
          };
        }
      } else {
        option = {
          deposit: 0,
          debit: currentImport.totalPrice
        };
      }
      return Import.update(currentImport._id, {
        $set: option
      });
    }
  };
});

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineApp(Template.deliveryManager, {
  activeDeliveryFilter: function(status) {
    if (Session.get('deliveryFilter') === status) {
      return 'active';
    }
  },
  events: {
    "click [data-filter]": function(event, template) {
      var $element;
      $element = $(event.currentTarget);
      return Session.set('deliveryFilter', $element.attr("data-filter"));
    }
  }
});

})();

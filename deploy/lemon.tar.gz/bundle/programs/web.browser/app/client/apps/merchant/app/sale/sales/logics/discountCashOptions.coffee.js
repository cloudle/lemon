(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var calculateCurrentDiscountPercent;

calculateCurrentDiscountPercent = function(discountCash, currentOrder) {
  var option, total;
  option = {
    currentDiscountCash: discountCash
  };
  total = currentOrder.currentQuality * currentOrder.currentPrice;
  if (discountCash > 0) {
    option.currentDiscountPercent = Math.round(discountCash / total * 100);
  } else {
    option.currentDiscountPercent = 0;
  }
  return Order.update(currentOrder._id, {
    $set: option
  });
};

Apps.Merchant.salesInit.push(function() {
  return logics.sales.discountCashOptions = {
    reactiveSetter: function(val) {
      return calculateCurrentDiscountPercent(val, Session.get('currentOrder'));
    },
    reactiveValue: function() {
      var _ref, _ref1;
      return (_ref = (_ref1 = Session.get('currentOrder')) != null ? _ref1.currentDiscountCash : void 0) != null ? _ref : 0;
    },
    reactiveMax: function() {
      var _ref, _ref1;
      return (_ref = (_ref1 = Session.get('currentOrder')) != null ? _ref1.currentTotalPrice : void 0) != null ? _ref : 0;
    },
    reactiveMin: function() {
      return 0;
    },
    reactiveStep: function() {
      return 1000;
    },
    others: {
      forcestepdivisibility: 'none'
    }
  };
});

})();

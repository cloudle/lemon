(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var scope;

scope = logics.merchantTest;

lemon.defineApp(Template.merchantTest, {
  rendered: function() {
    console.log(scope.tour);
    scope.tour.init();
    return scope.tour.restart();
  }
});

})();

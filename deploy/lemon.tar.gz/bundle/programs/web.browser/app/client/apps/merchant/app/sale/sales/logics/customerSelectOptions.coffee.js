(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var changedActionSelectCustomer, formatCustomerSearch, updateCustomerAllowDelete;

formatCustomerSearch = function(item) {
  if (item) {
    return "" + item.name;
  }
};

updateCustomerAllowDelete = function(customer) {
  if (customer.allowDelete) {
    return Schema.customers.update(customer._id, {
      $set: {
        allowDelete: false
      }
    });
  }
};

changedActionSelectCustomer = function(customerId, currentOrder) {
  var customer, date, option, _ref, _ref1, _ref2;
  if (customer = Schema.customers.findOne(customerId)) {
    option = {
      contactName: null,
      contactPhone: null,
      deliveryAddress: null,
      deliveryDate: null,
      comment: null
    };
    if (currentOrder.paymentsDelivery === 1) {
      date = new Date;
      option.contactName = (_ref = customer.name) != null ? _ref : null;
      option.contactPhone = (_ref1 = customer.phone) != null ? _ref1 : null;
      option.deliveryAddress = (_ref2 = customer.address) != null ? _ref2 : null;
      option.deliveryDate = new Date(date.getFullYear(), date.getMonth(), date.getDate());
      option.comment = 'giao trong ngay';
    }
    updateCustomerAllowDelete(customer);
    option.buyer = customer._id;
    option.tabDisplay = Helpers.respectName(customer.name, customer.gender);
  } else {
    console.log('Sai customer');
    return;
  }
  return Order.update(currentOrder._id, {
    $set: option
  });
};

Apps.Merchant.salesInit.push(function() {
  return logics.sales.customerSelectOptions = {
    query: function(query) {
      return query.callback({
        results: _.filter(logics.sales.currentAllCustomers.fetch(), function(item) {
          var unsignedName, unsignedTerm;
          unsignedTerm = Helpers.RemoveVnSigns(query.term);
          unsignedName = Helpers.RemoveVnSigns(item.name);
          return unsignedName.indexOf(unsignedTerm) > -1;
        }),
        text: 'name'
      });
    },
    initSelection: function(element, callback) {
      return callback(Schema.customers.findOne(Session.get('currentOrder').buyer));
    },
    formatSelection: formatCustomerSearch,
    formatResult: formatCustomerSearch,
    id: '_id',
    placeholder: 'CHỌN NGƯỜI MUA',
    changeAction: function(e) {
      return changedActionSelectCustomer(e.added._id, logics.sales.currentOrder);
    },
    reactiveValueGetter: function() {
      var _ref;
      return (_ref = Session.get('currentOrder')) != null ? _ref.buyer : void 0;
    }
  };
});

})();

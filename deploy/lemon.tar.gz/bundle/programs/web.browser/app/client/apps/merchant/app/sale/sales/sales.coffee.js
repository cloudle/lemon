(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var calculatePercentDiscount, calculateTotalPrice;

calculateTotalPrice = function() {
  var _ref, _ref1;
  return ((_ref = logics.sales.currentOrder) != null ? _ref.currentPrice : void 0) * ((_ref1 = logics.sales.currentOrder) != null ? _ref1.currentQuality : void 0);
};

calculatePercentDiscount = function() {
  var _ref, _ref1, _ref2;
  return Math.round(((_ref = logics.sales.currentOrder) != null ? _ref.currentDiscount : void 0) * 100 / (((_ref1 = logics.sales.currentOrder) != null ? _ref1.currentPrice : void 0) * ((_ref2 = logics.sales.currentOrder) != null ? _ref2.currentQuality : void 0)));
};

lemon.defineApp(Template.sales, {
  allowAllOrderDetail: function() {
    if (!logics.sales.currentProduct) {
      return 'disabled';
    }
  },
  allowSuccessOrder: function() {
    if (Session.get('allowSuccess')) {
      return '';
    } else {
      return 'disabled';
    }
  },
  created: function() {
    Session.setDefault('allowAllOrderDetail', false);
    return Session.setDefault('allowSuccessOrder', false);
  },
  rendered: function() {
    var _ref;
    logics.sales.templateInstance = this;
    lemon.ExcuteLogics();
    return $("[name=deliveryDate]").datepicker('setDate', (_ref = logics.sales.deliveryDetail) != null ? _ref.deliveryDate : void 0);
  },
  events: {
    "change [name='advancedMode']": function(event, template) {
      return logics.sales.templateInstance.ui.extras.toggleExtra('advanced', event.target.checked);
    },
    "change [name ='deliveryDate']": function(event, template) {
      return logics.sales.updateDeliveryDate();
    },
    'blur .contactName': function(event, template) {
      return logics.sales.updateDeliveryContactName(template.find(".contactName"));
    },
    'blur .contactPhone': function(event, template) {
      return logics.sales.updateDeliveryContactPhone(template.find(".contactPhone"));
    },
    'blur .deliveryAddress': function(event, template) {
      return logics.sales.updateDeliveryAddress(template.find(".deliveryAddress"));
    },
    'blur .comment': function(event, template) {
      return logics.sales.updateDeliveryComment(template.find(".comment"));
    },
    'click .addOrderDetail': function() {
      return logics.sales.addOrderDetail(logics.sales.currentOrder.currentProduct, logics.sales.currentOrder.currentQuality, logics.sales.currentOrder.currentPrice, logics.sales.currentOrder.currentDiscountCash);
    },
    "click .print-preview": function(event, template) {
      return $(template.find('#salePrinter')).modal();
    },
    'click .finish': function(event, template) {
      return Meteor.call("finishOrder", logics.sales.currentOrder._id, function(error, result) {
        if (error) {
          return console.log(error.error);
        }
      });
    }
  }
});

})();

(function(){
Template.__define__("transactionManager", (function() {
  var view = this;
  return [ Spacebars.TemplateWith(function() {
    return {
      transaction: Spacebars.call(view.lookup("currentTransaction")),
      transactionDetail: Spacebars.call(view.lookup("currentTransactionDetail"))
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("transactionManagerDetail"));
  }), HTML.DIV({
    id: "header"
  }, HTML.Raw('<div class="caption-row"><div class="title">QUẢN LÝ CÔNG NỢ</div></div>'), "\n", HTML.DIV({
    "class": "editor-row"
  }, Blaze.If(function() {
    return Spacebars.call(view.lookup("unSecureMode"));
  }, function() {
    return [ HTML.DIV({
      "class": "editor-wrapper",
      style: "width: 170px"
    }, HTML.SPAN({
      "class": "ilabel"
    }, "chọn khách hàng"), "\n", Spacebars.TemplateWith(function() {
      return {
        options: Spacebars.call(view.lookup("customerSelectOptions")),
        "class": Spacebars.call("field")
      };
    }, function() {
      return Spacebars.include(view.lookupTemplate("iSelect"));
    })), "\n", HTML.DIV({
      "class": "editor-wrapper",
      style: "width:170px"
    }, HTML.SPAN({
      "class": "ilabel"
    }, "tổng số tiền"), "\n", Spacebars.TemplateWith(function() {
      return {
        options: Spacebars.call(view.lookup("totalCashOptions")),
        "class": Spacebars.call("field")
      };
    }, function() {
      return Spacebars.include(view.lookupTemplate("iSpinEdit"));
    })), "\n", HTML.DIV({
      "class": "editor-wrapper",
      style: "width:170px"
    }, HTML.SPAN({
      "class": "ilabel"
    }, "số tiền đã trả"), "\n", Spacebars.TemplateWith(function() {
      return {
        options: Spacebars.call(view.lookup("depositCashOptions")),
        "class": Spacebars.call("field")
      };
    }, function() {
      return Spacebars.include(view.lookupTemplate("iSpinEdit"));
    })), "\n", HTML.DIV({
      "class": "editor-wrapper",
      style: "width: 90px"
    }, HTML.SPAN({
      "class": "ilabel"
    }, "ngày tạo"), "\n", HTML.INPUT({
      name: "debtDate",
      binding: "datePicker",
      todayHighlight: "true",
      maxlength: "20"
    })), "\n", HTML.DIV({
      "class": "editor-wrapper",
      style: "width: 250px"
    }, HTML.SPAN({
      "class": "ilabel"
    }, "lý do"), "\n", HTML.INPUT({
      "class": "description",
      maxlength: "200",
      value: function() {
        return Spacebars.mustache(Spacebars.dot(view.lookup("newTransaction"), "description"));
      }
    })), "\n", HTML.DIV({
      "class": "editor-wrapper"
    }, HTML.BUTTON({
      "class": function() {
        return [ "lemon", " ", "btn", " ", "lime", " ", "icon-plus-circled", " ", "createTransaction", " ", Spacebars.mustache(view.lookup("allowCreate")) ];
      }
    }, "THÊM")) ];
  }))), HTML.DIV({
    id: "content"
  }, Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("gridOptions"))
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("iGrid"));
  })), HTML.DIV({
    id: "footer",
    "class": "gray"
  }, HTML.UL({
    "class": "step-filter"
  }, HTML.LI({
    "class": function() {
      return Spacebars.mustache(view.lookup("activeReceivable"), "0");
    },
    "data-receivable": "0",
    "data-toggle": "tooltip",
    title: "PHẢI THU"
  }, HTML.Raw('<span class="icon-money"></span>')), "\n", HTML.LI({
    "class": function() {
      return Spacebars.mustache(view.lookup("activeReceivable"), "1");
    },
    "data-receivable": "1",
    "data-toggle": "tooltip",
    title: "PHẢI TRẢ"
  }, HTML.Raw('<span class="icon-emo-cry"></span>')), "\n", HTML.Raw('<li class="split"></li>'), "\n", HTML.LI({
    "class": function() {
      return Spacebars.mustache(view.lookup("activeTransactionFilter"), "1");
    },
    "data-filter": "1",
    "data-toggle": "tooltip",
    title: "NỢ"
  }, HTML.Raw('<span class="icon-feather-1"></span>')), "\n", HTML.LI({
    "class": function() {
      return Spacebars.mustache(view.lookup("activeTransactionFilter"), "2");
    },
    "data-filter": "2",
    "data-toggle": "tooltip",
    title: "QUÁ HẠN"
  }, HTML.Raw('<span class="icon-cancel-7"></span>')), "\n", HTML.LI({
    "class": function() {
      return Spacebars.mustache(view.lookup("activeTransactionFilter"), "3");
    },
    "data-filter": "3",
    "data-toggle": "tooltip",
    title: "ĐÃ KẾT THÚC"
  }, HTML.Raw('<span class="icon-ok-6"></span>')))) ];
}));

})();

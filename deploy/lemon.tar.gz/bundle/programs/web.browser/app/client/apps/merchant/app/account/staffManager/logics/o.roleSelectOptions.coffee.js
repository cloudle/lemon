(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var formatRoleSelect;

formatRoleSelect = function(item) {
  if (item) {
    return "" + item.name;
  }
};

Apps.Merchant.staffManagerInit.push(function(scope) {
  Session.set('currentRoleSelection', []);
  return logics.staffManager.roleSelectOptions = {
    query: function(query) {
      return query.callback({
        results: Schema.roles.find().fetch()
      });
    },
    initSelection: function(element, callback) {
      return callback(Session.get('currentRoleSelection'));
    },
    changeAction: function(e) {
      var currentRoles, removedItem;
      currentRoles = Session.get('currentRoleSelection');
      currentRoles = currentRoles != null ? currentRoles : [];
      if (e.added) {
        currentRoles.push(e.added);
      }
      if (e.removed) {
        removedItem = _.findWhere(currentRoles, {
          _id: e.removed._id
        });
        currentRoles.splice(currentRoles.indexOf(removedItem), 1);
      }
      return Session.set('currentRoleSelection', currentRoles);
    },
    reactiveValueGetter: function() {
      return Session.get('currentRoleSelection');
    },
    formatSelection: formatRoleSelect,
    formatResult: formatRoleSelect,
    others: {
      multiple: true,
      maximumSelectionSize: 3
    }
  };
});

})();

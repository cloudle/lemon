(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineWidget(Template.transactionThumbnail, {
  colorClass: function() {
    if (this.status === 'closed') {
      return 'lime';
    } else {
      return 'pumpkin';
    }
  },
  avatarUrl: function() {
    var owner, _ref;
    owner = Schema.customers.findOne(this.owner);
    if (!owner) {
      return void 0;
    }
    return (_ref = AvatarImages.findOne(owner.avatar)) != null ? _ref.url() : void 0;
  },
  ownerName: function() {
    var _ref;
    return (_ref = Schema.customers.findOne(this.owner)) != null ? _ref.name : void 0;
  },
  formatNumber: function(number) {
    return accounting.formatMoney(number, {
      format: "%v",
      precision: 0
    });
  },
  daysFromNow: function() {
    if (this.dueDay) {
      return (new Date) - this.dueDay;
    }
  },
  meterStyle: function() {
    var percentage;
    percentage = this.debitCash / this.totalCash;
    return {
      percent: percentage * 100,
      color: Helpers.ColorBetween(135, 196, 57, 255, 0, 0, percentage, 0.9)
    };
  }
});

})();

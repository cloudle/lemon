(function(){
Template.__define__("salesReport", (function() {
  var view = this;
  return [ HTML.Raw('<div id="header"><div class="caption-row"><div class="title">BÁO CÁO TỔNG QUAN</div></div></div>'), HTML.DIV({
    id: "content"
  }, HTML.DIV({
    id: "month-chart"
  }, HTML.SVG()), "\n", HTML.DIV({
    id: "year-chart"
  }, HTML.SVG())), HTML.Raw('<div id="footer" class="gray"><ul class="step-filter"><li><span class="icon-emo-shoot"></span></li>\n<li><span class="icon-cog"></span></li>\n<li><span class="icon-cw-5"></span></li>\n<li><span class="icon-location-7"></span></li></ul></div>') ];
}));

})();

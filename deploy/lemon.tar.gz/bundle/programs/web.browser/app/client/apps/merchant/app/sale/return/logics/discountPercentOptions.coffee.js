(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Apps.Merchant.returnsInit.push(function(scope) {
  return logics.returns.discountPercentOptions = {
    reactiveSetter: function(val) {
      var option;
      option = {
        discountPercent: val
      };
      if (val > 0) {
        option.discountCash = Math.round(logics.returns.currentReturn.totalPrice / 100 * val);
      } else {
        option.discountCash = 0;
      }
      option.finallyPrice = logics.returns.currentReturn.totalPrice - option.discountCash;
      if (logics.returns.currentReturn) {
        return Schema.returns.update(logics.returns.currentReturn._id, {
          $set: option
        });
      }
    },
    reactiveValue: function() {
      var returns;
      if (returns = logics.returns.currentReturn) {
        return Math.round(returns.discountPercent);
      } else {
        return 0;
      }
    },
    reactiveMax: function() {
      if (logics.returns.currentReturn) {
        return 100;
      } else {
        return 0;
      }
    },
    reactiveMin: function() {
      return 0;
    },
    reactiveStep: function() {
      return 1;
    }
  };
});

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var formatWarehouseSearch;

formatWarehouseSearch = function(item) {
  if (item) {
    return "" + item.name;
  }
};

logics.sales.warehouseSelectOptions = {
  query: function(query) {
    return query.callback({
      results: _.filter(Session.get('availableWarehouses'), function(item) {
        var unsignedName, unsignedTerm;
        unsignedTerm = Helpers.RemoveVnSigns(query.term);
        unsignedName = Helpers.RemoveVnSigns(item.name);
        return unsignedName.indexOf(unsignedTerm) > -1;
      })
    });
  },
  initSelection: function(element, callback) {
    var _ref;
    return callback((_ref = Session.get('currentWarehouse')) != null ? _ref : 'skyReset');
  },
  formatSelection: formatWarehouseSearch,
  formatResult: formatWarehouseSearch,
  placeholder: 'CHỌN CHI NHÁNH',
  minimumResultsForSearch: -1,
  changeAction: function(e) {
    return Schema.userProfiles.update(Session.get('currentProfile')._id, {
      $set: {
        currentWarehouse: e.added._id
      }
    });
  },
  reactiveValueGetter: function() {
    var _ref;
    return (_ref = Session.get('currentWarehouse')) != null ? _ref : 'skyReset';
  }
};

})();

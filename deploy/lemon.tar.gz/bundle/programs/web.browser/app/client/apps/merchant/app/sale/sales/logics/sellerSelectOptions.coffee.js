(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var formatSellerSearch;

formatSellerSearch = function(item) {
  if (item) {
    return "" + item.emails[0].address;
  }
};

Apps.Merchant.salesInit.push(function() {
  return logics.sales.sellerSelectOptions = {
    query: function(query) {
      var _ref;
      return query.callback({
        results: _.filter((_ref = logics.sales.currentBranchStaff) != null ? _ref.fetch() : void 0, function(item) {
          var email, result, _i, _len, _ref1;
          result = false;
          _ref1 = item.emails;
          for (_i = 0, _len = _ref1.length; _i < _len; _i++) {
            email = _ref1[_i];
            if (email.address.indexOf(query.term) > -1) {
              result = true;
              break;
            }
          }
          return result;
        }),
        text: 'email'
      });
    },
    initSelection: function(element, callback) {
      var currentSeller, _ref, _ref1;
      currentSeller = (_ref = (_ref1 = logics.sales.currentOrder) != null ? _ref1.seller : void 0) != null ? _ref : Meteor.userId();
      return callback(Meteor.users.findOne(currentSeller));
    },
    formatSelection: formatSellerSearch,
    formatResult: formatSellerSearch,
    id: '_id',
    placeholder: 'CHỌN NGƯỜI BÁN',
    changeAction: function(e) {
      return Order.update(logics.sales.currentOrder._id, {
        $set: {
          seller: e.added._id
        }
      });
    },
    reactiveValueGetter: function() {
      var _ref;
      return (_ref = logics.sales.currentOrder) != null ? _ref.seller : void 0;
    }
  };
});

})();

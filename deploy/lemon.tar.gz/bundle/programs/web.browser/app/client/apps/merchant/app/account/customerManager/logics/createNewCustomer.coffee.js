(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var resetForm;

resetForm = function(context) {
  var item, _i, _len, _ref, _results;
  _ref = context.findAll("[name]");
  _results = [];
  for (_i = 0, _len = _ref.length; _i < _len; _i++) {
    item = _ref[_i];
    _results.push($(item).val(''));
  }
  return _results;
};

logics.customerManager.createNewCustomer = function(context) {
  var address, dateOfBirth, fullName, option, phone;
  fullName = context.ui.$fullName.val();
  phone = context.ui.$phone.val();
  address = context.ui.$address.val();
  dateOfBirth = $("[name=dateOfBirth]").datepicker().data().datepicker.dates[0];
  console.log(dateOfBirth);
  option = {
    creator: Meteor.userId(),
    name: fullName,
    phone: phone,
    address: address,
    dateOfBirth: dateOfBirth,
    styles: Helpers.RandomColor(),
    currentMerchant: Session.get('myProfile').currentMerchant,
    parentMerchant: Session.get('myProfile').parentMerchant,
    gender: Session.get('genderNewCustomer')
  };
  if (Schema.customers.findOne({
    name: fullName,
    phone: phone,
    currentMerchant: Session.get('myProfile').currentMerchant
  })) {
    return console.log('Trùng tên khách hàng');
  } else {
    Schema.customers.insert(option, function(error, result) {
      if (error) {
        return console.log(error);
      } else {
        return MetroSummary.updateMetroSummaryBy(['customer']);
      }
    });
    resetForm(context);
    return Session.set('allowCreateNewCustomer', false);
  }
};

})();

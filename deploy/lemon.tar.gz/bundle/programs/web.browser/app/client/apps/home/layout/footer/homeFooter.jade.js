(function(){
Template.__define__("homeFooter", (function() {
  var view = this;
  return [ HTML.DIV({
    "class": "home-wrapper"
  }, HTML.DIV({
    "class": [ "footer-content", " ", "row" ]
  }, HTML.DIV({
    "class": "col-md-4"
  }, HTML.H3({
    "class": "icon-location-1"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("i18n"), "home.contact");
  })), "\n", HTML.DIV({
    "class": "details"
  }, HTML.SPAN({
    "class": "icon-flag-circled"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("i18n"), "home.address");
  }), " ", HTML.Raw("<br>")), "\n", HTML.Raw('<span class="icon-mail-circled">thienban@gmail.com <br></span>'), "\n", HTML.Raw('<span class="icon-phone-circled">+84 838-<b>111</b>-766 <br></span>'), "\n", HTML.Raw('<span class="icon-skype">thienban.eds</span>'))), "\n", HTML.DIV({
    "class": [ "col-md-5", " ", "comment-section" ]
  }, HTML.H3({
    "class": "icon-chat-5"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("i18n"), "comment");
  })), "\n", HTML.DIV({
    "class": "details"
  }, Spacebars.include(view.lookupTemplate("merchantTestimonials")))), "\n", HTML.DIV({
    "class": "col-md-3"
  }, HTML.H3({
    "class": "icon-award"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("i18n"), "home.award");
  })), "\n", HTML.DIV({
    "class": "details"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("i18n"), "commingSoon");
  }))))), HTML.DIV({
    "class": "home-wrapper"
  }, HTML.DIV({
    "class": "sub-footer"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("i18n"), "home.copyWriting");
  }))) ];
}));

})();

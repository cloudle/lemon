(function(){
Template.__define__("import", (function() {
  var view = this;
  return [ Spacebars.TemplateWith(function() {
    return {
      myCreateProduct: Spacebars.call(view.lookup("myCreateProduct")),
      order: Spacebars.call(view.lookup("currentOrder"))
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("addProduct"));
  }), Spacebars.TemplateWith(function() {
    return {
      myCreateProvider: Spacebars.call(view.lookup("myCreateProvider")),
      order: Spacebars.call(view.lookup("currentOrder"))
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("addProvider"));
  }), HTML.DIV({
    id: "header"
  }, HTML.Raw('<div class="caption-row"><div class="title">Nhập Kho\n<button class="lemon btn amethyst icon-history importHistory" type="submit">LỊCH SỬ</button></div>\n<div class="commands"><button class="lemon btn lime icon-building add-provider" type="submit">Thêm NPP</button>\n<button class="lemon btn lime icon-tags-2 add-product" type="submit">Thêm Sản Phẩm</button>\n<input binding="switch" type="checkbox" name="advancedMode"></div></div>'), "\n", HTML.DIV({
    "class": "editor-row"
  }, HTML.DIV({
    "class": "editor-wrapper",
    style: "width:250px"
  }, HTML.Raw('<span class="ilabel">sản phẩm</span>'), "\n", Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("productSelectOptions")),
      "class": Spacebars.call("field")
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("iSelect"));
  })), "\n", HTML.DIV({
    "class": "editor-wrapper",
    style: "width:180px"
  }, HTML.Raw('<span class="ilabel optional">nhà phân phối</span>'), "\n", Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("providerSelectOptions")),
      "class": Spacebars.call("field")
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("iSelect"));
  })), "\n", HTML.DIV({
    "class": "editor-wrapper",
    style: "width:120px"
  }, HTML.Raw('<span class="ilabel center">số lượng</span>'), "\n", Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("qualityOptions")),
      "class": Spacebars.call("field")
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("iSpinEdit"));
  })), "\n", HTML.DIV({
    "class": "editor-wrapper",
    style: "width:150px"
  }, HTML.Raw('<span class="ilabel center">giá nhập</span>'), "\n", Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("importPriceOptions")),
      "class": Spacebars.call("field")
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("iSpinEdit"));
  })), "\n", Blaze.If(function() {
    return Spacebars.call(view.lookup("hidePriceSale"));
  }, function() {
    return HTML.DIV({
      "class": "editor-wrapper",
      style: "width:150px"
    }, HTML.SPAN({
      "class": [ "ilabel", " ", "center" ]
    }, "giá bán"), "\n", Spacebars.TemplateWith(function() {
      return {
        options: Spacebars.call(view.lookup("salePriceOptions")),
        "class": Spacebars.call("field")
      };
    }, function() {
      return Spacebars.include(view.lookupTemplate("iSpinEdit"));
    }));
  }), "\n", Blaze.If(function() {
    return Spacebars.call(view.lookup("showCreateDetail"));
  }, function() {
    return HTML.DIV({
      "class": "editor-wrapper",
      style: "width:100px"
    }, HTML.BUTTON({
      "class": [ "lemon", " ", "btn", " ", "lime", " ", "icon-plus-circled", " ", "addImportDetail" ],
      type: "submit",
      style: function() {
        return Spacebars.mustache(view.lookup("showCreateDetail"));
      }
    }, "THÊM"));
  }), "\n", HTML.Raw('<div class="editor-wrapper pull-right"><input class="hidden excelFileSource" type="file">\n<button class="lemon btn blue pull-right excel-import" type="submit" data-toggle="tooltip" data-container="body" data-placement="left" title="Nhập tự động"><span class="icon-inbox-1"></span></button></div>')), "\n", HTML.DIV({
    "class": [ "editor-row", " ", "extra" ],
    name: "advanced",
    style: "display: none;"
  }, HTML.Raw('<div class="editor-wrapper" style="width: 120px"><span class="ilabel optional">ngày sản xuất</span>\n<input name="productionDate" binding="datePicker" todayHighlight="true"></div>'), "\n", HTML.DIV({
    "class": "editor-wrapper",
    style: "width: 120px"
  }, HTML.Raw('<span class="ilabel optional">hạn sử dụng</span>'), "\n", Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("timeUseSelectOptions")),
      "class": Spacebars.call("field")
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("iSelect"));
  })), "\n", HTML.Raw('<!--.editor-wrapper(style="width: 120px")-->'), "\n", HTML.Raw("<!--  span.ilabel.optional ngày hết hạn-->"), "\n", HTML.Raw('<!--  input(binding="datePicker" todayHighlight="true" name="expire")-->'), "\n", "")), HTML.DIV({
    id: "content"
  }, Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("importDetailOptions"))
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("iGrid"));
  })), HTML.DIV({
    id: "footer"
  }, Blaze.If(function() {
    return Spacebars.call(view.lookup("currentImport"));
  }, function() {
    return HTML.DIV({
      "class": "editor-row"
    }, Blaze.If(function() {
      return Spacebars.call(view.lookup("showSubmit"));
    }, function() {
      return HTML.DIV({
        "class": [ "editor-wrapper", " ", "right" ],
        style: "width: 100px"
      }, HTML.BUTTON({
        "class": [ "lemon", " ", "btn", " ", "lime", " ", "icon-ok-6", " ", "right", " ", "submitImport" ],
        type: "submit",
        style: "margin-right: 5px;"
      }, "XÁC NHẬN"));
    }), "\n", Blaze.If(function() {
      return Spacebars.call(view.lookup("showEdit"));
    }, function() {
      return HTML.DIV({
        "class": [ "editor-wrapper", " ", "right" ],
        style: "width: 120px"
      }, HTML.BUTTON({
        "class": [ "lemon", " ", "btn", " ", "carrot", " ", "icon-pencil-circled", " ", "editImport" ],
        type: "submit",
        style: "margin-right: 5px;"
      }, "CHỈNH SỬA"));
    }), "\n", Blaze.If(function() {
      return Spacebars.call(view.lookup("showFinish"));
    }, function() {
      return HTML.DIV({
        "class": [ "editor-wrapper", " ", "right" ],
        style: "width: 100px"
      }, HTML.BUTTON({
        "class": [ "lemon", " ", "btn", " ", "lime", " ", "icon-award", " ", "right", " ", "finishImport" ],
        type: "submit",
        style: "margin-right: 5px;"
      }, "HOÀN TẤT"));
    }), "\n", HTML.DIV({
      "class": [ "editor-wrapper", " ", "right" ],
      style: "width: 120px"
    }, HTML.SPAN({
      "class": [ "ilabel", " ", "optional" ]
    }, "tiền còn nợ"), "\n", HTML.INPUT({
      "class": "debit",
      value: function() {
        return Spacebars.mustache(Spacebars.dot(view.lookup("currentImport"), "debit"));
      },
      disabled: ""
    })), "\n", HTML.DIV({
      "class": [ "editor-wrapper", " ", "right" ],
      style: "width: 120px"
    }, HTML.SPAN({
      "class": [ "ilabel", " ", "optional" ]
    }, "tiền đã trả"), "\n", HTML.INPUT({
      "class": "deposit",
      value: function() {
        return Spacebars.mustache(Spacebars.dot(view.lookup("currentImport"), "deposit"));
      }
    })), "\n", HTML.DIV({
      "class": [ "editor-wrapper", " ", "right" ],
      style: "width: 120px"
    }, HTML.SPAN({
      "class": [ "ilabel", " ", "optional" ]
    }, "tổng tiền"), "\n", HTML.INPUT({
      "class": "totalPrice",
      value: function() {
        return Spacebars.mustache(Spacebars.dot(view.lookup("currentImport"), "totalPrice"));
      },
      disabled: ""
    })), "\n", HTML.DIV({
      "class": [ "editor-wrapper", " ", "right" ],
      style: "width: 300px"
    }, HTML.SPAN({
      "class": "ilabel"
    }, "description"), "\n", HTML.INPUT({
      "class": "description",
      value: function() {
        return Spacebars.mustache(Spacebars.dot(view.lookup("currentImport"), "description"));
      }
    })), "\n", HTML.DIV({
      "class": [ "editor-wrapper", " ", "right" ],
      style: "width: 180px"
    }, HTML.SPAN({
      "class": [ "ilabel", " ", "optional" ]
    }, "người tạo"), "\n", HTML.INPUT({
      "class": "emailCreator",
      value: function() {
        return Spacebars.mustache(view.lookup("userNameFromId"), Spacebars.dot(view.lookup("currentImport"), "creator"));
      },
      disabled: ""
    })));
  }), "\n", Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("tabOptions"))
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("tabComponent"));
  })) ];
}));

})();

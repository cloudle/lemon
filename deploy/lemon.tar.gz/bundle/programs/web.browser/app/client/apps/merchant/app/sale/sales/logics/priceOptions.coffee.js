(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Apps.Merchant.salesInit.push(function() {
  return logics.sales.priceOptions = {
    reactiveSetter: function(val) {
      return Order.update(logics.sales.currentOrder._id, {
        $set: {
          currentPrice: val
        }
      });
    },
    reactiveValue: function() {
      var _ref, _ref1;
      return (_ref = (_ref1 = Session.get('currentOrder')) != null ? _ref1.currentPrice : void 0) != null ? _ref : 0;
    },
    reactiveMax: function() {
      return 999999999;
    },
    reactiveMin: function() {
      var _ref, _ref1;
      return (_ref = (_ref1 = logics.sales.currentProduct) != null ? _ref1.price : void 0) != null ? _ref : 0;
    },
    reactiveStep: function() {
      return 1000;
    }
  };
});

})();

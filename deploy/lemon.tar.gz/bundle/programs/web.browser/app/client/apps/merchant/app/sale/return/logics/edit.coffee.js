(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
logics.returns.editReturn = function(returnId) {
  var currentReturn, error, returnDetail, userProfile, _i, _len, _ref;
  try {
    if (!(userProfile = Schema.userProfiles.findOne({
      user: Meteor.userId()
    }))) {
      throw 'Lỗi, Bạn chưa đăng nhập.';
    }
    if (!(currentReturn = Schema.returns.findOne({
      _id: returnId,
      creator: userProfile.user
    }))) {
      throw 'Lỗi, Phiếu trả không chính xác.';
    }
    if (currentReturn.status === 1) {
      Schema.returns.update(currentReturn._id, {
        $set: {
          status: 0
        }
      });
      _ref = Schema.returnDetails.find({
        "return": currentReturn._id,
        submit: true
      }).fetch();
      for (_i = 0, _len = _ref.length; _i < _len; _i++) {
        returnDetail = _ref[_i];
        Schema.returnDetails.update(returnDetail._id, {
          $set: {
            submit: false
          }
        });
      }
      throw 'Ok, Phiếu đã có thể chỉnh sửa.';
    }
    if (currentReturn.status === 0) {
      throw 'Lỗi, Phiếu chưa được xác nhận từ nhân viên.';
    }
    if (currentReturn.status === 2) {
      throw 'Lỗi, Phiếu đã được duyệt, không thể thao tác.';
    }
  } catch (_error) {
    error = _error;
    return console.log(error);
  }
};

})();

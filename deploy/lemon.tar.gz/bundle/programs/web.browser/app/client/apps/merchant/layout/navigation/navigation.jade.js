(function(){
Template.__define__("navigation", (function() {
  var view = this;
  return HTML.NAV({
    role: "navigation",
    "class": [ "navbar", " ", "main", " ", "navbar-fixed-top" ]
  }, HTML.DIV({
    "class": "wrapper"
  }, HTML.A({
    "class": "branding"
  }, HTML.Raw('<span class="logo">EDS</span>'), "\n", HTML.SPAN({
    "class": "version"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("systemVersion"));
  }))), "\n", HTML.UL({
    "class": [ "nav", " ", "navbar-nav", " ", "navbar-right", " ", "notifications" ]
  }, Blaze.If(function() {
    return Spacebars.call(view.lookup("tourVisible"));
  }, function() {
    return HTML.LI({
      "class": "inav"
    }, HTML.SPAN({
      "class": "tour-toggle"
    }, HTML.I({
      "class": "icon-light-up"
    })));
  }), "\n", HTML.LI({
    "class": "inav"
  }, Spacebars.include(view.lookupTemplate("messageNotifications")), "\n", HTML.DIV({
    "class": function() {
      return [ "notification-counts", " ", Spacebars.mustache(view.lookup("activeClassByCount"), view.lookup("unreadMessageCount")) ];
    }
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("unreadMessageCount"));
  })), "\n", HTML.Raw('<span class="dropdown-toggle" data-toggle="dropdown"><i class="icon-chat-6"></i></span>')), "\n", HTML.LI({
    "class": "inav"
  }, Spacebars.include(view.lookupTemplate("notificationDetails")), "\n", HTML.DIV({
    "class": function() {
      return [ "notification-counts", " ", Spacebars.mustache(view.lookup("activeClassByCount"), view.lookup("unreadNotifiesCount")) ];
    }
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("unreadNotifiesCount"));
  })), "\n", HTML.Raw('<span class="dropdown-toggle" data-toggle="dropdown"><i class="icon-globe-6"></i></span>')), "\n", HTML.LI({
    "class": "inav"
  }, Spacebars.include(view.lookupTemplate("requestDetails")), "\n", HTML.DIV({
    "class": function() {
      return [ "notification-counts", " ", Spacebars.mustache(view.lookup("activeClassByCount"), view.lookup("unreadRequestCount")) ];
    }
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("unreadRequestCount"));
  })), "\n", HTML.Raw('<span class="dropdown-toggle" data-toggle="dropdown"><i class="icon-share-3"></i></span>'))), "\n", HTML.UL({
    "class": [ "nav", " ", "navbar-nav" ]
  }, HTML.Raw('<li class="inav"><span id="logoutButton"><i class="icon-off-1"></i></span></li>'), "\n", HTML.LI({
    "class": function() {
      return [ "home", " ", Spacebars.mustache(view.lookup("isActiveRoute"), Spacebars.kw({
        regex: "merchantHome"
      })) ];
    }
  }, HTML.A({
    href: function() {
      return Spacebars.mustache(view.lookup("pathFor"), "merchantHome");
    }
  }, HTML.Raw('<i class="icon-home-4"></i>'))), "\n", HTML.Raw("<!--\na(href=\"{{pathFor 'taskManager'}}\"): i.icon-clipboard-2\n-->"), "\n", Blaze.Each(function() {
    return Spacebars.call(view.lookup("subMenus"));
  }, function() {
    return HTML.LI({
      "class": function() {
        return [ "inav", " ", Spacebars.mustache(view.lookup("isActiveRoute"), Spacebars.kw({
          regex: view.lookup("route")
        })) ];
      }
    }, HTML.A({
      href: function() {
        return Spacebars.mustache(view.lookup("pathFor"), view.lookup("route"));
      }
    }, HTML.I({
      "class": function() {
        return [ "fa", " ", Spacebars.mustache(view.lookup("icon")) ];
      }
    })));
  }))));
}));

})();

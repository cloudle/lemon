(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
logics.inventoryManager.updateDescription = function(context) {
  if (Session.get("currentInventory")) {
    if (context.ui.$description.val().length > 1) {
      return Schema.inventories.update(Session.get("currentInventory")._id, {
        $set: {
          description: context.ui.$description.val()
        }
      });
    } else {
      return context.ui.$description.val(Session.get("currentInventory").description);
    }
  }
};

})();

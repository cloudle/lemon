(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineWidget(Template.addProvider, {
  allowDelete: function() {
    if (Schema.importDetails.findOne({
      provider: this._id,
      merchant: Session.get('myProfile').currentMerchant
    })) {
      return false;
    } else {
      return true;
    }
  },
  events: {
    'click .create-provider': function(event, template) {
      return logics["import"].createNewProvider(event, template);
    },
    'click .delete-provider': function(event, template) {
      return logics["import"].removeNewProvider(this._id);
    }
  }
});

})();

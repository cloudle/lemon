(function(){
Template.__define__("silentLoadingLayout", (function() {
  var view = this;
  return "";
}));

})();

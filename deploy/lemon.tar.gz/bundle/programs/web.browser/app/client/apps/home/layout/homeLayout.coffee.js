(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineWidget(Template.homeLayout, {
  rendered: function() {
    return $("body").css("overflow-y", "scroll");
  },
  destroyed: function() {
    return $("body").css("overflow-y", "hidden");
  }
});

})();

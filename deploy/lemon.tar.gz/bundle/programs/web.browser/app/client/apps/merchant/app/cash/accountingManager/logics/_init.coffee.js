(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
logics.accountingManager = {};

Apps.Merchant.accountingManagerInit = [];

Apps.Merchant.accountingManagerReload = [];

Apps.Merchant.accountingManagerInit.push(function(scope) {
  var date, firstDay, lastDay;
  date = new Date();
  firstDay = new Date(date.getFullYear(), date.getMonth(), 15);
  lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0);
  Session.set('accountingFilterStartDate', firstDay);
  return Session.set('accountingFilterToDate', lastDay);
});

Apps.Merchant.accountingManagerReload.push(function(scope) {});

logics.accountingManager.reactiveRun = function() {
  if (Session.get('accountingFilterStartDate') && Session.get('accountingFilterToDate') && Session.get('myProfile')) {
    return logics.accountingManager.availableAccounting = Sale.findAccountingDetails(Session.get('accountingFilterStartDate'), Session.get('accountingFilterToDate'), Session.get('myProfile').currentWarehouse);
  }
};

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
logics.warehouseManager = {};

Apps.Merchant.warehouseManagerInit = [];

Apps.Merchant.warehouseManagerInit.push(function(scope) {
  Session.setDefault('allowCreateNewWarehouse', false);
  return logics.warehouseManager.availableWarehouses = Schema.warehouses.find({
    merchant: Session.get('myProfile').currentMerchant
  });
});

logics.warehouseManager.reactiveRun = function() {
  if (Session.get('allowCreateNewWarehouse')) {
    return logics.warehouseManager.allowCreate = '';
  } else {
    return logics.warehouseManager.allowCreate = 'disabled';
  }
};

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var inventoryHistoryRoute;

inventoryHistoryRoute = {
  template: 'inventoryHistory',
  waitOnDependency: 'inventoryHistory',
  onBeforeAction: function() {
    if (this.ready()) {
      Apps.setup(logics.inventoryHistory, Apps.Merchant.inventoryHistoryInit, 'inventoryHistory');
      return this.next();
    }
  },
  data: function() {
    Apps.setup(logics.inventoryHistory, Apps.Merchant.inventoryHistoryReactiveRun);
    return {
      gridOptions: logics.inventoryHistory.gridOptions,
      branchSelectOptions: logics.inventoryHistory.branchSelectOptions,
      warehouseSelectOptions: logics.inventoryHistory.warehouseSelectOptions,
      currentInventory: Session.get('currentInventoryHistory'),
      currentInventoryDetails: logics.inventoryHistory.currentInventoryDetailHistory,
      currentInventoryProductLost: logics.inventoryHistory.currentInventoryProductLostHistory
    };
  }
};

lemon.addRoute([inventoryHistoryRoute], Apps.Merchant.RouterBase);

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineWidget(Template.notificationDetails, {
  notifies: function() {
    return logics.merchantNotification.notifies;
  },
  unreadNotifies: function() {
    return logics.merchantNotification.unreadNotifies;
  }
});

})();

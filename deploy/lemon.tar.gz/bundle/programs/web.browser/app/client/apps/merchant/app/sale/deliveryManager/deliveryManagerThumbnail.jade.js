(function(){
Template.__define__("deliveryManagerThumbnail", (function() {
  var view = this;
  return HTML.DIV({
    "class": function() {
      return [ "thumbnails", " ", [ Spacebars.mustache(view.lookup("styles")) ] ];
    }
  }, HTML.DIV({
    "class": "right-caption"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("showStatus"), view.lookup("status"));
  })), "\n", Spacebars.TemplateWith(function() {
    return {
      avatar: Spacebars.call(view.lookup("avatarUrl")),
      alias: Spacebars.call(view.lookup("customerAlias"))
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("avatarImageComponent"));
  }), HTML.Raw('\n<!--.short-desc.quality-->\n<!--  button.btn.btn-default.unSuccessDelivery(style="{{hideButtonUnSuccess status}}") {{buttonUnSuccessText status}}-->\n<!--.single-price-->\n<!--  button.btn.btn-default.successDelivery(style="{{hideButtonSuccess status}}") {{buttonSuccessText status}}-->\n'), HTML.DIV({
    "class": "command-container"
  }, Blaze.If(function() {
    return Spacebars.call(view.lookup("showSelectCommand"));
  }, function() {
    return HTML.DIV({
      "class": [ "command-button", " ", "select-command", " ", "icon-paper-plane-empty" ]
    });
  }), "\n", Blaze.If(function() {
    return Spacebars.call(view.lookup("showStartCommand"));
  }, function() {
    return HTML.DIV({
      "class": [ "command-button", " ", "start-command", " ", "icon-truck-1" ]
    });
  }), "\n", Blaze.If(function() {
    return Spacebars.call(view.lookup("showConfirmCommand"));
  }, function() {
    return [ HTML.DIV({
      "class": [ "command-button", " ", "animated", " ", "bounceIn", " ", "fail-command", " ", "icon-emo-cry" ]
    }), "\n", HTML.DIV({
      "class": [ "command-button", " ", "animated", " ", "bounceIn", " ", "success-command", " ", "icon-ok-6" ]
    }) ];
  }), "\n", Blaze.If(function() {
    return Spacebars.call(view.lookup("showFinishCommand"));
  }, function() {
    return HTML.DIV({
      "class": [ "command-button", " ", "finish-command", " ", "icon-award" ]
    });
  }), "\n", Blaze.If(function() {
    return Spacebars.call(view.lookup("showCancelCommand"));
  }, function() {
    return HTML.DIV({
      "class": [ "command-button", " ", "cancel-command", " ", "icon-reply-3" ]
    });
  })));
}));

})();

(function(){
Template.__define__("myAvatarItem", (function() {
  var view = this;
  return HTML.LI({
    "class": [ "chat-avatar", " ", "me" ]
  }, HTML.Raw('<input class="avatarFileSelector" type="file">\n'), HTML.DIV({
    "class": function() {
      return [ "online-status-orb", " ", Spacebars.mustache(view.lookup("onlineStatus"), view.lookup("user")) ];
    }
  }), "\n", HTML.DIV({
    "class": "alias"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("shortAlias"));
  })), "\n", Spacebars.TemplateWith(function() {
    return {
      avatar: Spacebars.call(view.lookup("avatarUrl")),
      alias: Spacebars.call(view.lookup("fullName"))
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("avatarImageComponent"));
  }));
}));

})();

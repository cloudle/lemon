(function(){
Template.__define__("customerManager", (function() {
  var view = this;
  return [ Spacebars.include(view.lookupTemplate("customerProfileManager")), HTML.DIV({
    id: "header"
  }, HTML.Raw('<div class="caption-row"><div class="title">KHÁCH HÀNG <small>CRM</small></div>\n<div class="switches"><input binding="switch" type="checkbox" name="genderMode" checked="true"></div></div>'), "\n", HTML.DIV({
    "class": "editor-row"
  }, HTML.Raw('<div class="editor-wrapper"><span class="ilabel">tên khách hàng</span>\n<input name="fullName" maxlength="40"></div>'), "\n", HTML.Raw('<div class="editor-wrapper" style="width: 120px"><span class="ilabel">điện thoại</span>\n<input name="phone" maxlength="15"></div>'), "\n", HTML.Raw('<div class="editor-wrapper" style="width: 300px"><span class="ilabel optional">địa chỉ</span>\n<input name="address"></div>'), "\n", HTML.Raw('<div class="editor-wrapper" style="width: 120px"><span class="ilabel optional">sinh nhật</span>\n<input binding="datePicker" todayHighlight="true" name="dateOfBirth"></div>'), "\n", HTML.DIV({
    "class": "editor-wrapper"
  }, HTML.BUTTON({
    "class": function() {
      return [ "lemon", " ", "btn", " ", "lime", " ", "icon-user-add-1", " ", Spacebars.mustache(view.lookup("allowCreate")) ];
    },
    id: "createCustomerAccount"
  }, "TẠO MỚI")), "\n", HTML.Raw('<div class="editor-wrapper pull-right"><input class="hidden excelFileSource" type="file">\n<button class="lemon btn blue pull-right excel-customer" type="submit" data-toggle="tooltip" data-container="body" data-placement="left" title="Tự động nhập"><span class="icon-user-add-1"></span></button></div>'))), HTML.DIV({
    id: "content",
    "class": "customer-manager"
  }, Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("gridOptions"))
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("iGrid"));
  })) ];
}));

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
logics.deliveryManager = {};

Apps.Merchant.deliveryManagerInit = [];

Apps.Merchant.deliveryManagerInit.push(function(scope) {
  return Session.setDefault('deliveryFilter', 'working');
});

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var deliveryManagerRoute;

deliveryManagerRoute = {
  template: 'deliveryManager',
  waitOnDependency: 'deliveryManager',
  onBeforeAction: function() {
    if (this.ready()) {
      Apps.setup(logics.deliveryManager, Apps.Merchant.deliveryManagerInit, 'deliveryManager');
      return this.next();
    }
  },
  data: function() {
    return {
      waitingGridOptions: logics.deliveryManager.waitingGridOptions,
      deliveringGridOptions: logics.deliveryManager.deliveringGridOptions,
      doneGridOptions: logics.deliveryManager.doneGridOptions
    };
  }
};

lemon.addRoute([deliveryManagerRoute], Apps.Merchant.RouterBase);

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var checkAllow;

checkAllow = function(context) {
  var _ref, _ref1, _ref2, _ref3, _ref4, _ref5, _ref6;
  if (context.status === true && (((context.submitted === (_ref2 = context.exported) && _ref2 === (_ref1 = context.imported)) && _ref1 === (_ref = context.received)) && _ref === false) && (context.paymentsDelivery === 0 || context.paymentsDelivery === 1)) {
    return true;
  }
  if ((((context.status === (_ref5 = context.success) && _ref5 === (_ref4 = context.received)) && _ref4 === (_ref3 = context.exported)) && _ref3 === true) && (context.submitted === (_ref6 = context.imported) && _ref6 === false) && context.paymentsDelivery === 1) {
    return true;
  }
};

lemon.defineWidget(Template.accountingManagerThumbnail, {
  buyerName: function() {
    var _ref;
    return (_ref = Schema.customers.findOne(this.buyer)) != null ? _ref.name : void 0;
  },
  sellerName: function() {
    var _ref;
    return (_ref = Schema.userProfiles.findOne(this.creator)) != null ? _ref.fullName : void 0;
  },
  group: function() {
    if (this.paymentsDelivery === 0) {
      return 'Phiếu Bán';
    }
    if (this.paymentsDelivery === 1) {
      return 'Phiếu Giao';
    }
  },
  formatNumber: function() {
    var number;
    if (this.received && this.exported) {
      number = this.debit;
    } else {
      number = this.deposit;
    }
    return accounting.formatMoney(number, {
      format: "%v",
      precision: 0
    });
  },
  showInput: function() {
    if (!checkAllow(this)) {
      return "display: none";
    }
  },
  showInputText: function() {
    if (checkAllow(this)) {
      return 'Đã Nhận Tiền';
    }
  },
  events: {
    "click .confirmReceive": function() {
      return logics.accountingManager.confirmReceiveSale(this);
    }
  }
});

})();

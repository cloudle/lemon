(function(){
Template.__define__("homeNavigation", (function() {
  var view = this;
  return HTML.UL({
    "class": "home-navigation"
  }, HTML.LI(HTML.SPAN({
    "class": [ "menu-item", " ", "icon-doc" ]
  }, HTML.SPAN({
    "class": "main-caption"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("i18n"), "home.news");
  })), "\n", HTML.SPAN({
    "class": "sub-caption"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("i18n"), "home.subNews");
  })))), "\n", HTML.LI(HTML.SPAN({
    "class": [ "menu-item", " ", "icon-lightbulb" ]
  }, HTML.SPAN({
    "class": "main-caption"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("i18n"), "home.support");
  })), "\n", HTML.SPAN({
    "class": "sub-caption"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("i18n"), "home.subSupport");
  })))), "\n", HTML.LI(HTML.SPAN({
    "class": [ "menu-item", " ", "icon-comment" ]
  }, HTML.SPAN({
    "class": "main-caption"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("i18n"), "home.customer");
  })), "\n", HTML.SPAN({
    "class": "sub-caption"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("i18n"), "home.subCustomer");
  })))), "\n", HTML.LI(HTML.SPAN({
    "class": [ "menu-item", " ", "icon-beaker" ]
  }, HTML.SPAN({
    "class": "main-caption"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("i18n"), "home.feature");
  })), "\n", HTML.SPAN({
    "class": "sub-caption"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("i18n"), "home.subFeature");
  })))), "\n", HTML.LI(HTML.SPAN({
    "class": [ "menu-item", " ", "icon-wallet" ]
  }, HTML.SPAN({
    "class": "main-caption"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("i18n"), "home.priceTable");
  })), "\n", HTML.SPAN({
    "class": "sub-caption"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("i18n"), "home.subPriceTable");
  })))), "\n", HTML.LI(HTML.SPAN({
    "class": [ "menu-item", " ", "icon-location" ]
  }, HTML.SPAN({
    "class": "main-caption"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("i18n"), "home.contact");
  })), "\n", HTML.SPAN({
    "class": "sub-caption"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("i18n"), "home.subContact");
  })))));
}));

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Apps.Merchant.salesInit.push(function() {
  return logics.sales.createNewOrderAndSelected = function() {
    var buyer, newOrderId;
    buyer = Schema.customers.findOne(logics.sales.currentOrder.buyer);
    newOrderId = Order.createdNewBy(buyer, Session.get('myProfile'));
    if (newOrderId) {
      return logics.sales.selectOrder(newOrderId);
    }
  };
});

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineWidget(Template.importHistoryDetail, {
  showFinish: function() {
    var _ref, _ref1, _ref2;
    if (Role.hasPermission((_ref = Session.get('myProfile')) != null ? _ref.user : void 0, Apps.Merchant.Permissions.su.key)) {
      if (((_ref1 = this["import"]) != null ? _ref1.finish : void 0) === false && ((_ref2 = this["import"]) != null ? _ref2.submitted : void 0) === true) {
        return true;
      }
    }
  },
  status: function() {
    var _ref, _ref1, _ref2, _ref3;
    if (((_ref = this["import"]) != null ? _ref.submitted : void 0) === true && ((_ref1 = this["import"]) != null ? _ref1.finish : void 0) === false) {
      return 'chờ xác nhận';
    }
    if (((_ref2 = this["import"]) != null ? _ref2.submitted : void 0) === true && ((_ref3 = this["import"]) != null ? _ref3.finish : void 0) === true) {
      return 'đã nhập kho';
    }
  },
  rendered: function() {},
  events: {
    "click .finish": function(event, template) {
      var _ref, _ref1;
      if (((_ref = this["import"]) != null ? _ref.submitted : void 0) === true && ((_ref1 = this["import"]) != null ? _ref1.finish : void 0) === false) {
        return logics["import"].finish(this["import"]._id);
      }
    }
  }
});

})();

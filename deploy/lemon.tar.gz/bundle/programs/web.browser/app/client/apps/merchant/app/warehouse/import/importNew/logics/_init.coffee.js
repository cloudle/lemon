(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
logics["import"] = {};

Apps.Merchant.importInit = [];

Apps.Merchant.importReload = [];

Apps.Merchant.importInit.push(function(scope) {
  logics["import"].availableProducts = Product.insideWarehouse(Session.get('myProfile').currentWarehouse);
  logics["import"].availableSkulls = Skull.insideMerchant(Session.get('myProfile').parentMerchant);
  logics["import"].availableProviders = Provider.insideMerchant(Session.get('myProfile').parentMerchant);
  logics["import"].branchProviders = Provider.insideBranch(Session.get('myProfile').currentMerchant);
  logics["import"].myHistory = Import.myHistory(Session.get('myProfile').user, Session.get('myProfile').currentWarehouse, Session.get('myProfile').currentMerchant);
  logics["import"].myCreateProduct = Product.canDeleteByMeInside();
  return logics["import"].myCreateProvider = Provider.canDeleteByMe();
});

logics["import"].reactiveRun = function() {
  var currentImport, permission;
  if (Session.get('mySession') && Session.get('myProfile')) {
    logics["import"].currentImport = Import.findBy(Session.get('mySession').currentImport, Session.get('myProfile').currentWarehouse, Session.get('myProfile').currentMerchant);
  }
  if (currentImport = logics["import"].currentImport) {
    Session.set('currentImport', logics["import"].currentImport);
    Meteor.subscribe('importDetails', logics["import"].currentImport._id);
    logics["import"].currentImportDetails = ImportDetail.findBy(logics["import"].currentImport._id);
    logics["import"].hidePriceSale = logics["import"].currentImport.currentPrice > 0;
    logics["import"].showCreateDetail = !currentImport.submitted;
    logics["import"].showEdit = currentImport.submitted;
    permission = Role.hasPermission(Session.get('myProfile').user, Apps.Merchant.Permissions.su.key);
    logics["import"].showSubmit = logics["import"].currentImportDetails.count() > 0 && !currentImport.submitted && !permission;
    return logics["import"].showFinish = logics["import"].currentImportDetails.count() > 0 && !logics["import"].showSubmit;
  }
};

})();

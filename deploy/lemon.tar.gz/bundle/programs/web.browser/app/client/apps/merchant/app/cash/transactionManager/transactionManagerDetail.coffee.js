(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineWidget(Template.transactionManagerDetail, {
  groupType: function(group) {
    switch (group) {
      case 'sale':
        return 'Phiếu bán hàng';
      case 'import':
        return 'Phiếu nhập hàng';
      case 'customer':
        return 'Phiếu do nhân viên tạo';
    }
  },
  status: function() {
    var _ref;
    if (((_ref = this.transaction) != null ? _ref.debitCash : void 0) > 0) {
      return 'Phiếu còn nợ';
    } else {
      return 'Phiếu hết nợ';
    }
  },
  formatDate: function(date) {
    return moment(date).format("DD/MM/YYYY");
  },
  countDetail: function() {
    var _ref, _ref1;
    return (_ref = (_ref1 = this.transactionDetail) != null ? _ref1.count() : void 0) != null ? _ref : 0;
  },
  allowAddDetail: function() {
    if (this.transaction && this.transaction.debitCash > 0) {
      return true;
    } else {
      return false;
    }
  },
  showAddDetail: function() {
    return !Session.get('showAddTransactionDetail');
  },
  showDeleteTransaction: function() {
    if (this.transactionDetail && this.transactionDetail.count() === 0 && !Session.get('showAddTransactionDetail')) {
      return true;
    } else {
      return false;
    }
  },
  createTransactionDetail: function() {
    if (Session.get('showAddTransactionDetail')) {
      return 'display: block';
    } else {
      return 'display: none';
    }
  },
  rendered: function() {
    return Session.set('transactionDetailPaymentDate', new Date());
  },
  events: {
    "click .cancelCreateTransactionDetail": function(event, template) {
      return Session.set('showAddTransactionDetail', false);
    },
    "click .showTransactionDetail": function(event, template) {
      return logics.transactionManager.showTransactionDetail();
    },
    "click .createTransactionDetail": function(event, template) {
      return logics.transactionManager.createNewTransactionDetail();
    },
    "click .deleteTransaction": function(event, template) {
      return Meteor.call('deleteTransaction', this.transaction._id, function(error, result) {
        if (error) {
          return console.log(error);
        }
      });
    },
    "change [name ='createDebtDate']": function(event, template) {
      return Session.set('transactionDetailPaymentDate', $("[name=createDebtDate]").datepicker().data().datepicker.dates[0]);
    }
  },
  depositCashOptions: {
    reactiveSetter: function(val) {
      return Session.set('depositCashNewTransactionDetail', val);
    },
    reactiveValue: function() {
      var _ref;
      return (_ref = Session.get('depositCashNewTransactionDetail')) != null ? _ref : 0;
    },
    reactiveMax: function() {
      var _ref, _ref1;
      return (_ref = (_ref1 = Session.get('currentTransaction')) != null ? _ref1.debitCash : void 0) != null ? _ref : 0;
    },
    reactiveMin: function() {
      return 0;
    },
    reactiveStep: function() {
      return 10000;
    }
  }
});

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Apps.Merchant.transportHistoryInit.push(function(scope) {
  return logics.transportHistory.gridOptions = {
    itemTemplate: 'transportHistoryThumbnail',
    reactiveSourceGetter: function() {
      return logics.transportHistory.availableTransports;
    },
    wrapperClasses: 'detail-grid row'
  };
});

})();

(function(){
Template.__define__("merchantPriceTableExtension", (function() {
  var view = this;
  return [ HTML.LI({
    "class": "icon-group"
  }, Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("accountLimitOptions"))
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("iSpinEdit"));
  }), "\n", "Tài khoản"), HTML.LI({
    "class": "icon-location-1"
  }, Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("branchLimitOptions"))
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("iSpinEdit"));
  }), "\n", "Chi nhánh"), HTML.LI({
    "class": "icon-home-4"
  }, Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("warehouseLimitOptions"))
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("iSpinEdit"));
  }), "\n", "Kho hàng") ];
}));

})();

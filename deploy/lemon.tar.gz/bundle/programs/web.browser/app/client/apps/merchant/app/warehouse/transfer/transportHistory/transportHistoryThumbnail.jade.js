(function(){
Template.__define__("transportHistoryThumbnail", (function() {
  var view = this;
  return HTML.DIV({
    "class": "col"
  }, HTML.DIV({
    "class": function() {
      return [ "thumbnails", " ", [ Spacebars.mustache(view.lookup("colorClass")) ] ];
    }
  }, HTML.DIV({
    "class": "right-caption"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("creatorName"), view.lookup("creator"));
  })), "\n", HTML.DIV({
    "class": [ "short-desc", " ", "quality" ]
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("status"));
  })), "\n", HTML.DIV({
    "class": "single-price"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("description"));
  })), "\n", HTML.DIV({
    "class": [ "full-desc", " ", "price" ]
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("createDate"));
  }))));
}));

})();

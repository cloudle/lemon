(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var importRoute;

importRoute = {
  template: 'import',
  waitOnDependency: 'warehouseImport',
  onBeforeAction: function() {
    if (this.ready()) {
      Apps.setup(logics["import"], Apps.Merchant.importInit, 'import');
      return this.next();
    }
  },
  data: function() {
    var _ref;
    logics["import"].reactiveRun();
    return {
      creatorName: (_ref = Session.get('myProfile')) != null ? _ref.fullName : void 0,
      showCreateDetail: logics["import"].showCreateDetail,
      showSubmit: logics["import"].showSubmit,
      showFinish: logics["import"].showFinish,
      showEdit: logics["import"].showEdit,
      hidePriceSale: logics["import"].hidePriceSale,
      myCreateProduct: logics["import"].myCreateProduct,
      myCreateProvider: logics["import"].myCreateProvider,
      tabOptions: logics["import"].tabOptions,
      importDetailOptions: logics["import"].importDetailOptions,
      currentImport: logics["import"].currentImport,
      productSelectOptions: logics["import"].productSelectOptions,
      providerSelectOptions: logics["import"].providerSelectOptions,
      timeUseSelectOptions: logics["import"].timeUseSelectOptions,
      qualityOptions: logics["import"].qualityOptions,
      importPriceOptions: logics["import"].importPriceOptions,
      salePriceOptions: logics["import"].salePriceOptions
    };
  }
};

lemon.addRoute([importRoute], Apps.Merchant.RouterBase);

})();

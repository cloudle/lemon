(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var formatWarehouseSearch;

formatWarehouseSearch = function(item) {
  if (item) {
    return "" + item.name;
  }
};

Apps.Merchant.inventoryManagerInit.push(function(scope) {
  return logics.inventoryManager.warehouseSelectOptions = {
    query: function(query) {
      return query.callback({
        results: logics.inventoryManager.availableWarehouses.fetch()
      });
    },
    initSelection: function(element, callback) {
      var _ref;
      return callback((_ref = Schema.warehouses.findOne(Session.get('mySession').currentInventoryWarehouseSelection)) != null ? _ref : 'skyReset');
    },
    reactiveValueGetter: function() {
      var _ref;
      return (_ref = Session.get('mySession').currentInventoryWarehouseSelection) != null ? _ref : 'skyReset';
    },
    changeAction: function(e) {
      scope.currentWarehouse = e.added;
      return Schema.userSessions.update(Session.get('mySession')._id, {
        $set: {
          currentInventoryWarehouseSelection: e.added._id
        }
      });
    },
    minimumResultsForSearch: -1,
    formatSelection: formatWarehouseSearch,
    formatResult: formatWarehouseSearch,
    placeholder: 'CHỌN CHI NHÁNH'
  };
});

})();

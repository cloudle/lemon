(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var calculateDefaultOrder, calculateDepositAndDebitByBill, calculateDepositAndDebitByProduct, calculateOrderDeposit, updateOrderByOrderDetail, updateOrderByOrderDetailEmpty;

calculateDepositAndDebitByProduct = function(currentOrder, orderUpdate) {
  if (currentOrder.currentDeposit > orderUpdate.finalPrice) {
    orderUpdate.currentDeposit = currentOrder.currentDeposit;
  } else {
    orderUpdate.currentDeposit = orderUpdate.finalPrice;
  }
  orderUpdate.deposit = orderUpdate.finalPrice;
  orderUpdate.debit = 0;
  return orderUpdate;
};

calculateDepositAndDebitByBill = function(currentOrder, orderUpdate) {
  if (currentOrder.currentDeposit >= orderUpdate.finalPrice) {
    orderUpdate.paymentMethod = 0;
    orderUpdate.deposit = orderUpdate.finalPrice;
    orderUpdate.debit = 0;
  } else {
    orderUpdate.deposit = currentOrder.currentDeposit;
    orderUpdate.debit = orderUpdate.finalPrice - currentOrder.currentDeposit;
  }
  return orderUpdate;
};

calculateOrderDeposit = function(currentOrder, orderOptionDefault) {
  switch (currentOrder.paymentMethod) {
    case 0:
      return calculateDepositAndDebitByProduct(currentOrder, orderOptionDefault);
    case 1:
      return calculateDepositAndDebitByBill(currentOrder, orderOptionDefault);
  }
};

calculateDefaultOrder = function(currentOrder, orderDetails) {
  var detail, orderUpdate, _i, _len;
  orderUpdate = {
    saleCount: 0,
    discountCash: 0,
    discountPercent: 0,
    totalPrice: 0
  };
  for (_i = 0, _len = orderDetails.length; _i < _len; _i++) {
    detail = orderDetails[_i];
    orderUpdate.totalPrice += detail.quality * detail.price;
    orderUpdate.saleCount += detail.quality;
    if (currentOrder.billDiscount) {
      orderUpdate.discountCash = orderUpdate.discountCash;
    } else {
      orderUpdate.discountCash += detail.discountCash;
    }
  }
  orderUpdate.discountPercent = orderUpdate.discountCash / orderUpdate.totalPrice * 100;
  orderUpdate.finalPrice = orderUpdate.totalPrice - orderUpdate.discountCash;
  return orderUpdate;
};

updateOrderByOrderDetail = function(currentOrder, orderDetails) {
  var orderOptionDefault, updateOrder;
  orderOptionDefault = calculateDefaultOrder(currentOrder, orderDetails);
  updateOrder = calculateOrderDeposit(currentOrder, orderOptionDefault);
  return Order.update(currentOrder._id, {
    $set: updateOrder
  });
};

updateOrderByOrderDetailEmpty = function(currentOrder) {
  var updateOrder;
  updateOrder = {
    saleCount: 0,
    discountCash: 0,
    discountPercent: 0,
    totalPrice: 0,
    finalPrice: 0,
    paymentMethod: 0,
    currentDeposit: 0,
    deposit: 0,
    debit: 0
  };
  return Schema.orders.update(currentOrder._id, {
    $set: updateOrder
  });
};

Apps.Merchant.salesInit.push(function() {
  return logics.sales.reCalculateOrder = function(orderId) {
    return zone.run((function(_this) {
      return function() {
        var currentOrder, orderDetails;
        currentOrder = Schema.orders.findOne(orderId);
        if (currentOrder) {
          orderDetails = Schema.orderDetails.find({
            order: orderId
          }).fetch();
          if (orderDetails.length > 0) {
            return updateOrderByOrderDetail(currentOrder, orderDetails);
          } else {
            return updateOrderByOrderDetailEmpty(currentOrder);
          }
        }
      };
    })(this));
  };
});

})();

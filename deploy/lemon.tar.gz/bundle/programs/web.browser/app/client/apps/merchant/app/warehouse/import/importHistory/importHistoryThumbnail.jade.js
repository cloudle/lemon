(function(){
Template.__define__("importHistoryThumbnail", (function() {
  var view = this;
  return HTML.DIV({
    "class": "col"
  }, HTML.DIV({
    "class": function() {
      return [ "thumbnails", " ", [ Spacebars.mustache(view.lookup("colorClass")) ] ];
    }
  }, HTML.DIV({
    "class": "left-caption"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("createDate"), Spacebars.dot(view.lookup("version"), "createdAt"));
  })), "\n", HTML.DIV({
    "class": "right-caption"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("userNameFromId"), view.lookup("creator"));
  })), "\n", HTML.DIV({
    "class": [ "short-desc", " ", "quality" ]
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("status"));
  })), "\n", HTML.Raw('<div class="single-price"></div>'), "\n", HTML.DIV({
    "class": [ "full-desc", " ", "price" ]
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("formatNumber"), view.lookup("totalPrice"));
  })), "\n", HTML.Raw('<div class="full-desc trash"><a href="#"><i class="icon-bag"></i></a></div>')));
}));

})();

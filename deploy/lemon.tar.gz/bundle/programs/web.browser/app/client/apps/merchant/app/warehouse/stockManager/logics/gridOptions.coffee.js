(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Apps.Merchant.stockManagerInit.push(function(scope) {
  return logics.stockManager.gridOptions = {
    itemTemplate: 'stockThumbnail',
    reactiveSourceGetter: function() {
      return logics.stockManager.availableProducts;
    },
    wrapperClasses: 'detail-grid row'
  };
});

})();

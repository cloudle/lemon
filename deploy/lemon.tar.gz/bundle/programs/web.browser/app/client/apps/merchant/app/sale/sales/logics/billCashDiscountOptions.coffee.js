(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var calculateBillDiscountPercent, reactiveMaxBillCashDiscount, reactiveMinBillCashDiscount;

calculateBillDiscountPercent = function(discountCash, currentOrder) {
  var option;
  if (currentOrder.billDiscount) {
    option = {
      discountCash: discountCash
    };
    if (discountCash > 0) {
      if (discountCash === currentOrder.totalPrice) {
        option.discountPercent = 100;
      } else {
        option.discountPercent = discountCash * 100 / currentOrder.totalPrice;
      }
    } else {
      option.discountPercent = 0;
    }
    option.finalPrice = currentOrder.totalPrice - option.discountCash;
  }
  return Order.update(currentOrder._id, {
    $set: option
  });
};

reactiveMaxBillCashDiscount = function() {
  var _ref, _ref1, _ref2, _ref3, _ref4;
  if ((_ref = Session.get('currentOrder')) != null ? _ref.billDiscount : void 0) {
    return (_ref1 = (_ref2 = Session.get('currentOrder')) != null ? _ref2.totalPrice : void 0) != null ? _ref1 : 0;
  } else {
    return (_ref3 = (_ref4 = Session.get('currentOrder')) != null ? _ref4.discountCash : void 0) != null ? _ref3 : 0;
  }
};

reactiveMinBillCashDiscount = function() {
  var _ref, _ref1, _ref2;
  if ((_ref = Session.get('currentOrder')) != null ? _ref.billDiscount : void 0) {
    return 0;
  } else {
    return (_ref1 = (_ref2 = Session.get('currentOrder')) != null ? _ref2.discountCash : void 0) != null ? _ref1 : 0;
  }
};

Apps.Merchant.salesInit.push(function() {
  return logics.sales.billCashDiscountOptions = {
    reactiveSetter: function(val) {
      return calculateBillDiscountPercent(val, Session.get('currentOrder'));
    },
    reactiveValue: function() {
      var _ref, _ref1;
      return (_ref = (_ref1 = Session.get('currentOrder')) != null ? _ref1.discountCash : void 0) != null ? _ref : 0;
    },
    reactiveMax: function() {
      return reactiveMaxBillCashDiscount();
    },
    reactiveMin: function() {
      return reactiveMinBillCashDiscount();
    },
    reactiveStep: function() {
      return 1000;
    },
    others: {
      forcestepdivisibility: 'none'
    }
  };
});

})();

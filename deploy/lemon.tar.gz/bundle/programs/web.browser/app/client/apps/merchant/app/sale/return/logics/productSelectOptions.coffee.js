(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var formatReturnProductSearch;

formatReturnProductSearch = function(item) {
  var product;
  if (item) {
    product = Schema.products.findOne(item.product);
    if (item) {
      return "" + (product != null ? product.name : void 0) + " [" + (product != null ? product.skulls : void 0) + "] - [giảm giá: " + (Math.round(item.discountPercent * 100) / 100) + "% - số lượng: " + (item.quality - item.returnQuality) + "]";
    }
  }
};

Apps.Merchant.returnsInit.push(function(scope) {
  return logics.returns.productSelectOptions = {
    query: function(query) {
      return query.callback({
        results: logics.returns.availableSaleDetails.fetch()
      });
    },
    initSelection: function(element, callback) {
      var _ref;
      return callback(Schema.saleDetails.findOne((_ref = Session.get('currentSale')) != null ? _ref.currentProductDetail : void 0));
    },
    formatSelection: formatReturnProductSearch,
    formatResult: formatReturnProductSearch,
    placeholder: 'CHỌN SẢN PHẨM',
    hotkey: 'return',
    changeAction: function(e) {
      return Schema.sales.update(logics.returns.currentSale._id, {
        $set: {
          currentProductDetail: e.added._id,
          currentQuality: 1
        }
      });
    },
    reactiveValueGetter: function() {
      var _ref, _ref1;
      return (_ref = (_ref1 = Session.get('currentSale')) != null ? _ref1.currentProductDetail : void 0) != null ? _ref : 'skyReset';
    }
  };
});

})();

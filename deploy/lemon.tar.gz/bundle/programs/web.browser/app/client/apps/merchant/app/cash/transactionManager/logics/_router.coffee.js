(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var transactionManagerRoute;

transactionManagerRoute = {
  template: 'transactionManager',
  waitOnDependency: 'transactionManager',
  onBeforeAction: function() {
    if (this.ready()) {
      Apps.setup(logics.transactionManager, Apps.Merchant.transactionManagerInit, 'transactionManager');
      return this.next();
    }
  },
  data: function() {
    Apps.setup(logics.transactionManager, Apps.Merchant.transactionManagerReactiveRun);
    return {
      newTransaction: Session.get('createNewTransaction'),
      gridOptions: logics.transactionManager.gridOptions,
      totalCashOptions: logics.transactionManager.totalCashOptions,
      depositCashOptions: logics.transactionManager.depositCashOptions,
      customerSelectOptions: logics.transactionManager.customerSelectOptions,
      currentTransaction: Session.get('currentTransaction'),
      currentTransactionDetail: logics.transactionManager.transactionDetails
    };
  }
};

lemon.addRoute([transactionManagerRoute], Apps.Merchant.RouterBase);

})();

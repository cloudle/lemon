(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
logics.stockManager.totalStockProduct = function() {
  var item, total, _i, _len, _ref;
  total = 0;
  if (logics.stockManager.availableProducts) {
    _ref = logics.stockManager.availableProducts.fetch();
    for (_i = 0, _len = _ref.length; _i < _len; _i++) {
      item = _ref[_i];
      total += item.inStockQuality;
    }
  }
  return total;
};

})();

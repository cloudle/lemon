(function(){
Template.__define__("homeLayout", (function() {
  var view = this;
  return [ Spacebars.include(view.lookupTemplate("homeTopPanel")), HTML.DIV({
    "class": "animated-bg"
  }, HTML.SECTION({
    id: "homeHeader"
  }, HTML.DIV({
    "class": "home-wrapper"
  }, Spacebars.include(view.lookupTemplate("homeHeader")), "\n", HTML.Raw("<!--+homeNavigation-->"))), "\n", HTML.SECTION({
    id: "homeContent"
  }, Spacebars.include(view.lookupTemplate("yield")))), HTML.SECTION({
    id: "homeFooter"
  }, Spacebars.include(view.lookupTemplate("homeFooter"))) ];
}));

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineApp(Template.exportAndImportManager, {
  rendered: function() {
    $("[name=fromDate]").datepicker('setDate', Session.get('exportAndImportFilterStartDate'));
    return $("[name=toDate]").datepicker('setDate', Session.get('exportAndImportFilterToDate'));
  },
  events: {
    "click #filterBills": function(event, template) {
      Session.set('exportAndImportFilterStartDate', $("[name=fromDate]").datepicker().data().datepicker.dates[0]);
      return Session.set('exportAndImportFilterToDate', $("[name=toDate]").datepicker().data().datepicker.dates[0]);
    }
  }
});

})();

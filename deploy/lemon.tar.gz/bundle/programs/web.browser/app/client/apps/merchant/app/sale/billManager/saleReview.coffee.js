(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineWidget(Template.saleReview, {
  dayOfWeek: function() {
    var _ref;
    return moment((_ref = Session.get('currentBillManagerSale')) != null ? _ref.version.createdAt : void 0).format("dddd");
  },
  timeDMY: function() {
    var _ref;
    return moment((_ref = Session.get('currentBillManagerSale')) != null ? _ref.version.createdAt : void 0).format("DD/MM/YYYY");
  },
  timeHM: function() {
    var _ref;
    return moment((_ref = Session.get('currentBillManagerSale')) != null ? _ref.version.createdAt : void 0).format("hh:mm");
  },
  timeS: function() {
    var _ref;
    return moment((_ref = Session.get('currentBillManagerSale')) != null ? _ref.version.createdAt : void 0).format("ss");
  },
  soldPrice: function() {
    return this.price - (this.price * this.discountPercent);
  },
  discountVisible: function() {
    return this.discountPercent > 0;
  },
  events: {
    "click .print-button": function() {
      return window.print();
    }
  }
});

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Apps.Merchant.returnsInit.push(function(scope) {
  return logics.returns.discountCashOptions = {
    reactiveSetter: function(val) {
      var option;
      option = {
        discountCash: val
      };
      if (val > 0) {
        option.discountPercent = val / logics.returns.currentReturn.totalPrice * 100;
      } else {
        option.discountPercent = 0;
      }
      option.finallyPrice = logics.returns.currentReturn.totalPrice - option.discountCash;
      if (logics.returns.currentReturn) {
        return Schema.returns.update(logics.returns.currentReturn._id, {
          $set: option
        });
      }
    },
    reactiveValue: function() {
      var _ref, _ref1;
      return (_ref = (_ref1 = logics.returns.currentReturn) != null ? _ref1.discountCash : void 0) != null ? _ref : 0;
    },
    reactiveMax: function() {
      var _ref, _ref1;
      return (_ref = (_ref1 = logics.returns.currentReturn) != null ? _ref1.totalPrice : void 0) != null ? _ref : 0;
    },
    reactiveMin: function() {
      return 0;
    },
    reactiveStep: function() {
      return 1000;
    },
    others: {
      forcestepdivisibility: 'none'
    }
  };
});

})();

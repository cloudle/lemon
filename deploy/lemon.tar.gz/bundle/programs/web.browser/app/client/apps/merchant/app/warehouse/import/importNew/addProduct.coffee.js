(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineWidget(Template.addProduct, {
  allowDelete: function() {
    if (Schema.importDetails.findOne({
      product: this._id,
      merchant: Session.get('myProfile').currentMerchant
    })) {
      return false;
    } else {
      return true;
    }
  },
  events: {
    'click .create-product': function(event, template) {
      return logics["import"].createNewProduct(event, template);
    },
    'click .delete-product': function(event, template) {
      return logics["import"].destroyNewProduct(this._id);
    }
  }
});

})();

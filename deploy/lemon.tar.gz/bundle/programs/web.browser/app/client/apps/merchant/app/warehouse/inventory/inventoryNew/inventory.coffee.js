(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineApp(Template.inventory, {
  rendered: function() {
    return logics.inventoryManager.templateInstance = this;
  },
  events: {
    "click .inventoryHistory": function(event, template) {
      return Router.go('/inventoryHistory');
    },
    "input input": function(event, template) {
      return logics.inventoryManager.checkAllowCreate(template);
    },
    'blur input': function(event, template) {
      return logics.inventoryManager.updateDescription(template);
    },
    "change [name='advancedMode']": function(event, template) {
      return logics.inventoryManager.templateInstance.ui.extras.toggleExtra('advanced', event.target.checked);
    },
    'click .createInventory': function(event, template) {
      return logics.inventoryManager.createNewInventory(event, template);
    },
    'click .destroyInventory': function(event, template) {
      return logics.inventoryManager.destroyInventory(logics.inventoryManager.currentWarehouse._id);
    },
    'click .submitInventory': function(event, template) {
      return console.log(logics.inventoryManager.successInventory(logics.inventoryManager.currentWarehouse._id));
    }
  }
});

})();

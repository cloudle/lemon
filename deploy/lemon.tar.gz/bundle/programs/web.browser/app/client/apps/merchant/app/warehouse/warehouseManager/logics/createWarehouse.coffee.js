(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var resetForm;

resetForm = function(context) {
  var item, _i, _len, _ref, _results;
  _ref = context.findAll("[name]");
  _results = [];
  for (_i = 0, _len = _ref.length; _i < _len; _i++) {
    item = _ref[_i];
    _results.push($(item).val(''));
  }
  return _results;
};

logics.warehouseManager.createWarehouse = function(context) {
  var address, name, option;
  name = context.ui.$name.val();
  address = context.ui.$address.val();
  option = {
    parentMerchant: Session.get('myProfile').parentMerchant,
    merchant: Session.get('myProfile').currentMerchant,
    creator: Session.get('myProfile').user,
    name: name,
    location: {
      address: address ? [address] : void 0
    },
    isRoot: false,
    checkingInventory: false
  };
  return Schema.warehouses.insert(option, function(error, result) {
    if (error) {
      return console.log(error);
    } else {
      MetroSummary.updateMetroSummaryBy(['warehouse']);
      Session.set('allowCreateNewWarehouse', false);
      return resetForm(context);
    }
  });
};

})();

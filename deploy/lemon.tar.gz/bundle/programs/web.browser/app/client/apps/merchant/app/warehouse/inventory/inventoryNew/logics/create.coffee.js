(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
logics.inventoryManager.createNewInventory = function(event, template) {
  var description;
  description = template.ui.$description;
  if (description.val().length > 1) {
    return Meteor.call('createNewInventory', Session.get('mySession').currentImportWarehouse, description.val(), function(error, result) {
      if (error) {
        return console.log(error);
      } else {
        return Session.set('allowCreateNewInventory', false);
      }
    });
  }
};

})();

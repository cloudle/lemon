(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineApp(Template.transactionManager, {
  unSecureMode: function() {
    return true;
  },
  allowCreate: function() {
    var newTransaction;
    newTransaction = Session.get('createNewTransaction');
    if (newTransaction.customerId !== 'skyReset' && newTransaction.totalCash > 0 && newTransaction.totalCash > newTransaction.depositCash && newTransaction.description.length > 0) {
      return '';
    } else {
      return 'disabled';
    }
  },
  activeReceivable: function(receivable) {
    if (Session.get('receivable') === receivable) {
      return 'active';
    }
  },
  activeTransactionFilter: function(filter) {
    if (Session.get('transactionFilter') === filter) {
      return 'active';
    }
  },
  rendered: function() {
    return $("[name=debtDate]").datepicker('setDate', Session.get('createNewTransaction').debtDate);
  },
  events: {
    "click [data-receivable]": function(event, template) {
      var $element;
      $element = $(event.currentTarget);
      return Session.set('receivable', $element.attr("data-receivable"));
    },
    "click [data-filter]": function(event, template) {
      var $element;
      $element = $(event.currentTarget);
      return Session.set('transactionFilter', $element.attr("data-filter"));
    },
    "input .description": function(event, template) {
      return logics.transactionManager.updateDescription(template.find(".description"));
    },
    "change [name ='debtDate']": function(event, template) {
      return logics.transactionManager.updateDebtDate();
    },
    "click .createTransaction": function(event, template) {
      return logics.transactionManager.createTransaction();
    },
    "click .thumbnails": function(event, template) {
      Meteor.subscribe('transactionDetails', this._id);
      Session.set('currentTransaction', this);
      Session.set('showAddTransactionDetail', false);
      return $(template.find('#transactionManagerDetail')).modal();
    }
  }
});

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var saleStatusIsExport, saleStatusIsImport;

saleStatusIsExport = function(sale) {
  var _ref, _ref1, _ref2;
  if ((sale.status === (_ref = sale.received) && _ref === true) && ((sale.submitted === (_ref2 = sale.exported) && _ref2 === (_ref1 = sale.imported)) && _ref1 === false) && (sale.paymentsDelivery === 0 || sale.paymentsDelivery === 1)) {
    return true;
  } else {
    return false;
  }
};

saleStatusIsImport = function(sale) {
  var _ref, _ref1, _ref2;
  if (((sale.status === (_ref1 = sale.received) && _ref1 === (_ref = sale.exported)) && _ref === true) && (sale.submitted === (_ref2 = sale.imported) && _ref2 === false) && sale.paymentsDelivery === 1) {
    return true;
  } else {
    return false;
  }
};

logics.exportAndImportManager.createSaleExport = function(currentSale) {
  var detail, option, saleDetails, _i, _j, _len, _len1;
  if (saleStatusIsExport(currentSale)) {
    saleDetails = Schema.saleDetails.find({
      sale: currentSale._id
    }).fetch();
    console.log(saleDetails);
    for (_i = 0, _len = saleDetails.length; _i < _len; _i++) {
      detail = saleDetails[_i];
      Schema.saleDetails.update(detail._id, {
        $set: {
          exported: true,
          exportDate: new Date,
          status: true
        }
      });
      Schema.productDetails.update(detail.productDetail, {
        $inc: {
          inStockQuality: -detail.quality
        }
      });
      Schema.products.update(detail.product, {
        $inc: {
          inStockQuality: -detail.quality
        }
      });
      Schema.saleExports.insert(SaleExport["new"](currentSale, detail), function(error, result) {
        if (error) {
          return console.log(error);
        }
      });
    }
    MetroSummary.updateMetroSummaryBySaleExport(currentSale._id);
    if (currentSale.paymentsDelivery === 0) {
      Schema.sales.update(currentSale._id, {
        $set: {
          submitted: true,
          exported: true
        }
      });
    }
    if (currentSale.paymentsDelivery === 1) {
      Schema.sales.update(currentSale._id, {
        $set: {
          exported: true,
          status: false
        }
      });
      Schema.deliveries.update(currentSale.delivery, {
        $set: {
          status: 3,
          exporter: Meteor.userId()
        }
      });
    }
    console.log('create ExportSale');
  }
  if (saleStatusIsImport(currentSale)) {
    saleDetails = Schema.saleDetails.find({
      sale: currentSale._id
    }).fetch();
    for (_j = 0, _len1 = saleDetails.length; _j < _len1; _j++) {
      detail = saleDetails[_j];
      option = {
        availableQuality: detail.quality,
        inStockQuality: detail.quality
      };
      Schema.productDetails.update(detail.productDetail, {
        $inc: option
      });
      Schema.products.update(detail.product, {
        $inc: option
      });
    }
    MetroSummary.updateMetroSummaryBySaleImport(currentSale._id);
    Schema.sales.update(currentSale._id, {
      $set: {
        imported: true,
        status: false
      }
    });
    Schema.deliveries.update(currentSale.delivery, {
      $set: {
        status: 9,
        importer: Meteor.userId()
      }
    });
    return console.log('create ImportSale');
  }
};

})();

(function(){
Template.__define__("inventoryHistory", (function() {
  var view = this;
  return [ Spacebars.TemplateWith(function() {
    return {
      inventory: Spacebars.call(view.lookup("currentInventory")),
      inventoryDetails: Spacebars.call(view.lookup("currentInventoryDetails")),
      productLost: Spacebars.call(view.lookup("currentInventoryProductLost"))
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("inventoryHistoryDetail"));
  }), HTML.DIV({
    id: "header"
  }, HTML.Raw('<div class="caption-row"><div class="title">Lịch Sử Kiểm Kho</div></div>'), "\n", HTML.DIV({
    "class": "editor-row"
  }, HTML.Raw('<div class="editor-wrapper pull-right"><button class="lemon btn amethyst icon-edit-alt createInventory" type="submit">KIỂM KHO</button></div>'), "\n", HTML.DIV({
    "class": "editor-wrapper",
    style: "width: 200px"
  }, HTML.Raw('<span class="ilabel">chi nhánh</span>'), "\n", Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("branchSelectOptions")),
      "class": Spacebars.call("field")
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("iSelect"));
  })), "\n", HTML.DIV({
    "class": "editor-wrapper",
    style: "width: 200px"
  }, HTML.Raw('<span class="ilabel">kho</span>'), "\n", Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("warehouseSelectOptions")),
      "class": Spacebars.call("field")
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("iSelect"));
  })), "\n", HTML.Raw('<div class="editor-wrapper" style="width: 100px"><span class="ilabel right">xem từ ngày</span>\n<input name="fromDate" binding="datePicker" todayHighlight="true" maxlength="20"></div>'), "\n", HTML.Raw('<div class="editor-wrapper" style="width: 100px"><span class="ilabel">đến ngày</span>\n<input name="toDate" binding="datePicker" todayHighlight="true" maxlength="20"></div>'), "\n", HTML.Raw('<div class="editor-wrapper"><button class="lemon btn lime icon-ok-6" id="filterInventoryHistories">ÁP DỤNG</button></div>'))), HTML.DIV({
    id: "content"
  }, Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("gridOptions"))
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("iGrid"));
  })) ];
}));

})();

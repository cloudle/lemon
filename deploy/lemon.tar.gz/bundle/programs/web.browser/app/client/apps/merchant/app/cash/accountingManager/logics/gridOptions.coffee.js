(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Apps.Merchant.accountingManagerInit.push(function(scope) {
  return logics.accountingManager.gridOptions = {
    itemTemplate: 'accountingManagerThumbnail',
    reactiveSourceGetter: function() {
      return logics.accountingManager.availableAccounting;
    },
    wrapperClasses: 'detail-grid row'
  };
});

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineWidget(Template.inventoryHistoryDetail, {
  status: function() {
    if (this.inventory) {
      if (this.inventory.submit === false && this.inventory.success === false) {
        return 'Đang kiểm kho';
      }
      if (this.inventory.submit === true && this.inventory.success === false) {
        return 'Kho có vấn đề.';
      }
      if (this.inventory.submit === true && this.inventory.success === true) {
        return 'Kho không có vấn đề.';
      }
    }
  },
  events: {
    "click .finish": function(event, template) {
      var _ref, _ref1;
      if (((_ref = this.inventory["import"]) != null ? _ref.submitted : void 0) === true && ((_ref1 = this.inventory["import"]) != null ? _ref1.finish : void 0) === false) {
        return logics["import"].finish(this.inventory["import"]._id);
      }
    }
  }
});

})();

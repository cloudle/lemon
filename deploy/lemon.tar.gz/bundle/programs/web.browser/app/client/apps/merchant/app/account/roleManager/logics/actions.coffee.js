(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
logics.roleManager.createNewRole = function(event, template) {
  var newRole;
  newRole = Schema.roles.insert({
    group: 'merchant',
    name: template.ui.$newGroupName.val()
  });
  template.ui.$newGroupName.val('');
  logics.roleManager.checkAllowCreate(template);
  return Session.set('currentRoleSelection', Schema.roles.findOne(newRole));
};

logics.roleManager.saveRoleOptions = function(event, template) {
  var newPermissions, newRole, permission, switchery, _ref;
  if (!Session.get('currentRoleSelection')) {
    return;
  }
  newPermissions = [];
  _ref = template["switch"];
  for (permission in _ref) {
    switchery = _ref[permission];
    if (switchery.isChecked()) {
      newPermissions.push(permission);
    }
  }
  Schema.roles.update(Session.get('currentRoleSelection')._id, {
    $set: {
      permissions: newPermissions
    }
  });
  newRole = Schema.roles.insert({
    group: 'merchant',
    name: template.ui.$newGroupName.val()
  });
  template.ui.$newGroupName.val('');
  logics.roleManager.checkAllowCreate(template);
  return Session.set('currentRoleSelection', Schema.roles.findOne(newRole));
};

logics.roleManager.saveRoleOptions = function(event, template) {
  var newPermissions, permission, switchery, _ref;
  if (!Session.get('currentRoleSelection')) {
    return;
  }
  newPermissions = [];
  _ref = template["switch"];
  for (permission in _ref) {
    switchery = _ref[permission];
    if (switchery.isChecked()) {
      newPermissions.push(permission);
    }
  }
  return Schema.roles.update(Session.get('currentRoleSelection')._id, {
    $set: {
      permissions: newPermissions
    }
  });
};

})();

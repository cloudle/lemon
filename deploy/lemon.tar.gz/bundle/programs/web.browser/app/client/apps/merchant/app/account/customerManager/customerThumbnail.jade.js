(function(){
Template.__define__("customerThumbnail", (function() {
  var view = this;
  return HTML.DIV({
    "class": "col"
  }, HTML.Raw('<input class="hidden avatarFile" type="file">\n'), HTML.DIV({
    "class": function() {
      return [ "thumbnails", " ", "click-enable", " ", Spacebars.mustache(view.lookup("styles")) ];
    }
  }, HTML.DIV({
    "class": "left-caption"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("dateOfBirth"));
  })), "\n", HTML.DIV({
    "class": "right-caption"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("name"));
  })), "\n", HTML.DIV({
    "class": [ "full-desc", " ", "price" ]
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("phone"));
  })), "\n", Spacebars.TemplateWith(function() {
    return {
      avatar: Spacebars.call(view.lookup("avatarUrl")),
      alias: Spacebars.call(view.lookup("name")),
      instance: Spacebars.call(view.lookup("."))
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("avatarImageComponent"));
  }), "\n", HTML.DIV({
    "class": "single-price"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("address"));
  })), "\n", HTML.DIV({
    "class": [ "short-desc", " ", "quality" ]
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("gender"));
  })), "\n", Blaze.If(function() {
    return Spacebars.call(view.lookup("allowDelete"));
  }, function() {
    return HTML.DIV({
      "class": "trash"
    }, HTML.I({
      "class": "icon-bag"
    }));
  })));
}));

})();

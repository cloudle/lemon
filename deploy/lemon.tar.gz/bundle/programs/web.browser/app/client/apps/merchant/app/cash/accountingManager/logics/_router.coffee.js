(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var accountingManagerRoute;

accountingManagerRoute = {
  template: 'accountingManager',
  waitOnDependency: 'accountingManager',
  onBeforeAction: function() {
    if (this.ready()) {
      Apps.setup(logics.accountingManager, Apps.Merchant.accountingManagerInit, 'accountingManager');
      return this.next();
    }
  },
  data: function() {
    logics.accountingManager.reactiveRun();
    return {
      gridOptions: logics.accountingManager.gridOptions
    };
  }
};

lemon.addRoute([accountingManagerRoute], Apps.Merchant.RouterBase);

})();

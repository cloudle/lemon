(function(){
Template.__define__("exportAndImportManagerThumbnail", (function() {
  var view = this;
  return HTML.DIV({
    "class": "col"
  }, HTML.DIV({
    "class": "thumbnails"
  }, HTML.DIV({
    "class": "right-caption"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("buyerName"));
  }), " ", HTML.Raw("<br>"), " ", Blaze.View(function() {
    return Spacebars.mustache(view.lookup("sellerName"));
  })), "\n", HTML.DIV({
    "class": [ "full-desc", " ", "price" ]
  }, HTML.BUTTON({
    "class": [ "btn", " ", "btn-default", " ", "createSaleExport" ],
    style: function() {
      return Spacebars.mustache(view.lookup("showInput"));
    }
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("showInputText"));
  })))));
}));

})();

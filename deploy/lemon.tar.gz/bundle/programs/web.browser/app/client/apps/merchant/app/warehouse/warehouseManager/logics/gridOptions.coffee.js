(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Apps.Merchant.warehouseManagerInit.push(function(scope) {
  return logics.warehouseManager.gridOptions = {
    itemTemplate: 'warehouseThumbnail',
    reactiveSourceGetter: function() {
      return logics.warehouseManager.availableWarehouses;
    },
    wrapperClasses: 'detail-grid row'
  };
});

})();

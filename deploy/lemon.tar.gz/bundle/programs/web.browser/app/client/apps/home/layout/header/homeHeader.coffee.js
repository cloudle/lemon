(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineWidget(Template.homeHeader, {
  languages: function() {
    return i18n.languages;
  },
  created: function() {
    return Session.setDefault('loginValid', 'invalid');
  },
  rendered: function() {
    return $(this.find("#authAlias")).val($.cookie('lastAuthAlias'));
  },
  events: {
    "click .languages span": function() {
      return i18n.setLanguage(this.key);
    },
    "click .logo-text": function() {
      if (Meteor.userId() !== null) {
        return Router.go('/merchant');
      }
    }
  }
});

})();

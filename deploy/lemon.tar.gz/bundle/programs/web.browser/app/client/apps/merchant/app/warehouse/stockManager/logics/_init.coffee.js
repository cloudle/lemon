(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
logics.stockManager = {};

Apps.Merchant.stockManagerInit = [];

Apps.Merchant.stockManagerInit.push(function(scope) {
  return logics.stockManager.availableProducts = Schema.products.find({
    warehouse: Session.get('myProfile').currentWarehouse
  });
});

logics.stockManager.reactiveRun = function() {};

})();

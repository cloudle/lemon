(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var animateBackgroundColor, colors, currentIndex, incorrectPassword, registerErrors;

currentIndex = 0;

colors = ['#54c8eb', '#4ea9de', '#4b97d2', '#92cc8f', '#41bb98', '#c9de83', '#dee569', '#c891c0', '#9464a8', '#7755a1', '#f069a1', '#f05884', '#e7457b', '#ffd47e', '#f69078'];

registerErrors = [
  incorrectPassword = {
    reason: "Incorrect password",
    message: "tài khoản tồn tại"
  }
];

animateBackgroundColor = function() {
  $(".animated-bg").css("background-color", colors[currentIndex]);
  currentIndex++;
  if (currentIndex > colors.length) {
    return currentIndex = 0;
  }
};

lemon.defineWidget(Template.home, {
  registerValid: function() {
    var _ref;
    if ((Session.get('registerAccountValid') === (_ref = Session.get('registerSecretValid')) && _ref === 'valid')) {
      return 'valid';
    } else {
      return 'invalid';
    }
  },
  registerSecretValid: function() {
    return Session.get('registerSecretValid');
  },
  termButtonActive: function() {
    if (Session.get('topPanelMinimize')) {
      return '';
    } else {
      return 'reading';
    }
  },
  created: function() {
    if (!(Meteor.userId() === null || (Session.get('autoNatigateDashboardOff')))) {
      return Router.go('/merchant');
    }
  },
  rendered: function() {
    var self;
    self = this;
    return Meteor.setTimeout(function() {
      animateBackgroundColor();
      return self.bgInterval = Meteor.setInterval(animateBackgroundColor, 15000);
    }, 5000);
  },
  destroyed: function() {
    return Meteor.clearInterval(this.bgInterval);
  },
  events: {
    "click #authButton.valid": function(event, template) {
      return logics.homeHeader.login(event, template);
    },
    "click #gotoMerchantButton": function() {
      return Router.go('/merchant');
    },
    "click #logoutButton": function() {
      return lemon.logout();
    },
    "keypress .login-field": function(event, template) {
      if (event.which === 13 && Session.get('loginValid') === 'valid') {
        return $(template.find("#authButton")).click();
      }
    },
    "input .login-field": function(event, template) {
      var $login, $password;
      $login = $(template.find("#authAlias"));
      $password = $(template.find("#authSecret"));
      if ($login.val().length > 0 && $password.val().length > 0) {
        return Session.set('loginValid', 'valid');
      } else {
        return Session.set('loginValid', 'invalid');
      }
    },
    "click #terms": function() {
      return Session.set('topPanelMinimize', !Session.get('topPanelMinimize'));
    },
    "click #merchantRegister.valid": function(event, template) {
      var $account, $companyName, $companyPhone, $secret;
      $companyName = $(template.find("#companyName"));
      $companyPhone = $(template.find("#companyPhone"));
      $account = $(template.find("#account"));
      $secret = $(template.find("#secret"));
      return Meteor.call("registerMerchant", $account.val(), $secret.val(), $companyName.val(), $companyPhone.val(), function(error, result) {
        if (error) {
          return;
          console.log(error);
        }
        return Meteor.loginWithPassword($account.val(), $secret.val(), function(error) {
          if (!error) {
            return Router.go('/merchantWizard');
          }
        });
      });
    },
    "blur #account": function(event, template) {
      var $account;
      $account = $(template.find("#account"));
      if ($account.val().length > 0) {
        return Meteor.loginWithPassword($account.val(), '', function(error) {
          if ((error != null ? error.reason : void 0) === "Incorrect password") {
            $account.notify("tài khoản đã tồn tại", {
              position: "top"
            });
            return Session.set('registerAccountValid', 'invalid');
          } else {
            return Session.set('registerAccountValid', 'valid');
          }
        });
      } else {
        return Session.set('registerAccountValid', 'invalid');
      }
    },
    "keyup #secret": function(event, template) {
      var $secret, $secretConfirm;
      $secret = $(template.find("#secret"));
      $secretConfirm = $(template.find("#secretConfirm"));
      if ($secretConfirm.val().length > 0 || $secret.val().length > 0 || $secretConfirm.val() === $secret.val()) {
        return Session.set('registerSecretValid', 'invalid');
      } else {
        return Session.set('registerSecretValid', 'valid');
      }
    },
    "keyup .secret-field": function(event, template) {
      var $secret, $secretConfirm;
      $secret = $(template.find("#secret"));
      $secretConfirm = $(template.find("#secretConfirm"));
      if ($secret.val().length > 0 && $secretConfirm.val() === $secret.val()) {
        return Session.set('registerSecretValid', 'valid');
      } else {
        return Session.set('registerSecretValid', 'invalid');
      }
    }
  }
});

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var animateBackgroundColor, colors, currentIndex, finalAccountExtendPrice, finalBranchExtendPrice, finalWarehouseExtendPrice, incorrectPassword, registerErrors;

currentIndex = 0;

colors = ['#4b97d2', '#92cc8f', '#41bb98', '#c9de83', '#dee569', '#c891c0', '#9464a8', '#7755a1', '#f069a1', '#f05884', '#e7457b', '#ffd47e', '#f69078'];

registerErrors = [
  incorrectPassword = {
    reason: "Incorrect password",
    message: "tài khoản tồn tại"
  }
];

animateBackgroundColor = function() {
  $(".merchant-wizard-wrapper").css("background-color", colors[currentIndex]);
  currentIndex++;
  if (currentIndex > colors.length) {
    return currentIndex = 0;
  }
};

finalAccountExtendPrice = function() {
  var currentPackage;
  currentPackage = Session.get('currentMerchantPackage');
  return Session.get('wizardAccountPlus') * currentPackage.extendAccountPrice * currentPackage.years;
};

finalBranchExtendPrice = function() {
  var currentPackage;
  currentPackage = Session.get('currentMerchantPackage');
  return Session.get('wizardBranchPlus') * currentPackage.extendBranchPrice * currentPackage.years;
};

finalWarehouseExtendPrice = function() {
  var currentPackage;
  currentPackage = Session.get('currentMerchantPackage');
  return Session.get('wizardWarehousePlus') * currentPackage.extendWarehousePrice * currentPackage.years;
};

lemon.defineWidget(Template.merchantWizard, {
  accountExtendPrice: function() {
    var _ref;
    return (_ref = Session.get('currentMerchantPackage')) != null ? _ref.extendAccountPrice : void 0;
  },
  branchExtendPrice: function() {
    var _ref;
    return (_ref = Session.get('currentMerchantPackage')) != null ? _ref.extendBranchPrice : void 0;
  },
  warehouseExtendPrice: function() {
    var _ref;
    return (_ref = Session.get('currentMerchantPackage')) != null ? _ref.extendWarehousePrice : void 0;
  },
  packageYears: function() {
    var _ref;
    return (_ref = Session.get('currentMerchantPackage')) != null ? _ref.years : void 0;
  },
  packagePrice: function() {
    var _ref;
    return (_ref = Session.get('currentMerchantPackage')) != null ? _ref.price : void 0;
  },
  finalAccountExtendPrice: function() {
    return finalAccountExtendPrice();
  },
  finalBranchExtendPrice: function() {
    return finalBranchExtendPrice();
  },
  finalWarehouseExtendPrice: function() {
    return finalWarehouseExtendPrice();
  },
  crossFinalExtendPrice: function() {
    return finalAccountExtendPrice() + finalBranchExtendPrice() + finalWarehouseExtendPrice();
  },
  crossFinalPrice: function() {
    return Session.get('currentMerchantPackage').price + finalAccountExtendPrice() + finalBranchExtendPrice() + finalWarehouseExtendPrice();
  },
  rendered: function() {
    var self;
    self = this;
    return Meteor.setTimeout(function() {
      animateBackgroundColor();
      return self.bgInterval = Meteor.setInterval(animateBackgroundColor, 15000);
    }, 5000);
  },
  destroyed: function() {
    return Meteor.clearInterval(this.bgInterval);
  },
  events: {
    "click .package-block": function(event, template) {
      return Session.set('currentMerchantPackage', this.options);
    },
    "click .finish-register": function(event, template) {
      console.log(template.data.purchase);
      Schema.merchantPurchases.update(template.data.purchase._id, {
        $set: {
          merchantRegistered: true
        }
      });
      return Router.go('/merchant');
    },
    "click .register-logout.btn": function() {
      return lemon.logout();
    }
  }
});

})();

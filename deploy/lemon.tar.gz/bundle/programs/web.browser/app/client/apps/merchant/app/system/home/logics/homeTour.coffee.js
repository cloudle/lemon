(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var tourSteps;

tourSteps = [
  {
    element: ".tour-toggle",
    placement: "bottom",
    title: "<b>C</b>hào mừng Bạn đến với hệ thống <b>EDS!</b>",
    content: "<b>Đ</b>ây là chức năng hướng dẫn sử dụng, sau lần đăng nhập đầu tiên thông báo này sẽ không tự động hiển thị nữa.<br/><br/> <b>T</b>rong khi sử dụng, Bạn có thể xem lại hướng dẫn bằng cách chọn vào biểu tượng phía trên.<br/><br/> <b>N</b>hững bước hướng dẫn cần thiết này sẽ giúp bạn trải nghiệm hệ thống một cách dễ dàng và chuyên nghiệp hơn<b/>."
  }, {
    element: "[data-app='branchManager']",
    placement: "left",
    title: "<b>Bước 1:</b> Tạo mới Chi nhánh",
    content: "<b>C</b>hức năng này hỗ trợ khởi tạo danh sách chi nhánh trong hệ thống doanh nghiệp của Bạn.<br/><br/> <i>(Bỏ qua bước này nếu Bạn chưa có hệ thống chi nhánh)</i>"
  }, {
    element: "[data-app='warehouseManager']",
    placement: "left",
    title: "<b>Bước 2:</b> Tạo mới Kho hàng",
    content: "<b>C</b>hức năng này hỗ trợ khởi tạo thêm <b>kho hàng</b> cho chi nhánh.<br/><br/> <i>(Bỏ qua bước này nếu Bạn chưa cần lưu trữ hàng hóa trong nhiều kho)</i>"
  }, {
    element: "[data-app='staffManager']",
    title: "<b>Bước 3:</b> Tạo danh sách Nhân viên",
    content: "<b>Đ</b>ây là chức năng <b>quản lý nhân viên</b>, Bạn sẽ <b>tạo mới tài khoản</b> truy cập và <b>xác định quyền hạn</b> cho từng nhân viên.<br/><br/> <b>EDS</b> đã hỗ trợ sẵn những chức danh và quyền hạn cụ thể cho từng vị trí nhân viên. Bên cạnh đó, Bạn <b>có thể tạo mới hay tùy chỉnh</b> từng chức danh theo tính đặc thù trong doanh nghiệp của Bạn."
  }, {
    element: "[data-app='customerManager']",
    title: "<b>Bước 4:</b> Tạo danh sách Khách hàng",
    content: "<b>C</b>hức năng này hỗ trợ khởi tạo <b>danh sách khách hàng</b>. Hệ thống sẽ <b>ghi nhận và nhắc nhở bạn</b> những sự kiện liên quan đến khách hàng (<b>sinh nhật, công nợ, biến động</b> trong tình hình mua hàng qua các thời kỳ …)<br/><br/> <b>B</b>ạn cũng có thể tạo mới khách hàng trong chức năng <b>Bán hàng</b>."
  }, {
    element: "[data-app='importHistory']",
    placement: "bottom",
    title: "<b>Bước 5:</b> Nhập kho",
    content: "<b>B</b>ạn có thể thêm <b>sản phẩm, giá nhập, giá bán, nhà cung cấp</b>… và xem lại danh sách các đợt nhập kho trước đó.<br/><br/> <b>S</b>au khi hoàn thành bước này thì Bạn đã có thể bán hàng.<br/><br/> <b>Từ đây, mọi thứ đã được thiết lập tự động.</b>"
  }, {
    element: "[data-app='transactionManager']",
    placement: "top",
    title: "<b>Bước 6</b>*: Danh sách nợ cũ",
    content: "<b>B</b>ạn có thể dừng lại tại <b>Bước 5</b>. Tuy nhiên, bước này sẽ giúp Bạn không phải đau đầu vì sổ sách nữa.<br/><br/> <b>B</b>ạn có thể chuyển công nợ trước đó vào hệ thống, <b>EDS</b> sẽ <b>theo dõi và tự động nhắc nhở</b> Bạn các khoản nợ phải thu, phải trả, quá hạn...<br/><br/> <b>Chúc bạn có những trải nghiệm thú vị!</b>"
  }
];

Apps.Merchant.homeRerun.push(function(scope) {
  scope.homeTour = new Tour({
    steps: tourSteps,
    container: "body",
    backdrop: true
  });
  return Apps.currentTour = scope.homeTour;
});

})();

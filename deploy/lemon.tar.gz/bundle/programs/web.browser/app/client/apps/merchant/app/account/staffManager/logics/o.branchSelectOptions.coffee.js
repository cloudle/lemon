(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var formatBranchSelect;

formatBranchSelect = function(item) {
  if (item) {
    return "" + item.name;
  }
};

Apps.Merchant.staffManagerInit.push(function(scope) {
  return logics.staffManager.branchSelectOptions = {
    query: function(query) {
      return query.callback({
        results: Schema.merchants.find().fetch()
      });
    },
    initSelection: function(element, callback) {
      var _ref;
      return callback((_ref = Schema.merchants.findOne(Session.get('mySession').createStaffBranchSelection)) != null ? _ref : 'skyReset');
    },
    reactiveValueGetter: function() {
      var _ref;
      return (_ref = Session.get('mySession').createStaffBranchSelection) != null ? _ref : 'skyReset';
    },
    changeAction: function(e) {
      var option, _ref, _ref1;
      option = {
        createStaffBranchSelection: e.added._id,
        createStaffWarehouseSelection: (_ref = (_ref1 = Schema.warehouses.findOne({
          merchant: e.added._id,
          isRoot: true
        })) != null ? _ref1._id : void 0) != null ? _ref : 'skyReset'
      };
      Schema.userSessions.update(Session.get('mySession')._id, {
        $set: option
      });
      return scope.availableWarehouses = Schema.warehouses.find({
        merchant: e.added._id
      });
    },
    minimumResultsForSearch: -1,
    formatSelection: formatBranchSelect,
    formatResult: formatBranchSelect
  };
});

})();

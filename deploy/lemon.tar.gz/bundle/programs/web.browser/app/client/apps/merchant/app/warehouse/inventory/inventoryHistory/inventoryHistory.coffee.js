(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineApp(Template.inventoryHistory, {
  rendered: function() {
    $("[name=fromDate]").datepicker('setDate', Session.get('inventoryHistoryFilterStartDate'));
    return $("[name=toDate]").datepicker('setDate', Session.get('inventoryHistoryFilterToDate'));
  },
  events: {
    "click .createInventory": function(event, template) {
      return Router.go('/inventory');
    },
    "click #filterInventoryHistories": function(event, template) {
      Session.set('inventoryHistoryFilterStartDate', $("[name=fromDate]").datepicker().data().datepicker.dates[0]);
      return Session.set('inventoryHistoryFilterToDate', $("[name=toDate]").datepicker().data().datepicker.dates[0]);
    },
    "click .thumbnails": function(event, template) {
      Meteor.subscribe('productLostInInventory', this._id);
      Meteor.subscribe('inventoryDetailInWarehouse', this._id);
      Session.set('currentInventoryHistory', this);
      return $(template.find('#inventoryHistoryDetail')).modal();
    }
  }
});

})();

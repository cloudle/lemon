(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Apps.Merchant.inventoryManagerInit.push(function(scope) {
  return logics.inventoryManager.gridOptions = {
    itemTemplate: 'inventoryProductThumbnail',
    reactiveSourceGetter: function() {
      return logics.inventoryManager.inventoryDetails;
    },
    wrapperClasses: 'detail-grid row'
  };
});

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
logics.returns.addReturnDetail = function(saleId) {
  var findReturnDetail, returnDetail, returnDetails, returns, sale, saleDetail;
  if (!(sale = Schema.sales.findOne({
    _id: saleId
  }))) {
    return console.log('Phiếu bán hàng không tồn tại');
  }
  if (!sale.currentProductDetail) {
    return console.log("Chưa chọn sản phẩm trả hàng");
  }
  if (!(saleDetail = Schema.saleDetails.findOne({
    _id: sale.currentProductDetail
  }))) {
    return console.log("Sản phẩm trả hàng không tồn tại");
  }
  if (!sale.currentQuality || sale.currentQuality < 1) {
    return console.log("Số lượng sản phẩm phải lớn hơn 0");
  }
  if (sale.returnCount > 3) {
    return console.log("Số lần trả vượt quá 3 lần, không thể trả tiếp.");
  }
  if (returns = Schema.returns.findOne({
    _id: sale.currentReturn
  })) {
    if (returns.status === 1) {
      return console.log("Phiếu đang chờ duyệt, không thể thêm sản phẩm.");
    }
    if (returns.status === 2) {
      returns = Return.createBySale(saleId);
    }
  } else {
    returns = Return.createBySale(saleId);
  }
  if (!returns) {
    return console.log("Không thể tạo phiếu trả hàng.");
  }
  returnDetail = ReturnDetail.newByReturn(returns._id, saleId);
  returnDetails = Schema.returnDetails.find({
    "return": returns._id
  }).fetch();
  findReturnDetail = _.findWhere(returnDetails, {
    productDetail: returnDetail.productDetail,
    price: returnDetail.price,
    discountPercent: returnDetail.discountPercent
  });
  if (findReturnDetail) {
    if (saleDetail.quality < (findReturnDetail.returnQuality + returnDetail.returnQuality)) {
      return console.log('Vuot Qua SL Hang Co');
    }
    return Schema.returnDetails.update(findReturnDetail._id, {
      $inc: {
        returnQuality: returnDetail.returnQuality,
        discountCash: returnDetail.discountCash,
        finalPrice: returnDetail.finalPrice
      }
    });
  } else {
    if (saleDetail.quality < returnDetail.returnQuality) {
      return console.log('Vuot Qua SL Hang Co');
    }
    Schema.returnDetails.insert(returnDetail);
    return logics.returns.reCalculateReturn(returns._id);
  }
};

})();

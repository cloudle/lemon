(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineApp(Template.importHistory, {
  rendered: function() {
    logics.importHistory.templateInstance = this;
    $("[name=fromDate]").datepicker('setDate', Session.get('importHistoryFilterStartDate'));
    return $("[name=toDate]").datepicker('setDate', Session.get('importHistoryFilterToDate'));
  },
  events: {
    "click .createImport": function(event, template) {
      return Router.go('/import');
    },
    "change [name='advancedMode']": function(event, template) {
      return logics.importHistory.templateInstance.ui.extras.toggleExtra('advanced', event.target.checked);
    },
    "click #filterImportHistories": function(event, template) {
      Session.set('importHistoryFilterStartDate', $("[name=fromDate]").datepicker().data().datepicker.dates[0]);
      return Session.set('importHistoryFilterToDate', $("[name=toDate]").datepicker().data().datepicker.dates[0]);
    },
    "click .thumbnails:not(.full-desc.trash)": function(event, template) {
      Meteor.subscribe('importDetailInWarehouse', this._id);
      Session.set('currentImportHistory', this);
      return $(template.find('#importHistoryDetail')).modal();
    }
  }
});

})();

(function(){
Template.__define__("merchantPriceTable", (function() {
  var view = this;
  return HTML.DIV({
    "class": function() {
      return [ "package-block", " ", Spacebars.mustache(Spacebars.dot(view.lookup("options"), "packageClass")) ];
    }
  }, HTML.DIV({
    "class": "title"
  }, Blaze.View(function() {
    return Spacebars.mustache(Spacebars.dot(view.lookup("options"), "title"));
  })), "\n", HTML.DIV({
    "class": "content"
  }, Blaze.If(function() {
    return Spacebars.call(view.lookup("isActive"));
  }, function() {
    return HTML.I({
      "class": [ "active-icon", " ", "animated", " ", "bounceIn", " ", "icon-award" ]
    });
  }), "\n", HTML.P({
    "class": "price"
  }, HTML.Raw("<sup>VNĐ</sup>"), "\n", HTML.SPAN(Blaze.View(function() {
    return Spacebars.mustache(Spacebars.dot(view.lookup("options"), "titlePrice"));
  })), "\n", HTML.SUB("/", Blaze.View(function() {
    return Spacebars.mustache(Spacebars.dot(view.lookup("options"), "titleDuration"));
  }), ".")), "\n", HTML.P({
    "class": "hint"
  }, Blaze.View(function() {
    return Spacebars.mustache(Spacebars.dot(view.lookup("options"), "hint"));
  }))), "\n", HTML.DIV({
    "class": "features"
  }, HTML.LI({
    "class": "icon-group"
  }, HTML.SPAN({
    "class": "quality"
  }, Blaze.View(function() {
    return Spacebars.mustache(Spacebars.dot(view.lookup("options"), "accountLim"));
  })), "\n", Blaze.If(function() {
    return Spacebars.call(view.lookup("showAccountPlus"));
  }, function() {
    return HTML.SUP("+", Blaze.View(function() {
      return Spacebars.mustache(view.lookup("accountPlus"));
    }));
  }), "\n", HTML.Raw("<span>Tài khoản</span>"), "\n", Blaze.If(function() {
    return Spacebars.call(view.lookup("showExtension"));
  }, function() {
    return [ HTML.DIV({
      "class": [ "command", " ", "lower", " ", "icon-left-open-4", " ", "account", " ", "animated", " ", "bounceIn" ]
    }), "\n", HTML.DIV({
      "class": [ "command", " ", "raise", " ", "icon-right-open-4", " ", "account", " ", "animated", " ", "bounceIn" ]
    }) ];
  })), "\n", HTML.LI({
    "class": "icon-location-1"
  }, HTML.SPAN({
    "class": "quality"
  }, Blaze.View(function() {
    return Spacebars.mustache(Spacebars.dot(view.lookup("options"), "branchLim"));
  })), "\n", Blaze.If(function() {
    return Spacebars.call(view.lookup("showBranchPlus"));
  }, function() {
    return HTML.SUP("+", Blaze.View(function() {
      return Spacebars.mustache(view.lookup("branchPlus"));
    }));
  }), "\n", HTML.Raw("<span>Chi nhánh</span>"), "\n", Blaze.If(function() {
    return Spacebars.call(view.lookup("showExtension"));
  }, function() {
    return [ HTML.DIV({
      "class": [ "command", " ", "lower", " ", "icon-left-open-4", " ", "branch", " ", "animated", " ", "bounceIn" ]
    }), "\n", HTML.DIV({
      "class": [ "command", " ", "raise", " ", "icon-right-open-4", " ", "branch", " ", "animated", " ", "bounceIn" ]
    }) ];
  })), "\n", HTML.LI({
    "class": "icon-home-4"
  }, HTML.SPAN({
    "class": "quality"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("realWarehouseLim"));
  })), "\n", Blaze.If(function() {
    return Spacebars.call(view.lookup("showWarehousePlus"));
  }, function() {
    return HTML.SUP("+", Blaze.View(function() {
      return Spacebars.mustache(view.lookup("warehousePlus"));
    }));
  }), "\n", HTML.Raw("<span>Kho hàng</span>"), "\n", Blaze.If(function() {
    return Spacebars.call(view.lookup("showExtension"));
  }, function() {
    return [ HTML.DIV({
      "class": [ "command", " ", "lower", " ", "icon-left-open-4", " ", "warehouse", " ", "animated", " ", "bounceIn" ]
    }), "\n", HTML.DIV({
      "class": [ "command", " ", "raise", " ", "icon-right-open-4", " ", "warehouse", " ", "animated", " ", "bounceIn" ]
    }) ];
  })), "\n", HTML.Raw("<!--if showExtension-->"), "\n", HTML.Raw("<!--  li.icon-group-->"), "\n", HTML.Raw("<!--    +iSpinEdit(options=accountLimitOptions) Tài khoản/{{options.extendAccountPrice}} vnd-->"), "\n", HTML.Raw("<!--  li.icon-location-1-->"), "\n", HTML.Raw("<!--    +iSpinEdit(options=branchLimitOptions) Chi nhánh/{{options.extendBranchPrice}} vnd-->"), "\n", HTML.Raw("<!--  li.icon-home-4-->"), "\n", HTML.Raw("<!--\n//+merchantPriceTableExtension\n-->")), "\n", HTML.DIV({
    "class": "footer"
  }, Blaze.If(function() {
    return Spacebars.call(view.lookup("showExtension"));
  }, function() {
    return HTML.SPAN(Blaze.View(function() {
      return Spacebars.mustache(view.lookup("extendPrice"));
    }));
  }), "\n", HTML.SPAN(Blaze.View(function() {
    return Spacebars.mustache(Spacebars.dot(view.lookup("options"), "footer"));
  }))));
}));

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Apps.Merchant.transactionManagerInit.push(function(scope) {
  return logics.transactionManager.gridOptions = {
    itemTemplate: 'transactionThumbnail',
    reactiveSourceGetter: function() {
      return logics.transactionManager.transactionDetailFilter;
    },
    wrapperClasses: 'detail-grid row'
  };
});

})();

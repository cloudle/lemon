(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
logics.inventoryManager.successInventory = function(warehouseId) {
  var detail, error, inventory, option, temp, updateInventory, updateProduct, userProfile, warehouse, _i, _j, _len, _len1, _ref, _ref1;
  try {
    if (!(userProfile = Schema.userProfiles.findOne({
      user: Meteor.userId()
    }))) {
      throw 'Bạn chưa đăng nhập.';
    }
    if (!(warehouse = Schema.warehouses.findOne({
      _id: warehouseId
    }))) {
      throw 'Kho không tồn tại';
    }
    if (!(inventory = Schema.inventories.findOne({
      _id: warehouse.inventory
    }))) {
      throw 'Inventory khong ton tai';
    }
    _ref = Schema.inventoryDetails.find({
      inventory: inventory._id
    }).fetch();
    for (_i = 0, _len = _ref.length; _i < _len; _i++) {
      detail = _ref[_i];
      if (detail.lock === false || detail.submit === false) {
        throw 'Lỗi, Chưa Submitted hết các sp';
      }
    }
    temp = false;
    _ref1 = Schema.inventoryDetails.find({
      inventory: inventory._id
    }).fetch();
    for (_j = 0, _len1 = _ref1.length; _j < _len1; _j++) {
      detail = _ref1[_j];
      console.log('buoc 1');
      option = {
        realQuality: detail.realQuality - detail.saleQuality,
        saleQuality: 0,
        success: true,
        successDate: new Date,
        status: true
      };
      if (detail.lostQuality > 0) {
        temp = true;
        option.status = false;
        updateProduct = {
          inStockQuality: -detail.lostQuality,
          availableQuality: -detail.lostQuality
        };
        console.log('buoc 2');
        Schema.productLosts.insert(ProductLost["new"](warehouse, detail));
        Schema.products.update(detail.product, {
          $inc: updateProduct
        }, function(error, result) {
          if (error) {
            return console.log(error);
          }
        });
        Schema.productDetails.update(detail.productDetail, {
          $inc: updateProduct
        }, function(error, result) {
          if (error) {
            return console.log(error);
          }
        });
      }
      Schema.inventoryDetails.update(detail._id, {
        $set: option
      }, function(error, result) {
        if (error) {
          return console.log(error);
        }
      });
    }
    console.log('buoc 3');
    updateInventory = {
      submit: true,
      success: true
    };
    if (temp) {
      updateInventory.success = false;
      MetroSummary.updateMetroSummaryByInventory(inventory._id);
    }
    console.log('buoc 4');
    Schema.inventories.update(inventory._id, {
      $set: updateInventory
    });
    Schema.warehouses.update(warehouseId, {
      $set: {
        checkingInventory: false
      },
      $unset: {
        inventory: ""
      }
    });
    return console.log('Đã Xác Nhận Kiểm Kho.');
  } catch (_error) {
    error = _error;
    return error;
  }
};

})();

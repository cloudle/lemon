(function(){
Template.__define__("messenger", (function() {
  var view = this;
  return HTML.Raw('<div id="messenger"><div class="conversation-wrapper"><span>conversations</span></div>\n<div class="input-wrapper"><input type="text" placeholder="trò chuyện..."></div>\n<div class="search-wrapper"></div></div>');
}));

})();

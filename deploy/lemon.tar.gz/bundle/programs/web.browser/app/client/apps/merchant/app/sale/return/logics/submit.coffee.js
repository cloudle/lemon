(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
logics.returns.submitReturn = function(returnId) {
  return zone.run((function(_this) {
    return function() {
      var currentReturn, error, option, returnDetail, returnQuality, saleDetail, transaction, transactionDetail, unLockReturn, userProfile, _i, _len, _ref;
      try {
        if (!(userProfile = Schema.userProfiles.findOne({
          user: Meteor.userId()
        }))) {
          throw 'Lỗi, Bạn chưa đăng nhập.';
        }
        if (!(currentReturn = Schema.returns.findOne({
          _id: returnId,
          creator: userProfile.user
        }))) {
          throw 'Lỗi, Phiếu trả không chính xác.';
        }
        if (currentReturn.status === 1) {
          returnQuality = 0;
          _ref = Schema.returnDetails.find({
            "return": currentReturn._id,
            submit: true
          }).fetch();
          for (_i = 0, _len = _ref.length; _i < _len; _i++) {
            returnDetail = _ref[_i];
            returnQuality = returnDetail.returnQuality;
            option = {
              availableQuality: returnDetail.returnQuality,
              inStockQuality: returnDetail.returnQuality
            };
            Schema.productDetails.update(returnDetail.productDetail, {
              $inc: option
            });
            Schema.products.update(returnDetail.product, {
              $inc: option
            });
            Schema.saleDetails.update(returnDetail.saleDetail, {
              $inc: {
                returnQuality: returnDetail.returnQuality
              }
            });
            saleDetail = Schema.saleDetails.findOne(returnDetail.saleDetail);
            if (saleDetail.quality !== saleDetail.returnQuality) {
              unLockReturn = true;
            }
          }
          Schema.returns.update(currentReturn._id, {
            $set: {
              status: 2
            }
          });
          Schema.sales.update(currentReturn.sale, {
            $set: {
              status: true,
              "return": true,
              returnLock: !unLockReturn
            },
            $inc: {
              returnCount: 1,
              returnQuality: returnQuality
            }
          });
          transaction = Transaction.newByReturn(currentReturn);
          transactionDetail = TransactionDetail.newByTransaction(transaction);
          MetroSummary.updateMetroSummaryByReturn(currentReturn._id, returnQuality);
          throw 'Ok, Phiếu đã được duyệt bởi quản lý.';
        }
        if (currentReturn.status === 0) {
          throw 'Lỗi, Phiếu chưa được xác nhận từ nhân viên.';
        }
        if (currentReturn.status === 2) {
          throw 'Lỗi, Phiếu đã được duyệt, không thể thao tác.';
        }
      } catch (_error) {
        error = _error;
        return console.log(error);
      }
    };
  })(this));
};

})();

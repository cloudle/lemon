(function(){
Template.__define__("merchantHome", (function() {
  var view = this;
  return HTML.DIV({
    "class": "metro"
  }, HTML.DIV({
    "class": "metro-wrapper"
  }, HTML.DIV({
    "class": "tile-group-1"
  }, HTML.DIV({
    "class": function() {
      return [ "tile", " ", "belize-hole", " ", Spacebars.mustache(view.lookup("metroUnLocker"), Spacebars.dot(view.lookup("Summary"), "data", "merchantCount")) ];
    },
    "data-app": "tracker"
  }, HTML.Raw('<span class="center middle caption"><span class="table"><i class="ico icon-book"></i></span></span>'), "\n", HTML.Raw('<span class="bottom middle caption">NHẬT KÝ</span>')), "\n", HTML.DIV({
    "class": function() {
      return [ "tile", " ", "carrot", " ", Spacebars.mustache(view.lookup("metroUnLocker"), Spacebars.dot(view.lookup("Summary"), "data", "staffCount")) ];
    },
    "data-app": "staffManager"
  }, HTML.Raw('<span class="s7 top middle caption">TÀI KHOẢN</span>'), "\n", HTML.Raw('<span class="center middle caption"><span class="table"><i class="ico icon-group"></i></span></span>'), "\n", HTML.SPAN({
    "class": [ "bottom", " ", "middle", " ", "caption" ]
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("formatNumber"), Spacebars.dot(view.lookup("Summary"), "data", "staffCountAll"));
  }), HTML.Raw("<br>"), "NHÂN SỰ")), "\n", HTML.DIV({
    "class": function() {
      return [ "tile", " ", "amethyst", " ", Spacebars.mustache(view.lookup("metroUnLocker"), Spacebars.dot(view.lookup("Summary"), "data", "staffCount")) ];
    },
    "data-app": "customerManager"
  }, HTML.Raw('<span class="s7 top middle caption">HỒ SƠ MACKAY</span>'), "\n", HTML.Raw('<span class="center middle caption"><span class="table"><i class="ico icon-heart-8"></i></span></span>'), "\n", HTML.SPAN({
    "class": [ "bottom", " ", "middle", " ", "caption" ]
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("formatNumber"), Spacebars.dot(view.lookup("Summary"), "data", "customerCountAll"));
  }), HTML.Raw("<br>"), "KHÁCH HÀNG")), "\n", HTML.DIV({
    "class": function() {
      return [ "tile", " ", "belize-hole", " ", Spacebars.mustache(view.lookup("metroUnLocker"), Spacebars.dot(view.lookup("Summary"), "data", "merchantCount")) ];
    },
    "data-app": "branchManager"
  }, HTML.Raw('<span class="center middle caption"><span class="table"><i class="ico icon-home-6"></i>\n<i class="ico small icon-home-6"></i></span></span>'), "\n", HTML.SPAN({
    "class": [ "bottom", " ", "middle", " ", "caption" ]
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("formatNumber"), Spacebars.dot(view.lookup("Summary"), "data", "merchantCount"));
  }), HTML.Raw("<br>"), "CHI NHÁNH"))), "\n", HTML.DIV({
    "class": "tile-group-3"
  }, HTML.DIV({
    "class": function() {
      return [ "tile", " ", "quatro", " ", "lime", " ", Spacebars.mustache(view.lookup("metroUnLocker"), Spacebars.dot(view.lookup("Summary"), "data", "importCount")) ];
    },
    id: "saleManager",
    "data-app": "sales"
  }, HTML.Raw('<span class="top right caption">BÁN HÀNG</span>'), "\n", HTML.Raw('<span class="center middle caption"><span class="table"><i class="ico huge icon-basket-3"></i></span></span>'), "\n", HTML.SPAN({
    "class": [ "bottom", " ", "left", " ", "caption" ]
  }, HTML.H3(Blaze.View(function() {
    return Spacebars.mustache(view.lookup("formatNumber"), Spacebars.dot(view.lookup("Summary"), "data", "saleProductCount"));
  }), " ", HTML.getTag("tiny5")("SẢN PHẨM ĐÃ BÁN")))), "\n", HTML.DIV({
    "class": function() {
      return [ "tile", " ", "teal", " ", Spacebars.mustache(view.lookup("metroUnLocker"), Spacebars.dot(view.lookup("Summary"), "data", "saleCount")) ];
    },
    "data-app": "billManager"
  }, HTML.Raw('<span class="center middle caption"><span class="table"><i class="ico icon-clipboard-2"></i></span></span>'), "\n", HTML.SPAN({
    "class": [ "bottom", " ", "middle", " ", "caption" ]
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("formatNumber"), Spacebars.dot(view.lookup("Summary"), "data", "saleCount"));
  }), " ĐƠN HÀNG")), "\n", HTML.DIV({
    "class": function() {
      return [ "tile", " ", "amethyst", " ", Spacebars.mustache(view.lookup("metroUnLocker"), Spacebars.dot(view.lookup("Summary"), "data", "deliveryCount")) ];
    },
    "data-app": "deliveryManager"
  }, HTML.Raw('<span class="center middle caption"><span class="table"><i class="ico icon-truck-1"></i></span></span>'), "\n", HTML.SPAN({
    "class": [ "bottom", " ", "middle", " ", "caption" ]
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("formatNumber"), Spacebars.dot(view.lookup("Summary"), "data", "deliveryCount"));
  }), " GIAO HÀNG")), "\n", HTML.DIV({
    "class": function() {
      return [ "tile", " ", "double", " ", "dark-blue", " ", Spacebars.mustache(view.lookup("metroUnLocker"), Spacebars.dot(view.lookup("Summary"), "data", "importCount")) ];
    },
    "data-app": "transactionManager"
  }, HTML.SPAN({
    "class": [ "top", " ", "left", " ", "caption" ]
  }, HTML.H3(Blaze.View(function() {
    return Spacebars.mustache(view.lookup("formatNumber"), Spacebars.dot(view.lookup("Summary"), "data", "saleDebitCash"));
  }), " ", HTML.getTag("tiny5")("PHẢI THU"))), "\n", HTML.Raw('<span class="center left caption"><span class="table"><i class="ico icon-money"></i></span></span>'), "\n", HTML.Raw('<span class="bottom left caption">CÔNG NỢ</span>')), "\n", HTML.DIV({
    "class": function() {
      return [ "tile", " ", "alizarin", " ", Spacebars.mustache(view.lookup("metroUnLocker"), Spacebars.dot(view.lookup("Summary"), "data", "saleCount")) ];
    },
    "data-app": "returns"
  }, HTML.Raw('<span class="center middle caption"><span class="table"><i class="ico icon-reply-all-1"></i></span></span>'), "\n", HTML.SPAN({
    "class": [ "bottom", " ", "middle", " ", "caption" ]
  }, " ", Blaze.View(function() {
    return Spacebars.mustache(view.lookup("formatNumber"), Spacebars.dot(view.lookup("Summary"), "data", "returnCount"));
  }), " TRẢ HÀNG")), "\n", HTML.DIV({
    "class": function() {
      return [ "tile", " ", "lime", " ", Spacebars.mustache(view.lookup("metroUnLocker"), Spacebars.dot(view.lookup("Summary"), "data", "warehouseCount")) ];
    },
    "data-app": "warehouseManager"
  }, HTML.Raw('<span class="center middle caption"><span class="table"><i class="ico icon-home-4"></i></span></span>'), "\n", HTML.SPAN({
    "class": [ "bottom", " ", "middle", " ", "caption" ]
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("formatNumber"), Spacebars.dot(view.lookup("Summary"), "data", "warehouseCount"));
  }), HTML.Raw("<br>"), "KHO HÀNG")), "\n", HTML.DIV({
    "class": function() {
      return [ "tile", " ", "wisteria", " ", Spacebars.mustache(view.lookup("metroUnLocker"), Spacebars.dot(view.lookup("Summary"), "data", "staffCount")) ];
    },
    "data-app": "roleManager"
  }, HTML.Raw('<span class="center middle caption"><span class="table"><i class="ico icon-user-add-1"></i></span></span>'), "\n", HTML.Raw('<span class="bottom middle caption">PHÂN QUYỀN</span>'))), "\n", HTML.DIV({
    "class": "tile-group-3"
  }, HTML.DIV({
    "class": function() {
      return [ "tile", " ", "carrot", " ", "double", " ", "double-vertical", " ", Spacebars.mustache(view.lookup("metroUnLocker"), Spacebars.dot(view.lookup("Summary"), "data", "warehouseCount")) ];
    },
    "data-app": "importHistory"
  }, HTML.Raw('<span class="center left caption"><span class="table"><i class="ico icon-inbox-1"></i></span></span>'), "\n", HTML.SPAN({
    "class": [ "bottom", " ", "left", " ", "caption" ]
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("formatNumber"), Spacebars.dot(view.lookup("Summary"), "data", "importCount"));
  }), " NHẬP KHO"), "\n", HTML.SPAN({
    "class": [ "top", " ", "left", " ", "caption" ]
  }, HTML.H3(HTML.getTag("tiny5")("TỔNG NHẬP ", Blaze.View(function() {
    return Spacebars.mustache(Spacebars.dot(view.lookup("Summary"), "data", "importProductCount"));
  })))), "\n", HTML.SPAN({
    "class": [ "bottom", " ", "right", " ", "caption" ]
  }, HTML.H3(Blaze.View(function() {
    return Spacebars.mustache(Spacebars.dot(view.lookup("Summary"), "data", "stockProductCount"));
  }), HTML.Raw("<br>"), " ", HTML.getTag("tiny5")("TỒN KHO")))), "\n", HTML.DIV({
    "class": function() {
      return [ "tile", " ", "sun-flower", " ", Spacebars.mustache(view.lookup("metroUnLocker"), Spacebars.dot(view.lookup("Summary"), "data", "importCount")) ];
    },
    "data-app": "stockManager"
  }, HTML.Raw('<span class="s7 top middle caption">ĐIỀU CHỈNH GIÁ BÁN</span>'), "\n", HTML.Raw('<span class="center middle caption"><span class="table"><i class="ico icon-align-justify-1"></i></span></span>'), "\n", HTML.Raw('<span class="bottom middle caption">TỒN KHO</span>')), "\n", HTML.DIV({
    "class": function() {
      return [ "tile", " ", "double", " ", "peter-river", " ", Spacebars.mustache(view.lookup("metroUnLocker"), Spacebars.dot(view.lookup("Summary"), "data", "saleCount")) ];
    },
    "data-app": "salesReport"
  }, HTML.Raw('<span class="center left caption"><span class="table"><i class="ico large icon-chart-bar-4"></i></span></span>'), "\n", HTML.Raw('<span class="bottom left caption">BÁO CÁO DOANH SỐ</span>')), "\n", HTML.DIV({
    "class": function() {
      return [ "tile", " ", "alizarin", " ", Spacebars.mustache(view.lookup("metroUnLocker"), Spacebars.dot(view.lookup("Summary"), "data", "saleCount")) ];
    },
    "data-app": "export"
  }, HTML.Raw('<span class="center middle caption"><span class="table"><i class="ico icon-shuffle-4"></i></span></span>'), "\n", HTML.Raw('<span class="bottom middle caption">CHUYỂN KHO</span>')), "\n", HTML.DIV({
    "class": function() {
      return [ "tile", " ", "orange", " ", Spacebars.mustache(view.lookup("metroUnLocker"), Spacebars.dot(view.lookup("Summary"), "data", "importCount")) ];
    },
    "data-app": "accountingManager"
  }, HTML.Raw('<span class="top right caption"><i class="ico small icon-ok-6"></i></span>'), "\n", HTML.Raw('<span class="center middle caption"><span class="table"><i class="ico icon-money"></i></span></span>'), "\n", HTML.Raw('<span class="bottom middle caption"><span class="s7">XÁC NHẬN</span><br> THU TIỀN</span>')), "\n", HTML.DIV({
    "class": function() {
      return [ "tile", " ", "green-sea", " ", Spacebars.mustache(view.lookup("metroUnLocker"), Spacebars.dot(view.lookup("Summary"), "data", "importCount")) ];
    },
    "data-app": "exportAndImportManager"
  }, HTML.Raw('<span class="top right caption"><i class="ico small icon-ok-6"></i></span>'), "\n", HTML.Raw('<span class="center middle caption"><span class="table"><i class="ico icon-shareable"></i></span></span>'), "\n", HTML.Raw('<span class="bottom middle caption"><span class="s7">XÁC NHẬN</span><br> XUẤT NHẬP KHO</span>')), "\n", HTML.DIV({
    "class": function() {
      return [ "tile", " ", "dark", " ", Spacebars.mustache(view.lookup("metroUnLocker"), Spacebars.dot(view.lookup("Summary"), "data", "importCount")) ];
    },
    "data-app": "inventoryHistory"
  }, HTML.Raw('<span class="center middle caption"><span class="table"><i class="ico icon-edit-alt"></i></span></span>'), "\n", HTML.SPAN({
    "class": [ "bottom", " ", "middle", " ", "caption" ]
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("formatNumber"), Spacebars.dot(view.lookup("Summary"), "data", "inventoryCount"));
  }), HTML.Raw("<br>"), "KIỂM KHO")))));
}));

})();

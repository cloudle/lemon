(function(){
Template.__define__("deliveryManagerThumbnailHeader1", (function() {
  var view = this;
  return HTML.Raw('<span class="title">CHỜ GIAO</span><span class="icon icon-shareable"></span>');
}));

Template.__define__("deliveryManagerThumbnailHeader2", (function() {
  var view = this;
  return HTML.Raw('<span class="title">ĐANG GIAO</span><span class="icon icon-truck-1"></span>');
}));

Template.__define__("deliveryManagerThumbnailHeader3", (function() {
  var view = this;
  return HTML.Raw('<span class="title">ĐÃ KẾT THÚC</span><span class="icon icon-award"></span>');
}));

Template.__define__("deliveryManager", (function() {
  var view = this;
  return [ HTML.Raw('<div id="header"><div class="caption-row"><div class="title">Giao Hàng</div></div>\n<!--.editor-row-->\n<!--  .editor-wrapper(style="width: 200px")-->\n<!--    span.ilabel chi nhánh-->\n<!--    +iSelect(options=merchantSelectOptions class="field")-->\n<!--  .editor-wrapper(style="width: 200px")-->\n<!--    span.ilabel kho-->\n<!--    +iSelect(options=warehouseSelectOptions class="field")-->\n</div>'), HTML.DIV({
    id: "content"
  }, HTML.DIV({
    "class": [ "segments-container", " ", "size3" ]
  }, Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("waitingGridOptions")),
      wrapperClass: Spacebars.call("segments-column"),
      headerTemplate: Spacebars.call("deliveryManagerThumbnailHeader1"),
      animation: Spacebars.call("bounceInDown")
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("gridComponent"));
  }), "\n", Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("deliveringGridOptions")),
      wrapperClass: Spacebars.call("segments-column"),
      headerTemplate: Spacebars.call("deliveryManagerThumbnailHeader2"),
      animation: Spacebars.call("bounceInDown")
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("gridComponent"));
  }), "\n", Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("doneGridOptions")),
      wrapperClass: Spacebars.call("segments-column"),
      headerTemplate: Spacebars.call("deliveryManagerThumbnailHeader3"),
      animation: Spacebars.call("bounceInDown")
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("gridComponent"));
  }))) ];
}));

})();

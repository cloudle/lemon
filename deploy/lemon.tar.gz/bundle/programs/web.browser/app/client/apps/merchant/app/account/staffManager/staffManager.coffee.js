(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var scope;

scope = logics.staffManager;

lemon.defineApp(Template.staffManager, {
  allowCreate: function() {
    if (Session.get('allowCreateStaffAccount')) {
      return '';
    } else {
      return 'disabled';
    }
  },
  events: {
    "input input": function(event, template) {
      return scope.checkAllowCreate(template);
    },
    "change [name='genderMode']": function(event, template) {
      return Session.set("createStaffGenderSelection", event.target.checked);
    },
    "click #createStaffAccount": function(event, template) {
      return scope.createStaffAccount(template);
    },
    "blur #email": function(event, template) {
      var $email;
      $email = $(template.find("#email"));
      if ($email.val().length > 0) {
        if (!Helpers.isEmail($email.val())) {
          return $email.notify('Tài khoản phải là email');
        }
      }
    }
  }
});

})();

(function(){
Template.__define__("transactionThumbnail", (function() {
  var view = this;
  return HTML.DIV({
    "class": "col"
  }, HTML.DIV({
    "class": function() {
      return [ "thumbnails", " ", Spacebars.mustache(view.lookup("styles")) ];
    }
  }, HTML.DIV({
    "class": "right-caption"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("ownerName"));
  })), "\n", Spacebars.TemplateWith(function() {
    return {
      avatar: Spacebars.call(view.lookup("avatarUrl")),
      alias: Spacebars.call(view.lookup("ownerName"))
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("avatarImageComponent"));
  }), "\n", HTML.DIV({
    "class": "horizontal-meter"
  }, HTML.DIV({
    "class": "meter-wrapper"
  }, HTML.DIV({
    "class": "meter-progress",
    style: function() {
      return [ "height: ", Spacebars.mustache(Spacebars.dot(view.lookup("meterStyle"), "percent")), "%; background-color: ", Spacebars.mustache(Spacebars.dot(view.lookup("meterStyle"), "color")) ];
    }
  }))), "\n", HTML.DIV({
    "class": [ "short-desc", " ", "quality" ]
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("daysFromNow"));
  })), "\n", HTML.DIV({
    "class": [ "full-desc", " ", "price" ]
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("formatNumber"), view.lookup("debitCash"));
  }), " ", HTML.Raw("<small>VNĐ</small>")), "\n", HTML.DIV({
    "class": "single-price"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("formatNumber"), view.lookup("totalCash"));
  }), " VNĐ")));
}));

})();

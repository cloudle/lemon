(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineApp(Template.accountingManager, {
  rendered: function() {
    $("[name=fromDate]").datepicker('setDate', Session.get('accountingFilterStartDate'));
    return $("[name=toDate]").datepicker('setDate', Session.get('accountingFilterToDate'));
  },
  events: {
    "click #filterBills": function(event, template) {
      Session.set('accountingFilterStartDate', $("[name=fromDate]").datepicker().data().datepicker.dates[0]);
      return Session.set('accountingFilterToDate', $("[name=toDate]").datepicker().data().datepicker.dates[0]);
    }
  }
});

})();

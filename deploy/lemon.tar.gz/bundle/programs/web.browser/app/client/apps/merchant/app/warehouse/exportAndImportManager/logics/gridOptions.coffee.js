(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Apps.Merchant.exportAndImportManagerInit.push(function(scope) {
  return logics.exportAndImportManager.gridOptions = {
    itemTemplate: 'exportAndImportManagerThumbnail',
    reactiveSourceGetter: function() {
      return logics.exportAndImportManager.availableBills;
    },
    wrapperClasses: 'detail-grid row'
  };
});

})();

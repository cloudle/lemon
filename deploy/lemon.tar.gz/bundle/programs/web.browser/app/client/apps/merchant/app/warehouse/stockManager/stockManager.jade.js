(function(){
Template.__define__("stockManager", (function() {
  var view = this;
  return [ HTML.DIV({
    id: "header"
  }, HTML.DIV({
    "class": "caption-row"
  }, HTML.Raw('<div class="title">XEM TỒN KHO <small>QUẢN LÝ GIÁ BÁN</small></div>'), "\n", HTML.DIV({
    "class": "filter"
  }, [ "Tổng Nhập:", Blaze.View(function() {
    return Spacebars.mustache(view.lookup("totalQualityProduct"));
  }), " - Tồn Kho:", Blaze.View(function() {
    return Spacebars.mustache(view.lookup("totalStockProduct"));
  }), " - Loại:", Blaze.View(function() {
    return Spacebars.mustache(view.lookup("totalProduct"));
  }) ], "\n", HTML.Raw('<!--+iSelect(options=warehouseSelectOptions class="field")-->'), "\n", ""))), HTML.Raw('<!--.editor-row--><!--  .editor-wrapper(style="width: 200px")--><!--    span.ilabel tên đăng nhập--><!--    input(name="email")-->'), HTML.DIV({
    id: "content"
  }, Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("gridOptions"))
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("iGrid"));
  })) ];
}));

})();

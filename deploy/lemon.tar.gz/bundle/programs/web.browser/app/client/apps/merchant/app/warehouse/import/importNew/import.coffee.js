(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineApp(Template["import"], {
  rendered: function() {
    return logics["import"].templateInstance = this;
  },
  events: {
    "click .add-product": function(event, template) {
      return $(template.find('#addProduct')).modal();
    },
    "click .add-provider": function(event, template) {
      return $(template.find('#addProvider')).modal();
    },
    "click .importHistory": function(event, template) {
      return Router.go('/importHistory');
    },
    "change [name='advancedMode']": function(event, template) {
      return logics["import"].templateInstance.ui.extras.toggleExtra('advanced', event.target.checked);
    },
    'blur .description': function(event, template) {
      return logics["import"].updateDescription(template.find(".description").value, Session.get('currentImport'));
    },
    'blur .deposit': function(event, template) {
      var currentImport, deposit;
      deposit = template.find(".deposit");
      currentImport = Session.get('currentImport');
      if (currentImport.totalPrice < deposit.value) {
        deposit.value = currentImport.totalPrice;
        if (currentImport.debit !== currentImport.deposit) {
          return logics["import"].updateDeposit(currentImport.totalPrice, currentImport);
        }
      } else {
        return logics["import"].updateDeposit(deposit.value, currentImport);
      }
    },
    'click .addImportDetail': function(event, template) {
      return logics["import"].addImportDetail(event, template);
    },
    'click .editImport': function(event, template) {
      var currentImport;
      if (currentImport = Session.get('currentImport')) {
        return Meteor.call('importEnabledEdit', currentImport._id, function(error, result) {
          if (error) {
            return console.log(error.error);
          }
        });
      }
    },
    'click .submitImport': function(event, template) {
      var currentImport;
      if (currentImport = Session.get('currentImport')) {
        return Meteor.call('importSubmit', currentImport._id, function(error, result) {
          if (error) {
            return console.log(error.error);
          }
        });
      }
    },
    'click .finishImport': function(event, template) {
      var currentImport;
      if (currentImport = Session.get('currentImport')) {
        if (currentImport.submitted === false) {
          Meteor.call('importSubmit', currentImport._id, function(error, result) {
            if (error) {
              return console.log(error.error);
            }
          });
        }
        return Meteor.call('importFinish', currentImport._id, function(error, result) {
          if (error) {
            return console.log(error.error);
          }
        });
      }
    },
    'click .excel-import': function(event, template) {
      return $(".excelFileSource").click();
    },
    'change .excelFileSource': function(event, template) {
      var $excelSource;
      if (event.target.files.length > 0) {
        console.log('importing');
        $excelSource = $(".excelFileSource");
        $excelSource.parse({
          config: {
            complete: function(results, file) {
              if (file.type === "text/csv") {
                return Apps.Merchant.exportFileImport(results.data);
              }
            }
          }
        });
        return $excelSource.val("");
      }
    }
  }
});

})();

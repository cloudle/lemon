(function(){
Template.__define__("returnProductThumbnail", (function() {
  var view = this;
  return HTML.DIV({
    "class": "col"
  }, HTML.DIV({
    "class": function() {
      return [ "thumbnails", " ", [ Spacebars.mustache(view.lookup("styles")) ] ];
    }
  }, HTML.DIV({
    "class": "right-caption"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("productNameFromId"), view.lookup("product"));
  })), "\n", Spacebars.TemplateWith(function() {
    return {
      avatar: Spacebars.call(view.lookup("avatarUrl")),
      alias: Spacebars.call("{{productNameFromId product}}")
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("avatarImageComponent"));
  }), "\n", HTML.DIV({
    "class": [ "short-desc", " ", "quality" ]
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("pad"), view.lookup("returnQuality"));
  })), "\n", HTML.DIV({
    "class": [ "full-desc", " ", "price" ]
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("formatNumber"), view.lookup("finalPrice"));
  }), " ", HTML.Raw("<small>VNĐ</small>")), "\n", HTML.DIV({
    "class": "discount"
  }, Blaze.If(function() {
    return false;
  }, function() {
    return HTML.SPAN({
      "class": "s4"
    }, "-", Blaze.View(function() {
      return Spacebars.mustache(view.lookup("round"), view.lookup("discountPercent"));
    }), HTML.SPAN({
      "class": "h5"
    }, "%"));
  })), "\n", HTML.DIV({
    "class": "single-price"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("formatNumber"), view.lookup("price"));
  }), " VNĐ"), "\n", HTML.Raw('<div class="trash"><a href="#"><i class="icon-bag"></i></a></div>')));
}));

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineApp(Template.billManager, {
  rendered: function() {
    $("[name=fromDate]").datepicker('setDate', Session.get('billFilterStartDate'));
    return $("[name=toDate]").datepicker('setDate', Session.get('billFilterToDate'));
  },
  events: {
    "click .createSale": function(event, template) {
      return Router.go('/sales');
    },
    "click #filterBills": function(event, template) {
      Session.set('billFilterStartDate', $("[name=fromDate]").datepicker().data().datepicker.dates[0]);
      return Session.set('billFilterToDate', $("[name=toDate]").datepicker().data().datepicker.dates[0]);
    },
    "click .thumbnails": function(event, template) {
      Meteor.subscribe('saleDetails', this._id);
      Session.set('currentBillManagerSale', this);
      return $(template.find('#salePreview')).modal();
    }
  }
});

})();

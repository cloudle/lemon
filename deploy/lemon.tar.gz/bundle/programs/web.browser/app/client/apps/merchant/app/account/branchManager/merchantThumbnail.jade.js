(function(){
Template.__define__("merchantThumbnail", (function() {
  var view = this;
  return HTML.DIV({
    "class": "col"
  }, HTML.DIV({
    "class": function() {
      return [ "thumbnails", " ", Spacebars.mustache(view.lookup("styles")) ];
    }
  }, HTML.DIV({
    "class": "right-caption"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("name"));
  })), "\n", HTML.DIV({
    "class": [ "full-desc", " ", "price" ]
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("creatorName"));
  })), "\n", Spacebars.TemplateWith(function() {
    return {
      avatar: Spacebars.call(view.lookup("undefined")),
      alias: Spacebars.call(view.lookup("name"))
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("avatarImageComponent"));
  }), "\n", Blaze.If(function() {
    return Spacebars.call(view.lookup("isntDelete"));
  }, function() {
    return HTML.DIV({
      "class": "trash"
    }, HTML.I({
      "class": "icon-bag"
    }));
  })));
}));

})();

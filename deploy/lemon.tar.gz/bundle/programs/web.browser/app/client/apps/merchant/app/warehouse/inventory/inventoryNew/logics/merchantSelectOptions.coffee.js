(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var formatMerchantSearch;

formatMerchantSearch = function(item) {
  if (item) {
    return "" + item.name;
  }
};

Apps.Merchant.inventoryManagerInit.push(function(scope) {
  return logics.inventoryManager.merchantSelectOptions = {
    query: function(query) {
      return query.callback({
        results: scope.availableMerchants.fetch()
      });
    },
    initSelection: function(element, callback) {
      var _ref;
      return callback((_ref = Schema.merchants.findOne(Session.get('mySession').currentInventoryBranchSelection)) != null ? _ref : 'skyReset');
    },
    reactiveValueGetter: function() {
      var _ref;
      return (_ref = Session.get('mySession').currentInventoryBranchSelection) != null ? _ref : 'skyReset';
    },
    changeAction: function(e) {
      UserSession.set('currentInventoryBranchSelection', e.added._id);
      scope.availableWarehouses = Schema.warehouses.find({
        merchant: e.added._id
      });
      return UserSession.set('currentInventoryWarehouseSelection', Schema.warehouses.findOne({
        merchant: e.added._id,
        isRoot: true
      })._id);
    },
    minimumResultsForSearch: -1,
    formatSelection: formatMerchantSearch,
    formatResult: formatMerchantSearch,
    placeholder: 'CHỌN CHI NHÁNH'
  };
});

})();

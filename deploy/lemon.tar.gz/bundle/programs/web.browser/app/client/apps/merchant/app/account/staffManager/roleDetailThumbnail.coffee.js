(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineWidget(Template.roleDetailThumbnail, {
  permissionDesc: function() {
    var _ref, _ref1;
    if (!this.roles) {
      return 'CHƯA PHÂN QUYỀN';
    }
    return (_ref = (_ref1 = Schema.roles.findOne({
      name: this.roles[0]
    })) != null ? _ref1.description : void 0) != null ? _ref : 'KHÔNG TÌM THẤY';
  },
  avatarUrl: function() {
    var _ref;
    if (this.avatar) {
      return (_ref = AvatarImages.findOne(this.avatar)) != null ? _ref.url() : void 0;
    } else {
      return void 0;
    }
  },
  email: function() {
    var _ref;
    console.log(this.styles);
    return (_ref = Meteor.users.findOne(this.user)) != null ? _ref.emails[0].address : void 0;
  },
  events: {
    "click .trash": function(event, template) {
      var userOption, userSession;
      if (Meteor.users.remove(this.user) === 1) {
        Schema.userProfiles.remove(this._id);
        if (userSession = Schema.userSessions.findOne({
          user: this.user
        })) {
          Schema.userSessions.remove(userSession._id);
        }
        if (userOption = Schema.userOptions.findOne({
          user: this.user
        })) {
          return Schema.userOptions.remove(userOption._id);
        }
      }
    }
  }
});

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Apps.Merchant.importHistoryInit.push(function(scope) {
  return scope.gridOptions = {
    itemTemplate: 'importHistoryThumbnail',
    reactiveSourceGetter: function() {
      return scope.importHistorys;
    },
    wrapperClasses: 'detail-grid row'
  };
});

})();

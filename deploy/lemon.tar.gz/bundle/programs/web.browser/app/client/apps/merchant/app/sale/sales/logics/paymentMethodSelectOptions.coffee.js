(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var changedActionSelectPaymentMethod, formatPaymentMethodSearch;

formatPaymentMethodSearch = function(item) {
  if (item) {
    return "" + item.display;
  }
};

changedActionSelectPaymentMethod = function(paymentMethod, currentOrder) {
  var option;
  if (paymentMethod === 0) {
    option = {
      paymentMethod: paymentMethod,
      currentDeposit: currentOrder.finalPrice,
      deposit: currentOrder.finalPrice,
      debit: 0
    };
  }
  if (paymentMethod === 1) {
    option = {
      paymentMethod: paymentMethod,
      currentDeposit: 0,
      deposit: 0,
      debit: currentOrder.finalPrice
    };
  }
  return Order.update(currentOrder._id, {
    $set: option
  });
};

Apps.Merchant.salesInit.push(function() {
  return logics.sales.paymentMethodSelectOptions = {
    query: function(query) {
      return query.callback({
        results: Apps.Merchant.PaymentMethods,
        text: 'id'
      });
    },
    initSelection: function(element, callback) {
      var _ref;
      return callback(_.findWhere(Apps.Merchant.PaymentMethods, {
        _id: (_ref = Session.get('currentOrder')) != null ? _ref.paymentMethod : void 0
      }));
    },
    formatSelection: formatPaymentMethodSearch,
    formatResult: formatPaymentMethodSearch,
    placeholder: 'CHỌN SẢN PTGD',
    minimumResultsForSearch: -1,
    changeAction: function(e) {
      return changedActionSelectPaymentMethod(e.added._id, logics.sales.currentOrder);
    },
    reactiveValueGetter: function() {
      var _ref;
      return _.findWhere(Apps.Merchant.PaymentMethods, {
        _id: (_ref = Session.get('currentOrder')) != null ? _ref.paymentMethod : void 0
      });
    }
  };
});

})();

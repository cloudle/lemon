(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Apps.Home.merchantWizardReactive.push(function(scope) {
  var _ref;
  return scope.purchase = Schema.merchantPurchases.findOne({
    merchant: (_ref = Session.get('myProfile')) != null ? _ref.currentMerchant : void 0
  });
});

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var exportAndImportManagerRoute;

exportAndImportManagerRoute = {
  template: 'exportAndImportManager',
  waitOnDependency: 'billManager',
  onBeforeAction: function() {
    if (this.ready()) {
      Apps.setup(logics.exportAndImportManager, Apps.Merchant.exportAndImportManagerInit, 'exportAndImportManager');
      return this.next();
    }
  },
  data: function() {
    logics.exportAndImportManager.reactiveRun();
    return {
      gridOptions: logics.exportAndImportManager.gridOptions
    };
  }
};

lemon.addRoute([exportAndImportManagerRoute], Apps.Merchant.RouterBase);

})();

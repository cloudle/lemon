(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var arrangeSideBar, destroyHomeTracker, startHomeTracker, toggleCollapse;

toggleCollapse = function() {
  return Session.set('collapse', Session.get('collapse') === 'collapsed' ? '' : 'collapsed');
};

arrangeSideBar = function(context) {
  var brandingHeight, messengerHeight, msgListHeight;
  messengerHeight = $("#messenger").outerHeight();
  brandingHeight = $(".branding").outerHeight();
  msgListHeight = $(window).height() - brandingHeight - messengerHeight;
  if (msgListHeight > 150) {
    return $("ul.messenger-list").css("height", "" + msgListHeight + "px");
  }
};

startHomeTracker = function() {
  return Apps.Merchant.homeTracker = Tracker.autorun(function() {
    var purchase, _ref;
    purchase = Schema.merchantPurchases.findOne({
      merchant: (_ref = Session.get("myProfile")) != null ? _ref.currentMerchant : void 0
    });
    if (!purchase) {
      return;
    }
    if (!purchase.merchantRegistered) {
      if (purchase.user === Meteor.userId()) {
        return Router.go('/merchantWizard');
      } else {
        return Router.go('/');
      }
    }
  });
};

destroyHomeTracker = function() {
  return Apps.Merchant.homeTracker.stop();
};

lemon.defineWidget(Template.merchantLayout, {
  collapse: function() {
    var _ref;
    return (_ref = Session.get('collapse')) != null ? _ref : '';
  },
  created: function() {
    return startHomeTracker();
  },
  rendered: function() {
    arrangeSideBar(this);
    $(window).resize(function() {
      Helpers.arrangeAppLayout();
      return arrangeSideBar(this);
    });
    return Helpers.animateUsing("#container", "bounceInDown");
  },
  destroyed: function() {
    $(window).off("resize");
    return destroyHomeTracker();
  },
  events: {
    "click .collapse-toggle": function() {
      return toggleCollapse();
    }
  }
});

})();

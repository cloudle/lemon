(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Apps.Merchant.transactionManagerInit.push(function(scope) {
  return scope.createTransaction = function() {
    var createNewTransaction, _ref;
    if ((_ref = Session.get('createNewTransaction')) != null ? _ref.customerId : void 0) {
      Transaction.newByUser(Session.get('createNewTransaction').customerId, Session.get('createNewTransaction').description, Session.get('createNewTransaction').totalCash, Session.get('createNewTransaction').depositCash, Session.get('createNewTransaction').debtDate);
      createNewTransaction = Session.get('createNewTransaction');
      createNewTransaction.customerId = 'skyReset';
      createNewTransaction.description = '';
      createNewTransaction.maxCash = 0;
      createNewTransaction.debtDate = new Date();
      return Session.set('createNewTransaction', createNewTransaction);
    }
  };
});

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var formatProviderSearch, updateImportAndProduct;

formatProviderSearch = function(item) {
  if (item) {
    return "" + item.name;
  }
};

updateImportAndProduct = function(e) {
  if (e.added) {
    Import.update(Session.get('currentImport')._id, {
      $set: {
        currentProvider: e.added._id
      }
    });
    return Product.update(Session.get('currentImport').currentProduct, {
      $set: {
        provider: e.added._id
      }
    });
  } else {
    Import.update(Session.get('currentImport')._id, {
      $set: {
        currentProvider: 'skyReset'
      }
    });
    return Product.update(Session.get('currentImport').currentProduct, {
      $set: {
        provider: 'skyReset'
      }
    });
  }
};

Apps.Merchant.importInit.push(function(scope) {
  return logics["import"].providerSelectOptions = {
    query: function(query) {
      return query.callback({
        results: _.filter(logics["import"].branchProviders.fetch(), function(item) {
          var unsignedName, unsignedTerm;
          unsignedTerm = Helpers.RemoveVnSigns(query.term);
          unsignedName = Helpers.RemoveVnSigns(item.name);
          return unsignedName.indexOf(unsignedTerm) > -1;
        }),
        text: 'name'
      });
    },
    initSelection: function(element, callback) {
      var _ref, _ref1;
      return callback((_ref = Schema.providers.findOne((_ref1 = Session.get('currentImport')) != null ? _ref1.currentProvider : void 0)) != null ? _ref : 'skyReset');
    },
    formatSelection: formatProviderSearch,
    formatResult: formatProviderSearch,
    id: '_id',
    placeholder: 'CHỌN NHÀ CUNG CẤP',
    others: {
      allowClear: true
    },
    changeAction: function(e) {
      return updateImportAndProduct(e);
    },
    reactiveValueGetter: function() {
      var _ref, _ref1;
      return (_ref = (_ref1 = Session.get('currentImport')) != null ? _ref1.currentProvider : void 0) != null ? _ref : 'skyReset';
    }
  };
});

})();

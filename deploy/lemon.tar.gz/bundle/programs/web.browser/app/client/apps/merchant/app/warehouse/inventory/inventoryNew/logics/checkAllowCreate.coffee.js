(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
logics.inventoryManager.checkAllowCreate = function(context) {
  var description;
  description = context.ui.$description.val();
  if (description.length > 1) {
    return Session.set('allowCreateNewInventory', true);
  } else {
    return Session.set('allowCreateNewInventory', false);
  }
};

})();

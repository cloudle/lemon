(function(){
Template.__define__("roleManager", (function() {
  var view = this;
  return [ HTML.DIV({
    id: "header"
  }, HTML.Raw('<div class="caption-row"><div class="title">PHÂN QUYỀN <small>NHÓM NGƯỜI DÙNG</small></div></div>'), "\n", HTML.DIV({
    "class": "editor-row"
  }, HTML.DIV({
    "class": "editor-wrapper",
    style: "width: 200px"
  }, HTML.Raw('<span class="ilabel">tên nhóm</span>'), "\n", Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("roleSelectOptions")),
      "class": Spacebars.call("field")
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("iSelect"));
  })), "\n", HTML.Raw('<div class="editor-wrapper"><div class="lemon btn lime icon-ok-6" id="updateButton">ÁP DỤNG</div></div>'), "\n", HTML.DIV({
    "class": [ "editor-wrapper", " ", "right" ],
    style: "display"
  }, HTML.DIV({
    "class": function() {
      return [ "lemon", " ", "btn", " ", "lime", " ", "icon-plus-circled", " ", Spacebars.mustache(view.lookup("allowCreate")) ];
    },
    id: "newGroupButton"
  }, "THÊM MỚI")), "\n", HTML.Raw('<div class="editor-wrapper right" style="width: 200px"><span class="ilabel optional">tên nhóm</span>\n<input name="newGroupName"></div>'))), HTML.DIV({
    id: "content",
    "class": "role-manager"
  }, HTML.UL({
    "class": "permission-group"
  }, Blaze.Each(function() {
    return Spacebars.call(view.lookup("permissionGroups"));
  }, function() {
    return HTML.LI(HTML.SPAN({
      "class": function() {
        return [ "group-caption", " ", Spacebars.mustache(view.lookup("icon")) ];
      },
      "data-toggle": "tooltip",
      "data-placement": "right",
      title: function() {
        return Spacebars.mustache(view.lookup("description"));
      }
    }), "\n", HTML.UL({
      "class": "permission-details"
    }, Blaze.Each(function() {
      return Spacebars.call(view.lookup("children"));
    }, function() {
      return HTML.LI({
        "class": "permission-item",
        "data-toggle": "tooltip",
        title: function() {
          return Spacebars.mustache(view.lookup("description"));
        }
      }, HTML.INPUT({
        binding: "switch",
        type: "checkbox",
        name: function() {
          return Spacebars.mustache(view.lookup("key"));
        }
      }), "\n", HTML.DIV({
        "class": "role-label"
      }, Blaze.View(function() {
        return Spacebars.mustache(view.lookup("description"));
      })));
    })));
  })), "\n", HTML.Raw("<!--  ul-->"), "\n", HTML.Raw("<!--    each-->"), "\n", HTML.Raw("<!--    li.permission-item-->"), "\n", HTML.Raw('<!--      input(binding="switch" type="checkbox" name="{{key}}")-->'), "\n", HTML.Raw("<!--      .role-label {{description}}-->")) ];
}));

})();

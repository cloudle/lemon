(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineApp(Template.returns, {
  hideAddReturnDetail: function() {
    var _ref;
    if (!(logics.returns.currentSale || ((_ref = logics.returns.currentReturn) != null ? _ref.status : void 0) === 0)) {
      return "display: none";
    }
  },
  hideFinishReturn: function() {
    var _ref;
    if (((_ref = logics.returns.currentReturn) != null ? _ref.status : void 0) !== 0) {
      return "display: none";
    }
  },
  hideEditReturn: function() {
    var _ref;
    if (((_ref = logics.returns.currentReturn) != null ? _ref.status : void 0) !== 1) {
      return "display: none";
    }
  },
  hideSubmitReturn: function() {
    var _ref;
    if (((_ref = logics.returns.currentReturn) != null ? _ref.status : void 0) !== 1) {
      return "display: none";
    }
  },
  events: {
    'click .addReturnDetail': function(event, template) {
      return logics.returns.addReturnDetail(Session.get('currentSale')._id);
    },
    'click .finishReturn': function(event, template) {
      if (logics.returns.currentReturn) {
        return logics.returns.finishReturn(logics.returns.currentReturn._id);
      }
    },
    'click .editReturn': function(event, template) {
      if (logics.returns.currentReturn) {
        return logics.returns.editReturn(logics.returns.currentReturn._id);
      }
    },
    'click .submitReturn': function(event, template) {
      if (logics.returns.currentReturn) {
        return logics.returns.submitReturn(logics.returns.currentReturn._id);
      }
    }
  }
});

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Apps.Merchant.staffManagerInit.push(function(scope) {
  return scope.checkAllowCreate = function(template) {
    var confirm, email, fullName, password;
    email = template.ui.$email.val();
    password = template.ui.$password.val();
    confirm = template.ui.$confirm.val();
    fullName = template.ui.$fullName.val();
    if (Meteor.users.findOne({
      'emails.address': email
    })) {
      return Session.set('allowCreateStaffAccount', false);
    }
    if (email.length > 0 && password.length > 0 && confirm.length > 0 && fullName.length > 0 && password === confirm) {
      if (_.findWhere(Session.get('availableUserProfile'), {
        fullName: fullName
      })) {
        return Session.set('allowCreateStaffAccount', false);
      } else {
        return Session.set('allowCreateStaffAccount', true);
      }
    } else {
      return Session.set('allowCreateStaffAccount', false);
    }
  };
});

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineWidget(Template.transportHistoryDetail, {
  status: function() {}
});

})();

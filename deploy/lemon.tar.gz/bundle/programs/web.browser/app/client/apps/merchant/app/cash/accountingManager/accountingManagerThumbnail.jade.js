(function(){
Template.__define__("accountingManagerThumbnail", (function() {
  var view = this;
  return HTML.DIV({
    "class": "col"
  }, HTML.DIV({
    "class": "thumbnails"
  }, HTML.DIV({
    "class": "left-caption"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("group"));
  }), HTML.Raw("<br>"), Blaze.View(function() {
    return Spacebars.mustache(view.lookup("orderCode"));
  })), "\n", HTML.DIV({
    "class": "right-caption"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("buyerName"));
  })), "\n", HTML.Raw('<div class="short-desc quality"></div>'), "\n", HTML.DIV({
    "class": "single-price"
  }, HTML.BUTTON({
    "class": [ "btn", " ", "btn-default", " ", "confirmReceive" ],
    style: function() {
      return Spacebars.mustache(view.lookup("showInput"));
    }
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("showInputText"));
  }))), "\n", HTML.DIV({
    "class": [ "full-desc", " ", "price" ]
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("formatNumber"));
  }), " ", HTML.Raw("<small>VNĐ</small>")), "\n", HTML.Raw("<!--.full-desc.price-->"), "\n", HTML.Raw('<!--  button.btn.btn-default.confirmReceive(style="{{showInput}}") {{showInputText}}-->')));
}));

})();

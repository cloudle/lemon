(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
logics.branchManager = {};

Apps.Merchant.branchManagerInit = [];

Apps.Merchant.branchManagerInit.push(function(scope) {
  Session.setDefault('allowCreateNewBranch', false);
  return logics.branchManager.availableBranch = [];
});

logics.branchManager.reactiveRun = function() {
  if (Session.get('allowCreateNewBranch')) {
    return logics.branchManager.allowCreate = '';
  } else {
    return logics.branchManager.allowCreate = 'disabled';
  }
};

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var formatProductSearch, updateImportSelectNewProduct;

formatProductSearch = function(item) {
  if (item) {
    return "" + item.name + " [" + item.skulls + "]";
  }
};

updateImportSelectNewProduct = function(productId) {
  var option, product, _ref, _ref1, _ref2;
  if (!logics["import"].currentImport) {
    logics["import"].currentImport = logics["import"].createImportAndSelected();
    Session.set('currentImport', logics["import"].currentImport);
  }
  product = Schema.products.findOne(productId);
  if (product) {
    option = {
      currentProduct: product._id,
      currentProvider: (_ref = product.provider) != null ? _ref : 'skyReset',
      currentQuality: 1,
      currentImportPrice: (_ref1 = product.importPrice) != null ? _ref1 : 0
    };
    if (product.price > 0 && product.inStockQuality > 0) {
      Import.update(Session.get('currentImport')._id, {
        $set: option,
        $unset: {
          currentPrice: ""
        }
      });
    } else {
      option.currentPrice = (_ref2 = product.importPrice) != null ? _ref2 : 0;
      Import.update(Session.get('currentImport')._id, {
        $set: option
      });
    }
    $("[name=productionDate]").datepicker('setDate', void 0);
    return Session.get('timesUseProduct');
  }
};

Apps.Merchant.importInit.push(function(scope) {
  return logics["import"].productSelectOptions = {
    query: function(query) {
      return query.callback({
        results: _.filter(logics["import"].availableProducts.fetch(), function(item) {
          var unsignedName, unsignedTerm;
          unsignedTerm = Helpers.RemoveVnSigns(query.term);
          unsignedName = Helpers.RemoveVnSigns(item.name);
          return unsignedName.indexOf(unsignedTerm) > -1 || item.productCode.indexOf(unsignedTerm) > -1;
        }),
        text: 'name'
      });
    },
    initSelection: function(element, callback) {
      var _ref, _ref1;
      return callback((_ref = Schema.products.findOne((_ref1 = Session.get('currentImport')) != null ? _ref1.currentProduct : void 0)) != null ? _ref : 'skyReset');
    },
    formatSelection: formatProductSearch,
    formatResult: formatProductSearch,
    id: '_id',
    placeholder: 'CHỌN SẢN PHẨM',
    hotkey: 'return',
    changeAction: function(e) {
      return updateImportSelectNewProduct(e.added._id);
    },
    reactiveValueGetter: function() {
      var _ref, _ref1;
      return (_ref = (_ref1 = Session.get('currentImport')) != null ? _ref1.currentProduct : void 0) != null ? _ref : 'skyReset';
    }
  };
});

})();

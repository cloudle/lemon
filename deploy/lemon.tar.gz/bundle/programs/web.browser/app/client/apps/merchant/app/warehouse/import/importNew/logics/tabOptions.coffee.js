(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var destroyImportAndDetail;

logics["import"].createImportAndSelected = function() {
  var importId;
  importId = Import.createdNewBy('01-05-2015', Session.get('myProfile'));
  UserSession.set('currentImport', importId);
  return Schema.imports.findOne(importId);
};

destroyImportAndDetail = function(importId) {
  var currentImport, importDetail, _i, _len, _ref;
  currentImport = Schema.imports.findOne({
    _id: importId,
    creator: Session.get('myProfile').user,
    merchant: Session.get('myProfile').currentMerchant,
    warehouse: Session.get('myProfile').currentWarehouse
  });
  if (currentImport) {
    _ref = Schema.importDetails.find({
      "import": currentImport._id
    }).fetch();
    for (_i = 0, _len = _ref.length; _i < _len; _i++) {
      importDetail = _ref[_i];
      Schema.importDetails.remove(importDetail._id);
    }
    Schema.imports.remove(currentImport._id);
    return logics["import"].myHistory.count();
  } else {
    return -1;
  }
};

Apps.Merchant.importInit.push(function(scope) {
  return logics["import"].tabOptions = {
    source: logics["import"].myHistory,
    currentSource: 'currentImport',
    caption: 'description',
    key: '_id',
    createAction: function() {
      return logics["import"].createImportAndSelected();
    },
    destroyAction: function(instance) {
      return destroyImportAndDetail(instance._id);
    },
    navigateAction: function(instance) {
      return UserSession.set('currentImport', instance._id);
    }
  };
});

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
logics.customerManager = {};

Apps.Merchant.customerManagerInit = [];

Apps.Merchant.customerManagerInit.push(function(scope) {
  return logics.customerManager.availableCustomers = Customer.insideMerchant(Session.get('myProfile').parentMerchant);
});

logics.customerManager.reactiveRun = function() {
  if (Session.get('allowCreateNewCustomer')) {
    return logics.customerManager.allowCreate = '';
  } else {
    return logics.customerManager.allowCreate = 'disabled';
  }
};

})();

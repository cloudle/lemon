(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var formatRoleSelect, syncSwitchState;

formatRoleSelect = function(item) {
  if (item) {
    return "" + item.name;
  }
};

syncSwitchState = function(switchery, turnOn) {
  var changeSateHook;
  changeSateHook = switchery.isChecked() !== turnOn;
  if (changeSateHook) {
    return switchery.element.click();
  }
};

logics.roleManager.roleSelectOptions = {
  query: function(query) {
    return query.callback({
      results: Schema.roles.find({}, {
        sort: {
          'version.updateAt': -1
        }
      }).fetch()
    });
  },
  initSelection: function(element, callback) {
    return callback(Session.get('currentRoleSelection'));
  },
  changeAction: function(e) {
    var hasPermission, permissionName, switchery, _ref, _results;
    Session.set('currentRoleSelection', e.added);
    _ref = logics.roleManager.rolesTemplateContext["switch"];
    _results = [];
    for (permissionName in _ref) {
      switchery = _ref[permissionName];
      hasPermission = _.contains(e.added.permissions, permissionName);
      _results.push(syncSwitchState(switchery, hasPermission));
    }
    return _results;
  },
  reactiveValueGetter: function() {
    return Session.get('currentRoleSelection');
  },
  formatSelection: formatRoleSelect,
  formatResult: formatRoleSelect
};

})();

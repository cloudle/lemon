(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var branchManagerRoute;

branchManagerRoute = {
  template: 'branchManager',
  waitOnDependency: 'branchManager',
  onBeforeAction: function() {
    if (this.ready()) {
      Apps.setup(logics.branchManager, Apps.Merchant.branchManagerInit, 'branchManager');
      return this.next();
    }
  },
  data: function() {
    logics.branchManager.reactiveRun();
    return {
      allowCreate: logics.branchManager.allowCreate,
      gridOptions: logics.branchManager.gridOptions
    };
  }
};

lemon.addRoute([branchManagerRoute], Apps.Merchant.RouterBase);

})();

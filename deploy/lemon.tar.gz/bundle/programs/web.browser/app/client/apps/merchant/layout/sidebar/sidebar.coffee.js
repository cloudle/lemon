(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineWidget(Template.sidebar, {
  myProfile: function() {
    return Schema.userProfiles.findOne({
      user: Meteor.userId()
    });
  },
  friends: function() {
    return Schema.userProfiles.find({
      user: {
        $not: Meteor.userId()
      }
    });
  },
  events: {
    "click .chat-avatar:not(.me)": function(event, template) {
      var $messenger, $target;
      if (Session.get('messengerVisibility') && this.user === Session.get('currentChatTarget')) {
        Session.set('messengerVisibility', false);
        return;
      }
      $target = $(event.target);
      $messenger = $("#messenger");
      Session.set('currentChatTarget', this.user);
      Session.set('messengerVisibility', true);
      $messenger.addClass('active');
      return $messenger.find('input').focus();
    }
  }
});

})();

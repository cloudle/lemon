(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineApp(Template.salesReport, {
  rendered: function() {
    var col, columns, dateGroup, day, month, monthChart, monthColumn, monthSources, salesData, salesGroup, sum, yearChart, yearColumn, yearSources, _i, _j, _k, _len;
    salesData = Schema.sales.find({}).fetch();
    salesGroup = _.groupBy(salesData, function(o) {
      return o.version.createdAt.getMonth();
    });
    dateGroup = _.groupBy(salesGroup["9"], function(o) {
      return o.version.createdAt.getDate();
    });
    yearSources = [];
    monthSources = [];
    columns = [
      {
        display: "D.THU",
        key: "finalPrice"
      }, {
        display: "G.GIÁ",
        key: "discountCash"
      }
    ];
    for (_i = 0, _len = columns.length; _i < _len; _i++) {
      col = columns[_i];
      yearColumn = {
        key: col.display,
        values: []
      };
      monthColumn = {
        key: col.display,
        values: []
      };
      yearSources.push(yearColumn);
      monthSources.push(monthColumn);
      for (month = _j = 1; _j <= 12; month = ++_j) {
        if (salesGroup[month]) {
          sum = _.reduce(salesGroup[month], function(result, sale) {
            return result += sale[col.key];
          }, 0);
          yearColumn.values.push({
            x: month,
            y: sum
          });
        } else {
          yearColumn.values.push({
            x: month,
            y: 0
          });
        }
      }
      for (day = _k = 1; _k <= 30; day = ++_k) {
        if (dateGroup[day]) {
          sum = _.reduce(dateGroup[day], function(result, sale) {
            return result += sale[col.key];
          }, 0);
          monthColumn.values.push({
            x: day,
            y: sum
          });
        } else {
          monthColumn.values.push({
            x: day,
            y: 0
          });
        }
      }
    }
    yearChart = nv.models.multiBarChart();
    yearChart.xAxis.tickFormat(d3.format(',f'));
    yearChart.yAxis.tickFormat(function(d) {
      return accounting.formatNumber(d / 1000000) + " tr";
    });
    d3.select('#year-chart svg').datum(yearSources).transition().duration(500).call(yearChart);
    nv.utils.windowResize(yearChart.update);
    monthChart = nv.models.multiBarChart();
    monthChart.xAxis.tickFormat(d3.format(',f'));
    monthChart.yAxis.tickFormat(function(d) {
      return accounting.formatNumber(d / 1000000) + " tr";
    });
    return d3.select('#month-chart svg').datum(monthSources).transition().duration(500).call(monthChart);
  }
});

})();

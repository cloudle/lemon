(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var calculateDate, calculateLostQuality, calculateOriginalQuality, calculateRealQuality, calculateSaleQuality;

calculateOriginalQuality = function(context) {
  var product, _ref, _ref1, _ref2, _ref3, _ref4, _ref5, _ref6;
  if ((context.lock === (_ref = context.submit) && _ref === false)) {
    return (_ref1 = (_ref2 = Schema.productDetails.findOne(context.productDetail)) != null ? _ref2.inStockQuality : void 0) != null ? _ref1 : 0;
  }
  if ((context.lock !== (_ref3 = context.submit) && _ref3 === false)) {
    return context.lockOriginalQuality;
  }
  if ((context.lock === (_ref4 = context.submit) && _ref4 !== false)) {
    product = (_ref5 = (_ref6 = Schema.productDetails.findOne(context.productDetail)) != null ? _ref6.inStockQuality : void 0) != null ? _ref5 : 0;
    if (context.originalQuality !== product) {
      return Schema.inventoryDetails.update(context._id, {
        $set: {
          originalQuality: product
        }
      });
    } else {
      return product;
    }
  }
};

calculateSaleQuality = function(context) {
  var count, detail, realQuality, saleDetails, _i, _j, _len, _len1, _ref, _ref1, _ref2;
  if ((context.lock === (_ref = context.submit) && _ref === false)) {
    return context.saleQuality;
  }
  if ((context.lock !== (_ref1 = context.submit) && _ref1 === false)) {
    saleDetails = Schema.saleDetails.find({
      $and: [
        {
          productDetail: context.productDetail,
          status: true,
          exportDate: {
            $gte: context.lockDate
          }
        }
      ]
    }).fetch();
    count = 0;
    for (_i = 0, _len = saleDetails.length; _i < _len; _i++) {
      detail = saleDetails[_i];
      count += detail.quality;
    }
    if (count !== context.saleQuality) {
      realQuality = context.realQuality - (count - context.saleQuality);
      Schema.inventoryDetails.update(context._id, {
        $set: {
          saleQuality: count,
          realQuality: realQuality
        }
      });
    }
    return count;
  }
  if ((context.lock === (_ref2 = context.submit) && _ref2 !== false)) {
    saleDetails = Schema.saleDetails.find({
      $and: [
        {
          productDetail: context.productDetail,
          status: true,
          exportDate: {
            $gte: context.submitDate
          }
        }
      ]
    }).fetch();
    count = 0;
    for (_j = 0, _len1 = saleDetails.length; _j < _len1; _j++) {
      detail = saleDetails[_j];
      count += detail.quality;
    }
    if (count !== context.saleQuality) {
      Schema.inventoryDetails.update(context._id, {
        $set: {
          saleQuality: count
        }
      });
    }
    return count;
  }
};

calculateLostQuality = function(context) {
  var _ref, _ref1, _ref2;
  if ((context.lock === (_ref = context.submit) && _ref === false)) {
    return context.lostQuality;
  }
  if ((context.lock !== (_ref1 = context.submit) && _ref1 === false)) {
    return context.lostQuality;
  }
  if ((context.lock === (_ref2 = context.submit) && _ref2 !== false)) {
    return context.lostQuality;
  }
};

calculateDate = function(context) {
  var _ref, _ref1, _ref2;
  if ((context.lock === (_ref = context.submit) && _ref === false)) {
    return context.version.createdAt;
  }
  if ((context.lock !== (_ref1 = context.submit) && _ref1 === false)) {
    return context.lockDate;
  }
  if ((context.lock === (_ref2 = context.submit) && _ref2 !== false)) {
    return context.submitDate;
  }
};

calculateRealQuality = function(context) {
  var count, detail, saleDetails, _i, _len, _ref, _ref1, _ref2;
  if ((context.lock === (_ref = context.submit) && _ref === false)) {
    return 0;
  }
  if ((context.lock !== (_ref1 = context.submit) && _ref1 === false)) {
    context.realQuality;
  }
  if ((context.lock === (_ref2 = context.submit) && _ref2 !== false)) {
    saleDetails = Schema.saleExports.find({
      $and: [
        {
          productDetail: context.productDetail,
          'version.createdAt': {
            $gte: context.submitDate
          }
        }
      ]
    }).fetch();
    count = 0;
    for (_i = 0, _len = saleDetails.length; _i < _len; _i++) {
      detail = saleDetails[_i];
      count += detail.qualityExport;
    }
    if (count !== context.saleQuality) {
      Schema.inventoryDetails.update(context._id, {
        $set: {
          saleQuality: count
        }
      });
    }
    return count;
  }
};

lemon.defineWidget(Template.inventoryProductThumbnail, {
  colorClass: function() {
    var _ref;
    if ((this.lock === (_ref = this.submit) && _ref === false)) {
      return 'lime';
    }
    if (this.lostQuality > 0) {
      return 'pumpkin';
    } else {
      return 'belize-hole';
    }
  },
  productDetail: function() {
    return Schema.productDetails.findOne(this.productDetail);
  },
  expireDate: function(date) {
    if (date) {
      return date.toDateString();
    } else {
      return '';
    }
  },
  originalQuality: function() {
    return calculateOriginalQuality(this);
  },
  saleQuality: function() {
    return calculateSaleQuality(this);
  },
  date: function() {
    return calculateDate(this);
  },
  status: function() {
    var _ref, _ref1, _ref2;
    if ((this.lock === (_ref = this.submit) && _ref === false)) {
      return 'New';
    }
    if ((this.lock !== (_ref1 = this.submit) && _ref1 === false)) {
      return 'Locked';
    }
    if ((this.lock === (_ref2 = this.submit) && _ref2 !== false)) {
      return 'Submitted';
    }
  },
  hideLock: function() {
    var _ref;
    if ((this.lock !== (_ref = this.submit) || _ref !== false)) {
      return "display: none";
    }
  },
  hideCheck: function() {
    var _ref;
    if ((this.lock === (_ref = this.submit) || _ref !== false)) {
      return "display: none";
    }
  },
  hideReply: function() {
    var _ref;
    if ((this.lock !== (_ref = this.submit) || _ref === false)) {
      return "display: none";
    }
  },
  showDescription: function() {
    var _ref;
    if (((_ref = Session.get('inventoryWarehouse')) != null ? _ref.checkingInventory : void 0) === true && !Session.get("currentInventory") && Session.get("historyInventories")) {
      return "display: none";
    }
  },
  realQualityOptions: function() {
    return {
      parentContext: this,
      reactiveSetter: function(val) {
        var maxQuality, option, _ref;
        if ((this.parentContext.lock !== (_ref = this.parentContext.submit) && _ref === false) && this.parentContext.success === false) {
          option = {};
          maxQuality = this.parentContext.lockOriginalQuality - this.parentContext.saleQuality;
          if (val < maxQuality) {
            option.realQuality = val;
            option.lostQuality = maxQuality - val;
          } else {
            option.realQuality = maxQuality;
            option.lostQuality = 0;
          }
          return Schema.inventoryDetails.update(this.parentContext._id, {
            $set: option
          });
        }
      },
      reactiveValue: function() {
        var _ref;
        return (_ref = this.parentContext.realQuality) != null ? _ref : 0;
      },
      reactiveMax: function() {
        return this.parentContext.lockOriginalQuality - this.parentContext.saleQuality;
      },
      reactiveMin: function() {
        return 0;
      },
      reactiveStep: function() {
        return 1;
      }
    };
  },
  events: {
    "click .icon-lock": function(event, template) {
      var productDetail, _ref, _ref1;
      if (((this.lock === (_ref1 = this.submit) && _ref1 === (_ref = this.success)) && _ref === false)) {
        productDetail = Schema.productDetails.findOne(this.productDetail);
        return Schema.inventoryDetails.update(this._id, {
          $set: {
            lock: true,
            lockDate: new Date,
            lockOriginalQuality: productDetail.inStockQuality,
            realQuality: productDetail.inStockQuality,
            saleQuality: 0,
            lostQuality: 0
          }
        });
      }
    },
    "click .icon-ok-6": function(event, template) {
      var productDetail, _ref, _ref1;
      if (((this.lock !== (_ref1 = this.submit) && _ref1 === (_ref = this.success)) && _ref === false)) {
        productDetail = Schema.productDetails.findOne(this.productDetail);
        return Schema.inventoryDetails.update(this._id, {
          $set: {
            submit: true,
            submitDate: new Date
          }
        });
      }
    },
    "click .icon-reply-3": function(event, template) {
      var _ref, _ref1;
      if (((this.lock === (_ref1 = this.submit) && _ref1 !== (_ref = this.success)) && _ref === false)) {
        return Schema.inventoryDetails.update(this._id, {
          $set: {
            submit: false,
            realQuality: this.lockOriginalQuality - this.saleQuality - this.lostQuality
          }
        });
      }
    }
  }
});

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineWidget(Template.customerThumbnail, {
  gender: function() {
    if (this.gender) {
      return 'Nam';
    } else {
      return 'Nữ';
    }
  },
  isntDelete: function() {
    if (!Schema.sales.findOne({
      buyer: this._id
    })) {
      return true;
    }
  },
  dateOfBirth: function() {
    var _ref;
    return (_ref = this.dateOfBirth) != null ? _ref.toDateString() : void 0;
  },
  avatarUrl: function() {
    var _ref;
    if (this.avatar) {
      return (_ref = AvatarImages.findOne(this.avatar)) != null ? _ref.url() : void 0;
    } else {
      return void 0;
    }
  },
  events: {
    "click .trash": function(event, template) {
      Schema.customers.remove(this._id);
      return event.stopPropagation();
    },
    "click .avatar": function(event, template) {
      template.find('.avatarFile').click();
      Session.set('currentCustomer', this.instance);
      return event.stopPropagation();
    },
    "change .avatarFile": function(event, template) {
      var files;
      files = event.target.files;
      if (files.length > 0) {
        return AvatarImages.insert(files[0], function(error, fileObj) {
          var _ref;
          Schema.customers.update(Session.get('currentCustomer')._id, {
            $set: {
              avatar: fileObj._id
            }
          });
          return (_ref = AvatarImages.findOne(Session.get('currentCustomer').avatar)) != null ? _ref.remove() : void 0;
        });
      }
    }
  }
});

})();

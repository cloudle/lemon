(function(){
Template.__define__("merchantLayout", (function() {
  var view = this;
  return [ Spacebars.include(view.lookupTemplate("watermark")), HTML.DIV({
    "class": function() {
      return [ "application", " ", [ Spacebars.mustache(view.lookup("collapse")) ] ];
    }
  }, Spacebars.include(view.lookupTemplate("navigation")), "\n", Spacebars.include(view.lookupTemplate("sidebar")), "\n", HTML.DIV({
    id: "container"
  }, Spacebars.include(view.lookupTemplate("yield")))), HTML.Raw('<div class="unsupported-resolution"><span>HIỆN NAY HỆ THỐNG EDS CHƯA HỖ TRỢ MÀN HÌNH NHỎ! <br></span>\n<span>BẠN CẦN CHẠY EDS TRÊN ĐỘ PHÂN GIẢI LỚN HƠN</span></div>') ];
}));

Template.__define__("watermark", (function() {
  var view = this;
  return HTML.Raw('<div class="watermark">THIEN BAN</div>');
}));

})();

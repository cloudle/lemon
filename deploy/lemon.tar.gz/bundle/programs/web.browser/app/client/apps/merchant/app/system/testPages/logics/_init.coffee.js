(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
logics.merchantTest = {
  name: 'merchant-test-logics'
};

Apps.Merchant.testInit = [];

lemon.dependencies.add('merchantTest', ['merchantTestDep', 'myMerchantProfiles']);

})();

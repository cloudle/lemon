(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var isCurrentPackage;

isCurrentPackage = function(context) {
  var _ref;
  return ((_ref = Session.get("currentMerchantPackage")) != null ? _ref.packageClass : void 0) === context.options.packageClass;
};

lemon.defineWidget(Template.merchantPriceTable, {
  isActive: function() {
    var _ref;
    return ((_ref = Session.get("currentMerchantPackage")) != null ? _ref.packageClass : void 0) === this.options.packageClass;
  },
  showExtension: function() {
    return this.options.packageClass !== 'free' && isCurrentPackage(this);
  },
  showAccountPlus: function() {
    return Session.get('wizardAccountPlus') > 0 && isCurrentPackage(this);
  },
  showBranchPlus: function() {
    return Session.get('wizardBranchPlus') > 0 && isCurrentPackage(this);
  },
  showWarehousePlus: function() {
    return Session.get('wizardWarehousePlus') > 0 && isCurrentPackage(this);
  },
  accountPlus: function() {
    return Session.get('wizardAccountPlus');
  },
  branchPlus: function() {
    return Session.get('wizardBranchPlus');
  },
  warehousePlus: function() {
    return Session.get('wizardWarehousePlus');
  },
  realWarehouseLim: function() {
    return this.options.warehouseLim + Session.get('wizardBranchPlus');
  },
  events: {
    "click .command.raise.account": function() {
      return Session.set('wizardAccountPlus', Session.get('wizardAccountPlus') + 5);
    },
    "click .command.raise.branch": function() {
      return Session.set('wizardBranchPlus', Session.get('wizardBranchPlus') + 1);
    },
    "click .command.raise.warehouse": function() {
      return Session.set('wizardWarehousePlus', Session.get('wizardWarehousePlus') + 1);
    },
    "click .command.lower.account": function() {
      if (Session.get('wizardAccountPlus') > 0) {
        return Session.set('wizardAccountPlus', Session.get('wizardAccountPlus') - 5);
      }
    },
    "click .command.lower.branch": function() {
      if (Session.get('wizardBranchPlus') > 0) {
        return Session.set('wizardBranchPlus', Session.get('wizardBranchPlus') - 1);
      }
    },
    "click .command.lower.warehouse": function() {
      if (Session.get('wizardWarehousePlus') > 0) {
        return Session.set('wizardWarehousePlus', Session.get('wizardWarehousePlus') - 1);
      }
    }
  }
});

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var formatTimesUseProductSearch, updateImportAndProduct;

formatTimesUseProductSearch = function(item) {
  if (item) {
    return "" + item.display;
  }
};

updateImportAndProduct = function(e) {};

Apps.Merchant.importInit.push(function(scope) {
  return logics["import"].timeUseSelectOptions = {
    query: function(query) {
      return query.callback({
        results: Apps.Merchant.TimesUseProduct,
        text: 'id'
      });
    },
    initSelection: function(element, callback) {
      var _ref;
      return callback((_ref = _.findWhere(Apps.Merchant.TimesUseProduct, {
        timeDate: Session.get('timesUseProduct')
      })) != null ? _ref : 'skyReset');
    },
    formatSelection: formatTimesUseProductSearch,
    formatResult: formatTimesUseProductSearch,
    placeholder: 'CHỌN HẠN DÙNG',
    minimumResultsForSearch: -1,
    changeAction: function(e) {
      return Session.set('timesUseProduct', e.added.timeDate);
    },
    reactiveValueGetter: function() {
      var _ref, _ref1;
      return (_ref = (_ref1 = _.findWhere(Apps.Merchant.TimesUseProduct, {
        timeDate: Session.get('timesUseProduct')
      })) != null ? _ref1._id : void 0) != null ? _ref : 'skyReset';
    }
  };
});

})();

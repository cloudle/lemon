(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var scope;

scope = logics.merchantHome;

lemon.addRoute({
  template: 'merchantHome',
  path: 'merchant',
  waitOnDependency: 'merchantHome',
  onBeforeAction: function() {
    if (this.ready()) {
      Apps.setup(scope, Apps.Merchant.homeRerun, 'merchantHome');
      return this.next();
    }
  },
  data: function() {
    return {
      Summary: MetroSummary.findOne({})
    };
  }
}, Apps.Merchant.RouterBase);

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
logics.staffManager = {};

Apps.Merchant.staffManagerInit = [];

Apps.Merchant.staffManagerReactiveRun = [];

Apps.Merchant.staffManagerInit.push(function(scope) {
  scope.availableMerchants = Schema.merchants.find({
    $or: [
      {
        _id: Session.get('myProfile').parentMerchant
      }, {
        parent: Session.get('myProfile').parentMerchant
      }
    ]
  });
  Session.setDefault("createStaffGenderSelection", false);
  Session.setDefault('allowCreateStaffAccount', false);
  return Session.setDefault('currentRoleSelection', []);
});

Apps.Merchant.staffManagerReactiveRun.push(function(scope) {
  var _ref, _ref1;
  if (Session.get('mySession') && Session.get('myProfile')) {
    if (scope.currentMerchant = Schema.merchants.findOne(Session.get('mySession').createStaffBranchSelection)) {
      scope.currentWarehouse = Schema.warehouses.findOne({
        _id: Session.get('mySession').createStaffWarehouseSelection,
        merchant: scope.currentMerchant._id
      });
      if (!scope.currentWarehouse) {
        scope.currentWarehouse = Schema.warehouses.findOne({
          isRoot: true,
          merchant: scope.currentMerchant._id
        });
        UserSession.set('createStaffWarehouseSelection', (_ref = (_ref1 = scope.currentWarehouse) != null ? _ref1._id : void 0) != null ? _ref : 'skyReset');
      }
    } else {
      scope.currentMerchant = Schema.merchants.findOne(Session.get('myProfile').currentMerchant);
      scope.currentWarehouse = Schema.warehouses.findOne(Session.get('myProfile').currentWarehouse);
      UserSession.set('createStaffBranchSelection', Session.get('myProfile').currentMerchant);
      UserSession.set('createStaffWarehouseSelection', Session.get('myProfile').currentWarehouse);
    }
  }
  if (scope.currentMerchant) {
    return scope.availableWarehouses = Schema.warehouses.find({
      merchant: scope.currentMerchant._id
    });
  }
});

})();

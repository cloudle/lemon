(function(){
Template.__define__("messageNotifications", (function() {
  var view = this;
  return HTML.DIV({
    "class": "dropdown-menu",
    role: "menu"
  }, HTML.Raw('<div class="header-caption">TIN NHẮN</div>\n'), HTML.UL({
    "class": "details"
  }, Blaze.Each(function() {
    return Spacebars.call(view.lookup("topMessages"));
  }, function() {
    return HTML.LI(Spacebars.TemplateWith(function() {
      return {
        avatar: Spacebars.call(view.lookup("notificationSenderAvatar")),
        alias: Spacebars.call(view.lookup("notificationSenderAlias"))
      };
    }, function() {
      return Spacebars.include(view.lookupTemplate("avatarImageComponent"));
    }), "\n", HTML.DIV({
      "class": "content"
    }, Blaze.View(function() {
      return Spacebars.mustache(view.lookup("message"));
    })));
  })));
}));

})();

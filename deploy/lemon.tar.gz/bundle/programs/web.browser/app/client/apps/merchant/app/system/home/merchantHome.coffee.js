(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var scope;

scope = logics.merchantHome;

lemon.defineApp(Template.merchantHome, {
  rendered: function() {
    var _ref;
    console.log('starting tour...');
    Apps.currentTour.init();
    if (!((_ref = Session.get('mySession')) != null ? _ref.tourDisabled : void 0)) {
      Apps.currentTour.restart();
      return UserSession.set('tourDisabled', true);
    }
  },
  events: {
    "click [data-app]:not(.locked)": function(event, template) {
      return Router.go($(event.currentTarget).attr('data-app'));
    }
  }
});

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var toggleTopPanel;

Session.set('topPanelMinimize', true);

toggleTopPanel = function() {
  return Session.set('topPanelMinimize', !Session.get('topPanelMinimize'));
};

lemon.defineWidget(Template.homeTopPanel, {
  minimizeClass: function() {
    if (Session.get('topPanelMinimize')) {
      return 'minimize';
    } else {
      return '';
    }
  },
  toggleIcon: function() {
    if (Session.get('topPanelMinimize')) {
      return 'icon-up-open-3';
    } else {
      return 'icon-down-open-3';
    }
  },
  created: function() {
    Session.setDefault('registerAccountValid', 'invalid');
    return Session.setDefault('registerSecretValid', 'invalid');
  },
  events: {
    "click .top-panel-toggle": function() {
      toggleTopPanel();
      return console.log(Session.get('topPanelMinimize'));
    }
  }
});

})();

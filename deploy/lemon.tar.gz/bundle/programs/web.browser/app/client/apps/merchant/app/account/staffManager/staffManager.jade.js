(function(){
Template.__define__("staffManager", (function() {
  var view = this;
  return [ HTML.DIV({
    id: "header"
  }, HTML.Raw('<div class="caption-row"><div class="title">NHÂN VIÊN <small>TÀI KHOẢN</small></div></div>'), "\n", HTML.DIV({
    "class": "editor-row"
  }, HTML.Raw('<div class="editor-wrapper" style="width: 180px"><span class="ilabel">họ tên</span>\n<input name="fullName"></div>'), "\n", HTML.Raw('<div class="editor-wrapper" style="width: 180px"><span class="ilabel">tài khoản (email)</span>\n<input id="email" name="email"></div>'), "\n", HTML.Raw('<div class="editor-wrapper" style="width: 120px"><span class="ilabel center">mật khẩu</span>\n<input type="password" name="password"></div>'), "\n", HTML.Raw('<div class="editor-wrapper" style="width: 120px"><span class="ilabel center">xác nhận</span>\n<input type="password" name="confirm"></div>'), "\n", HTML.Raw('<div class="editor-wrapper" style="width: 120px"><span class="ilabel center optional">sinh nhật</span>\n<input name="dateOfBirth" binding="datePicker"></div>'), "\n", HTML.Raw('<div class="editor-wrapper" style="width: 120px"><span class="ilabel center optional">gia nhập</span>\n<input name="startWorkingDate" binding="datePicker" data-toggle="tooltip" data-container="body" data-placement="left" title="ngày tính lương"></div>'), "\n", HTML.DIV({
    "class": "editor-wrapper"
  }, HTML.BUTTON({
    id: "createStaffAccount",
    "class": function() {
      return [ "lemon", " ", "btn", " ", "lime", " ", "icon-user-add-1", " ", "addOrderDetail", " ", Spacebars.mustache(view.lookup("allowCreate")) ];
    },
    type: "submit"
  }, "TẠO MỚI"))), "\n", HTML.DIV({
    "class": "editor-row"
  }, HTML.DIV({
    "class": "editor-wrapper",
    style: "width: 360px"
  }, HTML.Raw('<span class="ilabel optional">phân quyền</span>'), "\n", Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("roleSelectOptions")),
      "class": Spacebars.call("field")
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("iSelect"));
  })), "\n", HTML.DIV({
    "class": "editor-wrapper",
    style: "width: 200px"
  }, HTML.Raw('<span class="ilabel optional">nơi làm việc</span>'), "\n", Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("branchSelectOptions")),
      "class": Spacebars.call("field")
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("iSelect"));
  })), "\n", HTML.DIV({
    "class": "editor-wrapper",
    style: "width: 200px"
  }, HTML.Raw('<span class="ilabel optional">kho mặc định</span>'), "\n", Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("warehouseSelectOptions")),
      "class": Spacebars.call("field")
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("iSelect"));
  })), "\n", HTML.Raw('<div class="switches"><input binding="switch" type="checkbox" name="genderMode"></div>'))), HTML.DIV({
    id: "content"
  }, Spacebars.TemplateWith(function() {
    return {
      options: Spacebars.call(view.lookup("gridOptions"))
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("iGrid"));
  })) ];
}));

})();

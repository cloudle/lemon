(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
logics.sales.validation = {};

Apps.Merchant.salesInit.push(function(scope) {
  logics.sales.validation.orderDetail = function(product, quality, price, discountCash) {
    if (quality < 1) {
      console.log('Số lượng nhỏ nhất là 1.');
      return false;
    } else if (price < product.price) {
      console.log('Giá sản phẩm không thể nhỏ hơn giá bán.');
      return false;
    } else if (discountCash > price * quality) {
      console.log('Giảm giá lớn hơn số tiền hiện có.');
      return false;
    } else {
      return true;
    }
  };
  logics.sales.validation.checkProductInStockQuality = function(order, orderDetails) {
    var currentDetail, currentProduct, e, product_ids, products, _i, _len;
    product_ids = _.union(_.pluck(orderDetails, 'product'));
    products = Schema.products.find({
      _id: {
        $in: product_ids
      }
    }).fetch();
    orderDetails = _.chain(orderDetails).groupBy("product").map(function(group, key) {
      return {
        product: key,
        quality: _.reduce(group, (function(res, current) {
          return res + current.quality;
        }), 0)
      };
    }).value();
    try {
      for (_i = 0, _len = orderDetails.length; _i < _len; _i++) {
        currentDetail = orderDetails[_i];
        currentProduct = _.findWhere(products, {
          _id: currentDetail.product
        });
        if (currentProduct.availableQuality < currentDetail.quality) {
          throw {
            message: "lỗi",
            item: currentDetail
          };
        }
      }
      return {};
    } catch (_error) {
      e = _error;
      return {
        error: e
      };
    }
  };
  return scope.validation.getCrossProductQuality = function(productId, orderId) {
    var crossProductQuality, currentProduct, item, sameProducts, _i, _len;
    currentProduct = Schema.products.findOne(productId);
    sameProducts = Schema.orderDetails.find({
      product: productId,
      order: orderId
    }).fetch();
    crossProductQuality = 0;
    for (_i = 0, _len = sameProducts.length; _i < _len; _i++) {
      item = sameProducts[_i];
      crossProductQuality += item.quality;
    }
    return {
      product: currentProduct,
      quality: crossProductQuality
    };
  };
});

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.addRoute({
  template: 'merchantTest',
  waitOnDependency: 'merchantTest',
  onBeforeAction: function() {
    if (this.ready()) {
      Apps.setup(logics.merchantTest, Apps.Merchant.testInit, 'merchantTest');
      return this.next();
    }
  }
}, Apps.Merchant.RouterBase);

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var formatProductSearch, updateSelectNewProduct;

formatProductSearch = function(item) {
  if (item) {
    return "" + item.name + " [" + item.skulls + "]";
  }
};

updateSelectNewProduct = function(scope, product, orderId) {
  var cross, maxQuality;
  cross = scope.validation.getCrossProductQuality(product._id, orderId);
  maxQuality = cross.product.availableQuality - cross.quality;
  return Order.update(orderId, {
    $set: {
      currentProduct: product._id,
      currentQuality: maxQuality > 0 ? 1 : 0,
      currentPrice: product.price,
      currentTotalPrice: product.price,
      currentDiscountCash: Number(0),
      currentDiscountPercent: Number(0)
    }
  });
};

Apps.Merchant.salesInit.push(function(scope) {
  return logics.sales.productSelectOptions = {
    query: function(query) {
      return query.callback({
        results: _.filter(logics.sales.currentAllProductsInWarehouse.fetch(), function(item) {
          var unsignedName, unsignedTerm;
          unsignedTerm = Helpers.RemoveVnSigns(query.term);
          unsignedName = Helpers.RemoveVnSigns(item.name);
          return unsignedName.indexOf(unsignedTerm) > -1 || item.productCode.indexOf(unsignedTerm) > -1;
        }),
        text: 'name'
      });
    },
    initSelection: function(element, callback) {
      var _ref;
      return callback(Schema.products.findOne((_ref = Session.get('currentOrder')) != null ? _ref.currentProduct : void 0));
    },
    formatSelection: formatProductSearch,
    formatResult: formatProductSearch,
    placeholder: 'CHỌN SẢN PHẨM',
    changeAction: function(e) {
      var orderId;
      if (logics.sales.currentOrder) {
        orderId = logics.sales.currentOrder._id;
      } else {
        orderId = logics.sales.createNewOrderAndSelected();
      }
      updateSelectNewProduct(scope, e.added, orderId);
      if (!Session.get('allowAllOrderDetail')) {
        return Session.set('allowAllOrderDetail', true);
      }
    },
    reactiveValueGetter: function() {
      var _ref;
      return (_ref = Session.get('currentOrder')) != null ? _ref.currentProduct : void 0;
    }
  };
});

})();

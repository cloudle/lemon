(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
logics.returns.removeReturnDetail = function(returnDetailId) {
  var returnDetail;
  returnDetail = Schema.returnDetails.findOne({
    _id: returnDetailId
  });
  if (!returnDetail) {
    return console.log('Chi tiết trả hàng không tồn tại');
  }
  if (returnDetail.submit === true) {
    return console.log('Phiếu trả hàng đã xác nhận, không thể xóa.');
  } else {
    Schema.returnDetails.remove(returnDetail._id);
    if (Schema.returnDetails.findOne({
      "return": returnDetail["return"]
    })) {
      return logics.returns.reCalculateReturn(returnDetail["return"]);
    } else {
      Schema.sales.update(returnDetail.sale, {
        $set: {
          status: true
        }
      });
      return Schema.returns.remove(returnDetail["return"]);
    }
  }
};

})();

(function(){
Template.__define__("addProduct", (function() {
  var view = this;
  return HTML.ASIDE({
    "class": [ "modal", " ", "swipe", " ", "left" ],
    id: "addProduct"
  }, HTML.DIV({
    "class": [ "modal-dialog", " ", "sale-bill-preview" ]
  }, HTML.Raw('<div class="modal-header"><button class="close" type="button" data-dismiss="modal"><span aria-hidden="true">&times;</span>\n<span class="sr-only">Close</span></button>\n<h4 class="modal-title"><i class="icon-search-8"></i>\nTHÊM SẢN PHẨM MỚI</h4></div>'), "\n", HTML.DIV({
    "class": [ "modal-body", " ", "printable-area" ]
  }, HTML.Raw('<div class="header"></div>'), "\n", HTML.Raw('<div class="merchant-info"><input class="form-control productCode" type="text" placeholder="Mã Code">\n<input class="form-control name" type="text" placeholder="Tên Sản Phẩm">\n<input class="form-control skull" type="text" placeholder="Loại Sản Phẩm">\n<div align="right"><a class="btn btn-danger create-product">Tạo mới</a></div></div>'), "\n", HTML.UL(Blaze.Each(function() {
    return Spacebars.call(view.lookup("myCreateProduct"));
  }, function() {
    return HTML.LI({
      "class": "order-detail"
    }, HTML.DIV({
      "class": "product-name"
    }, [ Blaze.View(function() {
      return Spacebars.mustache(view.lookup("name"));
    }), " [", Blaze.View(function() {
      return Spacebars.mustache(view.lookup("skulls"));
    }), "]" ], "\n", Blaze.If(function() {
      return Spacebars.call(view.lookup("allowDelete"));
    }, function() {
      return HTML.BUTTON({
        "class": [ "btn", " ", "delete-product" ],
        type: "button"
      }, "x");
    })), "\n", HTML.DIV({
      "class": "product-price"
    }, HTML.SPAN({
      "class": "individual-price"
    }, "Barcode: ", Blaze.View(function() {
      return Spacebars.mustache(view.lookup("productCode"));
    }))));
  })), "\n", HTML.Raw("<!--.bill-summary-->"), "\n", HTML.Raw("<!--.bill-footer-->")), "\n", HTML.Raw('<div class="modal-footer"><button class="btn btn-default" type="button" data-dismiss="modal">ĐÓNG</button></div>')));
}));

})();

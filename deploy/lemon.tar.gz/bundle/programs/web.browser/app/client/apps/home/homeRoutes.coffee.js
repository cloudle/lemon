(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.addRoute([
  {
    template: 'home',
    path: '/',
    layoutTemplate: 'homeLayout',
    waitOnDependency: 'home'
  }
]);

})();

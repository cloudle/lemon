(function(){
Template.__define__("saleProductThumbnail", (function() {
  var view = this;
  return HTML.DIV({
    "class": function() {
      return [ "thumbnails", " ", Spacebars.mustache(view.lookup("styles")) ];
    }
  }, HTML.DIV({
    "class": "right-caption"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("productNameFromId"), view.lookup("product"));
  })), "\n", Spacebars.TemplateWith(function() {
    return {
      avatar: Spacebars.call(view.lookup("avatarUrl")),
      alias: Spacebars.call("{{productNameFromId product}}")
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("avatarImageComponent"));
  }), "\n", HTML.DIV({
    "class": "horizontal-meter"
  }, HTML.Raw("<!--background-color: {{meterStyle.color}}-->"), "\n", HTML.DIV({
    "class": "meter-wrapper"
  }, HTML.DIV({
    "class": "meter-progress",
    style: function() {
      return [ "height: ", Spacebars.mustache(Spacebars.dot(view.lookup("meterStyle"), "percent")), "%; background-color: ", Spacebars.mustache(Spacebars.dot(view.lookup("meterStyle"), "color")) ];
    }
  }))), "\n", HTML.DIV({
    "class": [ "short-desc", " ", "quality" ]
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("pad"), view.lookup("quality"));
  })), "\n", HTML.DIV({
    "class": [ "full-desc", " ", "price" ]
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("formatNumber"), view.lookup("finalPrice"));
  }), " ", HTML.Raw("<small>VNĐ</small>")), HTML.Raw('\n<!--.discount-->\n<!--  if false-->\n<!--    span.s4 -{{round discountPercent}}<span class="h5">%</span>-->\n\n'), HTML.DIV({
    "class": "single-price"
  }, Blaze.View(function() {
    return Spacebars.mustache(view.lookup("formatNumber"), view.lookup("price"));
  }), " VNĐ"), HTML.Raw('\n<div class="trash"><i class="icon-bag"></i></div>\n<div class="command-button up icon-right-open-4"></div>\n<div class="command-button down icon-left-open-4"></div>'));
}));

})();

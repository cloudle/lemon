(function(){
Template.__body__.__contentParts.push(Blaze.View('body_content_'+Template.__body__.__contentParts.length, (function() {
  var view = this;
  return "";
})));
Meteor.startup(Template.__body__.__instantiate);

})();

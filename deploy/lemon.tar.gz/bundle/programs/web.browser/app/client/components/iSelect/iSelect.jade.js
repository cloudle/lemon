(function(){
Template.__define__("iSelect", (function() {
  var view = this;
  return HTML.Raw('<div class="select2component"></div>');
}));

})();

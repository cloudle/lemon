(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineWidget(Template.iCooldown, {
  ui: {
    iCooldown: ".iCooldown"
  },
  rendered: function() {
    var $iCooldown, animationSpeed, buget, cooldownConfigures, maxStep, minArcLength, options, radius, startAt, timeHook, _ref, _ref1, _ref2, _ref3;
    options = this.data.options;
    radius = (_ref = ((_ref1 = options.width) != null ? _ref1 : 200) / 2) != null ? _ref : 100;
    minArcLength = Math.PI * 2 * radius * (1 / 360);
    maxStep = minArcLength * 1000;
    startAt = (_ref2 = options.startAt) != null ? _ref2 : new Date;
    buget = ((_ref3 = options.buget) != null ? _ref3 : 0) * 60000;
    timeHook = new Date;
    animationSpeed = buget / maxStep;
    if (animationSpeed < 16) {
      animationSpeed = 16;
    }
    $iCooldown = $(this.ui.iCooldown);
    cooldownConfigures = {
      max: maxStep,
      readOnly: true
    };
    if (options.width) {
      cooldownConfigures.width = options.width;
    }
    if (options.others) {
      _.extend(cooldownConfigures, options.others);
    }
    $iCooldown.knob(cooldownConfigures);
    return this.data.interval = setInterval((function(_this) {
      return function() {
        var pastedSteps;
        pastedSteps = ((new Date - startAt) / buget) * maxStep;
        $iCooldown.val(pastedSteps).trigger('change');
        if (pastedSteps > maxStep) {
          return clearInterval(_this.data.interval);
        }
      };
    })(this), animationSpeed);
  },
  destroyed: function() {
    return clearInterval(this.data.interval);
  }
});

})();

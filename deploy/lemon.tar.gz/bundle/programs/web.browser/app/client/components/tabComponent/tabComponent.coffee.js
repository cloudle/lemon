(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var destroyTab, generateActiveClass;

destroyTab = function(context, instance) {
  var allTabs, currentIndex, currentSource, latestLength, newTab, nextIndex, options;
  options = context.data.options;
  allTabs = options.source.fetch();
  currentSource = _.findWhere(allTabs, {
    _id: instance._id
  });
  currentIndex = allTabs.indexOf(currentSource);
  latestLength = typeof options.destroyAction === "function" ? options.destroyAction(instance) : void 0;
  if (latestLength > 0) {
    nextIndex = currentIndex + 1;
    if (currentIndex === latestLength) {
      nextIndex = currentIndex - 1;
    }
    Session.set(options.currentSource, allTabs[nextIndex]);
    return typeof options.navigateAction === "function" ? options.navigateAction(allTabs[nextIndex]) : void 0;
  } else if (latestLength === 0) {
    newTab = options.createAction();
    Session.set(options.currentSource, newTab);
    return typeof options.navigateAction === "function" ? options.navigateAction(newTab) : void 0;
  }
};

generateActiveClass = function(context, instance) {
  var currentSource, key;
  key = context.data.options.key;
  currentSource = Session.get(context.data.options.currentSource);
  if (instance[key] === (currentSource != null ? currentSource[key] : void 0)) {
    return 'active';
  } else {
    return '';
  }
};

lemon.defineWidget(Template.tabComponent, {
  activeClass: function() {
    return generateActiveClass(UI._templateInstance(), this);
  },
  dynamicCaption: function() {
    var _ref;
    return this[(_ref = UI._templateInstance().data.options.caption) != null ? _ref : 'caption'];
  },
  events: {
    "click li:not(.new-button):not(.active)": function(event, template) {
      var _base;
      Session.set(template.data.options.currentSource, this);
      return typeof (_base = template.data.options).navigateAction === "function" ? _base.navigateAction(this) : void 0;
    },
    "click li.new-button": function(event, template) {
      return Session.set(template.data.options.currentSource, template.data.options.createAction());
    },
    "dblclick span.delete-button": function(event, template) {
      destroyTab(template, this);
      return event.stopPropagation();
    }
  }
});

})();

(function(){
Template.__define__("selectComponent", (function() {
  var view = this;
  return HTML.Raw('<div class="select-component"></div>');
}));

})();

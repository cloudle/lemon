(function(){
Template.__define__("iGrid", (function() {
  var view = this;
  return HTML.DIV({
    "class": function() {
      return [ "igrid", " ", [ Spacebars.mustache(Spacebars.dot(view.lookup("options"), "wrapperClasses")) ] ];
    }
  }, Blaze.If(function() {
    return Spacebars.call(view.lookup("classicalHeader"));
  }, function() {
    return HTML.DIV({
      "class": function() {
        return [ "igrid-header", " ", [ Spacebars.mustache(Spacebars.dot(view.lookup("classicalHeader"), "class")) ] ];
      }
    }, Spacebars.TemplateWith(function() {
      return {
        template: Spacebars.call(view.lookup("itemTemplate")),
        data: Spacebars.call(Spacebars.dot(view.lookup("classicalHeader"), "columns"))
      };
    }, function() {
      return Spacebars.include(function() {
        return Spacebars.call(Template.__dynamic);
      });
    }));
  }), "\n", Blaze.Each(function() {
    return Spacebars.call(view.lookup("dataSource"));
  }, function() {
    return Spacebars.TemplateWith(function() {
      return {
        template: Spacebars.call(view.lookup("itemTemplate")),
        data: Spacebars.call(view.lookup("."))
      };
    }, function() {
      return Spacebars.include(function() {
        return Spacebars.call(Template.__dynamic);
      });
    });
  }));
}));

Template.__define__("testDyn", (function() {
  var view = this;
  return [ [ Blaze.View(function() {
    return Spacebars.mustache(view.lookup("name"));
  }), ", ", Blaze.View(function() {
    return Spacebars.mustache(view.lookup("price"));
  }) ], HTML.Raw('<a class="btn btn-default">Cloud</a>') ];
}));

})();

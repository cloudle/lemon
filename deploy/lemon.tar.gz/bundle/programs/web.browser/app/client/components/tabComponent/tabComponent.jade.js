(function(){
Template.__define__("tabComponent", (function() {
  var view = this;
  return HTML.UL({
    "class": "tab-component"
  }, HTML.Raw('<li class="new-button icon-plus-6"></li>\n'), Blaze.Each(function() {
    return Spacebars.call(Spacebars.dot(view.lookup("options"), "source"));
  }, function() {
    return HTML.LI({
      "class": function() {
        return Spacebars.mustache(view.lookup("activeClass"));
      }
    }, HTML.DIV({
      "class": "title"
    }, Blaze.View(function() {
      return Spacebars.mustache(view.lookup("dynamicCaption"));
    })), "\n", HTML.SPAN({
      "class": [ "delete-button", " ", "icon-cancel-circled-4" ]
    }));
  }));
}));

})();

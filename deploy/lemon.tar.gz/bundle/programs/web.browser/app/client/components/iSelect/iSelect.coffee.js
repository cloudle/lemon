(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var destroySelection, registerHotkey, registerSelection, setSelection, startTrackingValue, stopTrackingValue;

registerSelection = function($element, context) {
  var options, selectOptions, _ref;
  selectOptions = {};
  options = context.data.options;
  selectOptions.query = options.query;
  selectOptions.formatSelection = function(item) {
    return options.formatSelection(item);
  };
  selectOptions.formatResult = function(item) {
    return options.formatResult(item);
  };
  selectOptions.initSelection = options.initSelection;
  selectOptions.id = (_ref = options.id) != null ? _ref : '_id';
  if (options.placeholder) {
    selectOptions.placeholder = options.placeholder;
  }
  if (options.minimumResultsForSearch) {
    selectOptions.minimumResultsForSearch = options.minimumResultsForSearch;
  }
  if (context.data.options.others) {
    _.extend(selectOptions, context.data.options.others);
  }
  return $element.select2(selectOptions).on('change', function(e) {
    return options.changeAction(e);
  });
};

registerHotkey = function($element, context) {
  if (context.data.options.hotkey) {
    return $(document).bind('keyup', context.data.options.hotkey, function() {
      return $element.select2('open');
    });
  }
};

startTrackingValue = function($element, context) {
  return context.valueTracker = Tracker.autorun(function() {
    return setSelection($element, context);
  });
};

setSelection = function($element, context) {
  var val;
  val = context.data.options.reactiveValueGetter();
  if (val === 'skyReset') {
    return $element.select2('val', '');
  } else {
    if (val) {
      return $element.select2('val', val);
    }
  }
};

destroySelection = function($element, context) {
  return $element.select2('destroy');
};

stopTrackingValue = function(context) {
  return context.valueTracker.stop();
};

lemon.defineWidget(Template.iSelect, {
  ui: {
    component: ".select2component"
  },
  rendered: function() {
    var $element;
    $element = $(this.ui.component);
    if (this.data.width) {
      $element.css('width', this.data.width);
    }
    if (this.data["class"]) {
      $element.addClass(this.data["class"]);
    }
    registerSelection($element, this);
    registerHotkey($element, this);
    startTrackingValue($element, this);
    return setSelection($element, this);
  },
  destroyed: function() {
    var $element;
    $element = $(this.ui.component);
    destroySelection($element, this);
    return stopTrackingValue(this);
  }
});

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var isValueValid, registerSpinEdit, startTrackingOptions, startTrackingValue, stopTrackingOptions;

registerSpinEdit = function($element, context) {
  var options;
  options = {};
  options.initVal = context.data.options.reactiveValue();
  options.min = context.data.options.reactiveMin();
  options.max = context.data.options.reactiveMax();
  options.step = context.data.options.reactiveStep();
  if (context.data.options.others) {
    _.extend(options, context.data.options.others);
  }
  return $element.TouchSpin(options);
};

startTrackingOptions = function($element, context) {
  return context.optionsTracker = Tracker.autorun(function() {
    return $element.trigger("touchspin.updatesettings", {
      max: context.data.options.reactiveMax(),
      min: context.data.options.reactiveMin(),
      step: context.data.options.reactiveStep(),
      initVal: context.data.options.reactiveValue()
    });
  });
};

stopTrackingOptions = function(context) {
  return context.optionsTracker.stop();
};

startTrackingValue = function($element, context) {
  return $element.on('change', function(e) {
    var parsedValue;
    parsedValue = accounting.parse(e.target.value);
    if (context.data.options.reactiveSetter && isValueValid(context, parsedValue)) {
      return context.data.options.reactiveSetter(Number(parsedValue));
    }
  });
};

isValueValid = function(context, value) {
  return value >= context.data.options.reactiveMin() && value <= context.data.options.reactiveMax();
};

lemon.defineWidget(Template.iSpinEdit, {
  reactiveValue: function() {
    return UI._templateInstance().data.options.reactiveValue();
  },
  ui: {
    component: "input"
  },
  rendered: function() {
    var $component;
    $component = $(this.ui.component);
    registerSpinEdit($component, this);
    startTrackingOptions($component, this);
    return startTrackingValue($component, this);
  },
  destroyed: function() {
    return stopTrackingOptions(this);
  }
});

})();

(function(){
Template.__define__("iSpinEdit", (function() {
  var view = this;
  return HTML.INPUT({
    type: "text",
    value: function() {
      return [ Spacebars.mustache(view.lookup("reactiveValue")) ];
    }
  });
}));

})();

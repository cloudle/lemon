(function(){
Template.__define__("gridComponent", (function() {
  var view = this;
  return HTML.DIV({
    "class": function() {
      return [ "igrid", " ", Spacebars.mustache(view.lookup("wrapperClass")) ];
    }
  }, Blaze.If(function() {
    return Spacebars.call(view.lookup("headerTemplate"));
  }, function() {
    return HTML.DIV({
      "class": "igrid-header"
    }, Spacebars.TemplateWith(function() {
      return {
        template: Spacebars.call(view.lookup("headerTemplate"))
      };
    }, function() {
      return Spacebars.include(function() {
        return Spacebars.call(Template.__dynamic);
      });
    }));
  }), "\n", HTML.DIV({
    "class": "igrid-content"
  }, Blaze.Each(function() {
    return Spacebars.call(view.lookup("dataSource"));
  }, function() {
    return HTML.DIV({
      "class": function() {
        return [ "item-wrapper", " ", Spacebars.mustache(view.lookup("animationClass")) ];
      }
    }, Spacebars.TemplateWith(function() {
      return {
        template: Spacebars.call(view.lookup("itemTemplate")),
        data: Spacebars.call(view.lookup("."))
      };
    }, function() {
      return Spacebars.include(function() {
        return Spacebars.call(Template.__dynamic);
      });
    }));
  })));
}));

})();

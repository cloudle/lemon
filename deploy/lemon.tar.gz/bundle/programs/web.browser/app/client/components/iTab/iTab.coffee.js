(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var destroyTab, generateActiveClass;

destroyTab = function(context, instance) {
  var allTabs, currentIndex, currentLength, currentSource, newTab, nextIndex;
  allTabs = Session.get(context.options.source);
  currentSource = _.findWhere(allTabs, {
    _id: instance._id
  });
  currentIndex = allTabs.indexOf(currentSource);
  currentLength = allTabs.length;
  if (currentLength > 1) {
    context.options.destroyAction(instance);
    nextIndex = currentIndex === currentLength - 1 ? currentIndex - 1 : currentIndex + 1;
    Session.set(context.options.currentSource, allTabs[nextIndex]);
    if (context.options.navigateAction) {
      return context.options.navigateAction(allTabs[nextIndex]);
    }
  } else {
    console.log('cannot delete');
    if (instance.brandNew) {
      return;
    }
    context.options.destroyAction(instance);
    newTab = context.options.createAction();
    newTab.brandNew = true;
    Session.set(context.options.currentSource, newTab);
    if (context.options.navigateAction) {
      return context.options.navigateAction(newTab);
    }
  }
};

generateActiveClass = function(context, instance) {
  var currentSource, key;
  key = context.data.options.key;
  currentSource = Session.get(context.data.options.currentSource);
  if (!currentSource || instance[key] !== currentSource[key]) {
    return '';
  } else {
    return 'active';
  }
};

lemon.defineWidget(Template.iTab, {
  sources: function() {
    return Session.get(this.options.source);
  },
  getCaption: function() {
    var _ref;
    return this[(_ref = UI._templateInstance().data.options.caption) != null ? _ref : 'caption'];
  },
  activeClass: function() {
    return generateActiveClass(UI._templateInstance(), this);
  },
  events: {
    "click li:not(.new-button):not(.active)": function(event, template) {
      Session.set(template.data.options.currentSource, this);
      if (template.data.options.navigateAction) {
        return template.data.options.navigateAction(this);
      }
    },
    "click li.new-button": function(event, template) {
      return Session.set(template.data.options.currentSource, template.data.options.createAction());
    },
    "dblclick span.fa": function(event, template) {
      destroyTab(template.data, this);
      return event.stopPropagation();
    }
  }
});

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineWidget(Template.iGrid, {
  itemTemplate: function() {
    var itemTemplate, template;
    template = UI._templateInstance();
    itemTemplate = template.data.options.itemTemplate;
    if (typeof itemTemplate === 'function') {
      return itemTemplate(this);
    } else {
      return itemTemplate;
    }
  },
  dataSource: function() {
    return UI._templateInstance().data.options.reactiveSourceGetter();
  },
  classicalHeader: function() {
    return UI._templateInstance().data.options.classicalHeader;
  }
});

})();

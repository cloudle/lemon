(function(){
Template.__define__("squareMeterComponent", (function() {
  var view = this;
  return HTML.Raw('<div class="square-meter-component"></div>');
}));

})();

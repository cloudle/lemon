(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineWidget(Template.gridComponent, {
  itemTemplate: function() {
    var itemTemplate, template;
    template = UI._templateInstance();
    itemTemplate = template.data.options.itemTemplate;
    if (typeof itemTemplate === 'function') {
      return itemTemplate(this);
    } else {
      return itemTemplate;
    }
  },
  dataSource: function() {
    var _ref;
    return (_ref = this.dataSource) != null ? _ref : UI._templateInstance().data.options.reactiveSourceGetter();
  },
  classicalHeader: function() {
    return UI._templateInstance().data.options.classicalHeader;
  },
  animationClass: function() {
    var animate;
    animate = UI._templateInstance().data.animation;
    if (animate) {
      return "animated " + animate;
    } else {
      return '';
    }
  }
});

})();

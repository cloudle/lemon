(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineWidget(Template.squareMeterComponent, {
  ui: {
    component: ".square-meter-component"
  },
  rendered: function() {}
});

})();

(function(){
Template.__define__("iCooldown", (function() {
  var view = this;
  return HTML.Raw('<div class="iCooldown"></div>');
}));

})();

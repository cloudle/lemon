(function(){
Template.__define__("avatarImageComponent", (function() {
  var view = this;
  return Blaze.If(function() {
    return Spacebars.call(view.lookup("avatar"));
  }, function() {
    return HTML.SPAN({
      "class": [ "avatar", " ", "image" ]
    }, HTML.IMG({
      src: function() {
        return Spacebars.mustache(view.lookup("avatar"));
      }
    }));
  }, function() {
    return HTML.SPAN({
      "class": [ "avatar", " ", "letter" ]
    }, Blaze.View(function() {
      return Spacebars.mustache(view.lookup("aliasLetter"), view.lookup("alias"));
    }));
  });
}));

})();

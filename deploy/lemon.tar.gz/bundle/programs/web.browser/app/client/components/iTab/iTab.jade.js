(function(){
Template.__define__("iTab", (function() {
  var view = this;
  return HTML.UL({
    "class": "sky-tab"
  }, HTML.Raw('<li class="new-button"><div class="title">&nbsp;</div>\n<span class="fa fa-plus"></span></li>\n'), Blaze.Each(function() {
    return Spacebars.call(view.lookup("sources"));
  }, function() {
    return HTML.LI({
      "class": function() {
        return [ Spacebars.mustache(view.lookup("activeClass")) ];
      }
    }, HTML.DIV({
      "class": "title"
    }, Blaze.View(function() {
      return Spacebars.mustache(view.lookup("getCaption"));
    })), "\n", HTML.SPAN({
      "class": [ "fa", " ", "fa-times-circle" ]
    }));
  }));
}));

})();

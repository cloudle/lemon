(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
lemon.defineWidget(Template.selectComponent, {
  rendered: function() {
    return console.log("rendered");
  }
});

})();

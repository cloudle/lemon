(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.startup(function() {
  moment.locale('vi');
  Router.configure({
    progressDebug: false
  });
  return Tracker.autorun(function() {
    if (Meteor.userId()) {
      Session.set('myProfile', Schema.userProfiles.findOne({
        user: Meteor.userId()
      }));
      Session.set('myOption', Schema.userOptions.findOne({
        user: Meteor.userId()
      }));
      return Session.set('mySession', Schema.userSessions.findOne({
        user: Meteor.userId()
      }));
    }
  });
});

})();

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
i18n.map('en', {
  eds: 'eds',
  language: 'Language',
  slogan: 'business management network',
  commingSoon: 'Comming soon..',
  comment: 'Comment',
  register: 'Register',
  term: 'Terms',
  form: {
    userAccount: 'user account',
    password: 'password',
    companyName: 'company name',
    contactPhone: 'phone contact',
    confirm: 'confirm'
  },
  home: {
    news: 'News',
    subNews: 'Our latest updates',
    support: 'Support',
    subSupport: 'FAQ',
    customer: 'Our Customers',
    subCustomer: '& their commments',
    feature: 'Features',
    subFeature: 'EDS system',
    priceTable: 'Price',
    subPriceTable: 'EDS packages',
    contact: 'Contact us',
    subContact: 'Recruitment',
    comment: "Customer's commment",
    award: 'Awards',
    address: '109 Cong Hoa, Tan Binh Dist, HCMC.',
    copyWriting: 'Enterprise Dual Strategy System 2013 - 2014, All rights reserved by Thien Ban Technology Company Limited.',
    term: 'Term of use'
  },
  menu: {
    role: 'phân quyền',
    staff: 'nhân viên',
    customer: 'khách hàng',
    sale: 'bán hàng',
    "return": 'trả hàng',
    bill: 'đơn hàng',
    delivery: 'giao hàng',
    transaction: 'công nợ',
    "export": 'xuất kho',
    "import": 'nhập kho',
    importOrExport: 'xuất/nhập kho',
    inventory: 'tồn kho',
    report: 'báo cáo',
    inventoryChecking: 'kiểm kho',
    branch: 'chi nhánh',
    warehouse: 'kho hàng',
    history: 'nhật ký',
    tracking: 'theo dõi',
    transport: 'chuyển kho'
  }
});

})();

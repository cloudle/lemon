(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
modulus.seedScripts.push(function() {
  return Schema.dumpCollections.insert({
    dumpField: 'dump content from 1st seed..'
  });
});

})();
